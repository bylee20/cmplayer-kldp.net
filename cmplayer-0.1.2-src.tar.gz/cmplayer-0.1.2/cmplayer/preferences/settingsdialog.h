#ifndef PREFERENCESDIALOG_H
#define PREFERENCESDIALOG_H

#include <QDialog>

namespace Preferences {

class Settings;				class GeneralWidget;
class SubtitleWidget;		class InterfaceWidget;
namespace Ui {class Ui_SettingsDialog;}

class SettingsDialog : public QDialog {
	Q_OBJECT
public:
	SettingsDialog(QWidget *parent = 0);
	~SettingsDialog();
private slots:
	void save();
private:
	Ui::Ui_SettingsDialog *ui;
	Settings *m_pref;
	GeneralWidget *m_general;
	SubtitleWidget *m_subtitle;	
	InterfaceWidget *m_interface;
};

}

#endif
