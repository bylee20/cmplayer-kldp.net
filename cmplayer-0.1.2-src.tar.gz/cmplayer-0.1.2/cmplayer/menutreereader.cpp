#include "menutreereader.h"
#include "actioncollection.h"
#include <QFile>
#include <QMenu>
#include <QAction>

MenuTreeReader::MenuTreeReader()
: QXmlStreamReader(), m_ac(ActionCollection::get()), m_menu(0), m_curParent(0) {}


bool MenuTreeReader::read(QMenu *menu, const QString &fileName) {
	QFile file(fileName);
	if (!file.open(QFile::ReadOnly | QFile::Text))
		return false;
	setDevice(&file);
	m_menu = menu;
	while (!atEnd()) {
		readNext();
		if (isStartElement()) {
			if (name() == "Root") {
				QList<QAction*> acts = m_menu->actions();
				for (int i=0; i<acts.size(); ++i)
					m_menu->removeAction(acts[i]);
				readRoot();
			} else
				return false;
		}
	}
	return !error();
}

void MenuTreeReader::readAny() {
	if (!isStartElement())
		return;
	while(!atEnd()) {
		readNext();
		if (isEndElement())
			return;
		if (isStartElement())
			readAny();
	}
}

void MenuTreeReader::readRoot() {
	if (!isStartElement())
		return;
	while (!atEnd()) {
		readNext();
		if (isEndElement())
			return;
		if (isStartElement()) {
			m_curParent = m_menu;
			if (name() == "Action")
				readAction();
			else if (name() == "Menu")
				readMenu();
			else
				readAny();
		}
	}
}

void MenuTreeReader::readAction() {
	if (!isStartElement() || name() != "Action")
		return;
	if (attributes().value("IsSeparator") == "true")
		m_curParent->addSeparator();
	while (!atEnd()) {
		readNext();
		if (isEndElement())
			return;
		if (isStartElement()) {
			if (name() == "Name") {
				QAction *act = m_ac->action(readElementText());
				if (act)
					m_curParent->addAction(act);
			} else
				readAny();
		}
	}
}

void MenuTreeReader::readMenu() {
	if (!isStartElement() || name() != "Menu")
		return;
	QMenu *temp = m_curParent;
	m_curParent = temp->addMenu(attributes().value("Title").toString());
	QAction *original = m_ac->action(m_curParent->title());
	if (original)
		m_curParent->setIcon(original->icon());
	while (!atEnd()) {
		readNext();
		if (isEndElement())
			break;
		if (isStartElement()) {
			if (name() == "Menu")
				readMenu();
			else if (name() == "Action")
				readAction();
			else
				readAny();
		}
	}
	m_curParent = temp;
}
