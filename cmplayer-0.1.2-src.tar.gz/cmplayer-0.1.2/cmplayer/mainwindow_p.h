#ifndef MAINWINDOW_P_H
#define MAINWINDOW_P_H

#include "ui_mainwindow.h"
#include "mainwindow.h"

class MainWindow;				class PlayListModel;
class PlayMenuBar;				class PlayListDock;
class RecentInfo;				class ActionCollection;

namespace MPlayer {
class MediaSource;				class VideoOutput;
class AudioOutput;				class PlayEngine;
class SubtitleOutput;			class Informations;
class ABRepeater;
}

namespace Preferences {class Settings;}

struct MainWindow::Data {
	static const int SubPosStep = 1;
	enum StaysOnTop {AlwaysOnTop, OnlyPlaying, NotStayOnTop};
	Data(MainWindow *p);
	~Data();
	void init();
	void play(const MPlayer::MediaSource &source);
	QMenu *findMenuIn(QMenu *menu, const QString &title);
	void initSubtitles();
	void updateMenus();
	void updateStaysOnTop();
private:
	void createConnections();
	void registerActions();
	void setupGUI();
public:
	MainWindow *p;
	Ui::Ui_MainWindow ui;
	bool dragMove, repeating, pausedByHiding, resizedByAct;
	StaysOnTop staysOnTop;
	QPoint dragPos;
	Preferences::Settings *pref;
	MPlayer::PlayEngine *engine;
	MPlayer::VideoOutput *video;
	MPlayer::AudioOutput *audio;
	MPlayer::SubtitleOutput *subout;
	PlayListModel *model;
	MPlayer::Informations *info;
	RecentInfo *recent;
	PlayMenuBar *pmb;
	QActionGroup *onTopActions, *videoSizeActions, *videoAspectActions;
	QActionGroup *videoCropActions, *subListActions;
	QList<QAction *> recentActions;
	PlayListDock *dock;
	MPlayer::ABRepeater *repeater;
	QMenu *subSelMenu, *recentMenu;
	QMap<int, QAction*> mouseClickActions;
	QMap<int, QPair<QAction*, QAction*> > wheelScrollActions;
};



#endif
