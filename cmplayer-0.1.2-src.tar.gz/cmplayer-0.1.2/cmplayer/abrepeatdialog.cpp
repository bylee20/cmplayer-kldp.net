#include "abrepeatdialog.h"
#include "ui_abrepeatdialog.h"
#include <mplayer/abrepeater.h>

struct ABRepeatDialog::Data {
	ABRepeatDialog *p;
	Ui::Ui_ABRepeatDialog ui;
	MPlayer::ABRepeater *repeater;
	const QTime zero;
};

ABRepeatDialog::ABRepeatDialog(MPlayer::ABRepeater *repeater, QWidget *parent)
: QDialog(parent), d(new Data) {
	d->repeater = repeater;
	d->ui.setupUi(this);
	connect(d->ui.a_time_button, SIGNAL(clicked()), this, SLOT(getAFromTime()));
	connect(d->ui.b_time_button, SIGNAL(clicked()), this, SLOT(getBFromTime()));
	connect(d->ui.a_subtitle_button, SIGNAL(clicked()), this, SLOT(getAFromSubtitle()));
	connect(d->ui.b_subtitle_button, SIGNAL(clicked()), this, SLOT(getBFromSubtitle()));
	connect(d->ui.quit_button, SIGNAL(clicked()), repeater, SLOT(stop()));
	connect(d->ui.start_button, SIGNAL(clicked()), this, SLOT(start()));
}

ABRepeatDialog::~ABRepeatDialog() {
	delete d;
}

void ABRepeatDialog::start() {
	int a = d->zero.msecsTo(d->ui.a_time_edit->time());
	int b = d->zero.msecsTo(d->ui.b_time_edit->time());
	int dif = static_cast<int>(d->ui.add_time_spin->value()*1000);
	d->repeater->repeat(a - dif, b+ dif, d->ui.times_spin->value());
}

void ABRepeatDialog::getAFromTime() {
	d->ui.a_time_edit->setTime(d->zero.addMSecs(d->repeater->setAToCurrentTime()));
}

void ABRepeatDialog::getAFromSubtitle() {
	d->ui.a_time_edit->setTime(d->zero.addMSecs(d->repeater->setAToSubtitleTime()));
}

void ABRepeatDialog::getBFromTime() {
	d->ui.b_time_edit->setTime(d->zero.addMSecs(d->repeater->setBToCurrentTime()));
}

void ABRepeatDialog::getBFromSubtitle() {
	d->ui.b_time_edit->setTime(d->zero.addMSecs(d->repeater->setBToSubtitleTime()));
}

