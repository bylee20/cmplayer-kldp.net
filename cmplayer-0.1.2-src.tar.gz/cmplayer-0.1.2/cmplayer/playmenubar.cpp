#include "playmenubar.h"
#include "ui_playmenubar.h"
#include <QTime>

struct PlayMenuBar::Data {
	Data(PlayMenuBar *parent) : p(parent) {ui.setupUi(p);}
	static QString toString(qint64 msec) {return zero.addMSecs(msec).toString("h:mm:ss");}
	PlayMenuBar *p;
	Ui::Ui_PlayMenuBar ui;
	static const QTime zero;
};

const QTime PlayMenuBar::Data::zero;

PlayMenuBar::PlayMenuBar(QWidget *parent)
: QWidget(parent) {
	d = new Data(this);
}

PlayMenuBar::~PlayMenuBar() {
	delete d;
}

void PlayMenuBar::init(const QList<QWidget *> &tools) {
	QHBoxLayout *layout = new QHBoxLayout;
	layout->setMargin(0);
	layout->setSpacing(0);
	for (int i=0; i<tools.size(); ++i)
		layout->addWidget(tools[i]);
	d->ui.tools_widget->setLayout(layout);
	adjustSize();
	setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
}

void PlayMenuBar::setPlayText(const QString &text) {
	d->ui.play_info_label->setText(text);
}

void PlayMenuBar::setTotalTime(qint64 ms) {
	d->ui.total_time_label->setText(Data::toString(ms));
}

void PlayMenuBar::setCurrentTime(qint64 ms) {
	static qint64 before = -1;
	if (ms != before) {
		d->ui.current_time_label->setText(Data::toString(ms));
		before = ms;
	}
}
