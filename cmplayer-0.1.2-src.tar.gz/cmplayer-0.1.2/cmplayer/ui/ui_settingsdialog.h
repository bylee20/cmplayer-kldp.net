/********************************************************************************
** Form generated from reading ui file 'settingsdialog.ui'
**
** Created: Sun Jun 1 18:27:39 2008
**      by: Qt User Interface Compiler version 4.4.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_SETTINGSDIALOG_H
#define UI_SETTINGSDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QStackedWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

namespace Preferences {
namespace Ui {

class Ui_SettingsDialog
{
public:
    QVBoxLayout *vboxLayout;
    QHBoxLayout *hboxLayout;
    QListWidget *list;
    QStackedWidget *stack;
    QWidget *page;
    QHBoxLayout *hboxLayout1;
    QSpacerItem *spacerItem;
    QPushButton *ok_button;
    QPushButton *cancel_button;

    void setupUi(QDialog *Preferences__Ui__SettingsDialog)
    {
    if (Preferences__Ui__SettingsDialog->objectName().isEmpty())
        Preferences__Ui__SettingsDialog->setObjectName(QString::fromUtf8("Preferences__Ui__SettingsDialog"));
    Preferences__Ui__SettingsDialog->resize(426, 290);
    vboxLayout = new QVBoxLayout(Preferences__Ui__SettingsDialog);
    vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
    hboxLayout = new QHBoxLayout();
    hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
    list = new QListWidget(Preferences__Ui__SettingsDialog);
    const QIcon icon = QIcon(QString::fromUtf8(":/img/games-config-background.png"));
    QListWidgetItem *__listItem = new QListWidgetItem(list);
    __listItem->setIcon(icon);
    const QIcon icon1 = QIcon(QString::fromUtf8(":/img/character-set.png"));
    QListWidgetItem *__listItem1 = new QListWidgetItem(list);
    __listItem1->setIcon(icon1);
    const QIcon icon2 = QIcon(QString::fromUtf8(":/img/preferences-desktop-keyboard.png"));
    QListWidgetItem *__listItem2 = new QListWidgetItem(list);
    __listItem2->setIcon(icon2);
    list->setObjectName(QString::fromUtf8("list"));
    QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Expanding);
    sizePolicy.setHorizontalStretch(0);
    sizePolicy.setVerticalStretch(0);
    sizePolicy.setHeightForWidth(list->sizePolicy().hasHeightForWidth());
    list->setSizePolicy(sizePolicy);
    list->setMaximumSize(QSize(100, 16777215));
    list->setDragDropMode(QAbstractItemView::NoDragDrop);
    list->setIconSize(QSize(48, 48));
    list->setMovement(QListView::Static);
    list->setSpacing(0);
    list->setGridSize(QSize(94, 70));
    list->setViewMode(QListView::IconMode);
    list->setWordWrap(false);

    hboxLayout->addWidget(list);

    stack = new QStackedWidget(Preferences__Ui__SettingsDialog);
    stack->setObjectName(QString::fromUtf8("stack"));
    page = new QWidget();
    page->setObjectName(QString::fromUtf8("page"));
    stack->addWidget(page);

    hboxLayout->addWidget(stack);


    vboxLayout->addLayout(hboxLayout);

    hboxLayout1 = new QHBoxLayout();
    hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
    spacerItem = new QSpacerItem(0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum);

    hboxLayout1->addItem(spacerItem);

    ok_button = new QPushButton(Preferences__Ui__SettingsDialog);
    ok_button->setObjectName(QString::fromUtf8("ok_button"));
    ok_button->setDefault(true);

    hboxLayout1->addWidget(ok_button);

    cancel_button = new QPushButton(Preferences__Ui__SettingsDialog);
    cancel_button->setObjectName(QString::fromUtf8("cancel_button"));

    hboxLayout1->addWidget(cancel_button);


    vboxLayout->addLayout(hboxLayout1);


    retranslateUi(Preferences__Ui__SettingsDialog);
    QObject::connect(cancel_button, SIGNAL(clicked()), Preferences__Ui__SettingsDialog, SLOT(reject()));
    QObject::connect(list, SIGNAL(currentRowChanged(int)), stack, SLOT(setCurrentIndex(int)));

    stack->setCurrentIndex(0);


    QMetaObject::connectSlotsByName(Preferences__Ui__SettingsDialog);
    } // setupUi

    void retranslateUi(QDialog *Preferences__Ui__SettingsDialog)
    {
    Preferences__Ui__SettingsDialog->setWindowTitle(QApplication::translate("Preferences::Ui::SettingsDialog", "Dialog", 0, QApplication::UnicodeUTF8));

    const bool __sortingEnabled = list->isSortingEnabled();
    list->setSortingEnabled(false);
    list->item(0)->setText(QApplication::translate("Preferences::Ui::SettingsDialog", "\354\235\274\353\260\230", 0, QApplication::UnicodeUTF8));
    list->item(1)->setText(QApplication::translate("Preferences::Ui::SettingsDialog", "\354\236\220\353\247\211", 0, QApplication::UnicodeUTF8));
    list->item(2)->setText(QApplication::translate("Preferences::Ui::SettingsDialog", "\354\235\270\355\204\260\355\216\230\354\235\264\354\212\244", 0, QApplication::UnicodeUTF8));

    list->setSortingEnabled(__sortingEnabled);
    ok_button->setText(QApplication::translate("Preferences::Ui::SettingsDialog", "\355\231\225\354\235\270(&O)", 0, QApplication::UnicodeUTF8));
    cancel_button->setText(QApplication::translate("Preferences::Ui::SettingsDialog", "\354\267\250\354\206\214(&C)", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(Preferences__Ui__SettingsDialog);
    } // retranslateUi

};

} // namespace Ui
} // namespace Preferences

namespace Preferences {
namespace Ui {
namespace Ui {
    class SettingsDialog: public Ui_SettingsDialog {};
} // namespace Ui
} // namespace Ui
} // namespace Preferences

#endif // UI_SETTINGSDIALOG_H
