#ifndef MPLAYERMPMEDIASOURCE_H
#define MPLAYERMPMEDIASOURCE_H

#include <QSharedDataPointer>

class QUrl;

namespace MPlayer {

class MediaSource {
public:
	enum Type {Invalid = 0, LocalFile = 1, Url = 2, Disc = 3};
	MediaSource();
	MediaSource(const QString &filePath);
	MediaSource(const QUrl &url);
	MediaSource(const MediaSource &other);
	~MediaSource();
	MediaSource &operator = (const MediaSource &rhs);
	bool operator != (const MediaSource &rhs) const;
	bool operator == (const MediaSource &rhs) const;
	bool operator < (const MediaSource &rhs) const;
	QString filePath() const;
	Type type () const;
	bool isValid() const;
	bool isLocalFile() const;
	QUrl url () const;
	QString displayName() const;
private:
	struct Data;
	friend class SourceInfo;
	QSharedDataPointer<Data> d;
};

}

#endif
