#include "playengine.h"
#include "mediasource.h"
#include "videooutput.h"
#include "audiooutput.h"
#include "subtitleoutput.h"
#include "informations.h"
#include "abrepeater.h"
#include <QUrl>
#include <QFile>
#include <QSize>
#include <QProcess>

namespace MPlayer {

struct PlayEngine::Data {
	Data(PlayEngine *parent);
	void init();
	inline void setState(State state);
	void interpretMessages(QProcess *proc);
public:
	PlayEngine *p;
	Informations *info;
	QProcess *proc;
	VideoOutput *video;
	AudioOutput *audio;
	SubtitleOutput *subout;
	ABRepeater *repeater;
	State state;
	qint64 totalTime, curTime;
	double speed;
	bool justFinished, noVideo, playStopped, gotInfo;
	const QString dontmessup;
	QStringList options;
	MediaSource source;
	qreal videoRatio;
};

PlayEngine::Data::Data(PlayEngine *p)
: p(p), info(Informations::get()), proc(new QProcess(p)), video(0), audio(0), subout(0)
, repeater(new ABRepeater(p)), state(StoppedState), totalTime(0), curTime(0)
, speed(1.0), justFinished(false), noVideo(true), playStopped(false), gotInfo(false)
, dontmessup(info->privatePath() +"/input.conf"), videoRatio(-1.0) {}

void PlayEngine::Data::init() {
	connect(proc, SIGNAL(readyReadStandardOutput()), p, SLOT(interpretMessages()));
	connect(proc, SIGNAL(finished(int, QProcess::ExitStatus)), p, SLOT(slotProcFinished()));
	connect(p, SIGNAL(stateChanged(MPlayer::State, MPlayer::State)),
			p, SLOT(slotStateChanged(MPlayer::State, MPlayer::State)));
	connect(p, SIGNAL(started()), p, SLOT(update()));
}

void PlayEngine::Data::setState(State s) {
	if(state != s) {
		State old=state;
		emit p->stateChanged(state = s, old);
	}
}

void PlayEngine::Data::interpretMessages(QProcess *proc) {
	static QRegExp rxAV("^[AV]: *([0-9,:.-]+)");
	static QRegExp rxVO("^VO: \\[(.*)\\] (\\d+)x(\\d+) => (\\d+)x(\\d+)");
	static QRegExp rxInitStart("^Playing (.+)");
	static QRegExp rxID("^ID_(.*)=(.*)");
	static QRegExp rxFinished("^Exiting\\.+\\s+\\(End of file\\)");
	static QRegExp rxNoVideo("^Video:\\s+no video");
	static QRegExp rxLineBreak("[\\n\\r]");
	QStringList lines = QString::fromLocal8Bit(proc->readAllStandardOutput()).split(rxLineBreak);
	bool skip = false;
	for (int i=0; i<lines.size(); ++i) {
		const QString &message = lines[i];
		if (message.isEmpty())
			continue;
		bool matched = false;
		if (proc == this->proc) {
			if (rxAV.indexIn(message) != -1) {
				matched = true;
				skip = true;
				qint64 msec = static_cast<int>(rxAV.cap(1).toDouble()*1000);
				setState(PlayingState);
				emit p->tick(curTime = msec);
			} else if (message.contains(" PAUSE ")) {
				matched = true;
				setState(PausedState);
			} else if (rxNoVideo.indexIn(message) != -1) {
				matched = true;
				noVideo = true;
			} else if (rxInitStart.indexIn(message) != -1) {
				matched = true;
				emit p->started();
			} else if (rxFinished.indexIn(message) != -1) {
				matched = true;
				emit p->aboutToFinished();
				justFinished = true;
			}
		}
		if (!matched && !gotInfo && rxID.indexIn(message) != -1) {
			const QString id = rxID.cap(1);
			static QSize videoSize(-1, -1);
			if (id == "LENGTH") {
				emit p->totalTimeChanged(totalTime = static_cast<int>(rxID.cap(2).toDouble()*1000));
			} else if (id == "VIDEO_WIDTH") {
				videoSize.setWidth(rxID.cap(2).toInt());
			} else if (id == "VIDEO_HEIGHT") {
				videoSize.setHeight(rxID.cap(2).toInt());
			}
			if (videoSize.isValid()) {
				videoRatio = static_cast<qreal>(videoSize.width())/videoSize.height();
				if (video)
					video->setVideoSize(videoSize);
			}
		}
		if (!skip)
			qDebug(message.toLocal8Bit());
	}
}

PlayEngine::PlayEngine(QObject *parent)
: Controller(parent), d(new Data(this)) {
	d->init();
	QFile file(d->dontmessup);
	if (!file.exists() && file.open(QFile::WriteOnly)) {
		file.write(
			"## prevent mplayer from messing up our shortcuts\n\n"
			"RIGHT gui_about\nLEFT gui_about\nDOWN gui_about\n"
			"UP gui_about\nPGUP gui_about\nPGDWN gui_about\n"
			"- gui_about\n+ gui_about\nESC gui_about\nENTER gui_about\n"
			"SPACE pausing_keep invalid_command\nHOME gui_about\n"
			"END gui_about\n> gui_about\n< gui_about\nINS gui_about\n"
			"DEL gui_about\n[ gui_about\n] gui_about\n{ gui_about\n"
			"} gui_about\nBS gui_about\nTAB gui_about\n. gui_about\n"
			"# gui_about\n@ gui_about\n! gui_about\n9 gui_about\n"
			"/ gui_about\n0 gui_about\n* gui_about\n1 gui_about\n"
			"2 gui_about\n3 gui_about\n4 gui_about\n5 gui_about\n"
			"6 gui_about\n7 gui_about\n8 gui_about\na gui_about\n"
			"b gui_about\nc gui_about\nd gui_about\ne gui_about\n"
			"F invalid_command\nf invalid_command\ng gui_about\n"
			"h gui_about\ni gui_about\nj gui_about\nk gui_about\n"
			"l gui_about\nm gui_about\nn gui_about\no gui_about\n"
			"p gui_about\nq gui_about\nr gui_about\ns gui_about\n"
			"t gui_about\nT gui_about\nu gui_about\nv gui_about\n"
			"w gui_about\nx gui_about\ny gui_about\nz gui_about\n"
			"S gui_about\n"
		);
	}
}

PlayEngine::~PlayEngine() {
	delete d;
}

void PlayEngine::slotStateChanged(MPlayer::State /*newState*/, MPlayer::State /*oldState*/) {
	emit seekableChanged(!isStopped());
}

void PlayEngine::slotProcFinished() {
	d->setState(StoppedState);
	if (d->justFinished) {
		emit finished();
		d->justFinished = false;
	}
}

void PlayEngine::stop() {
	qint64 time = d->curTime;
	if (d->state == StoppedState || !tellmp("quit"))
		return;
	emit stopped(time);
	if (!d->proc->waitForFinished(5000))
		d->proc->kill();
}

void PlayEngine::seek(qint64 time, bool relative) {
	tellmp("seek " + QString::number(static_cast<double>(time)/1000) + (relative ? " 0" : " 2"));
}

void PlayEngine::replay() {
	qint64 time = d->curTime;
	stop();
	start(time);
}

void PlayEngine::interpretMessages() {
	d->interpretMessages(d->proc);
}

bool PlayEngine::start(qint64 time) {
	if (isRunning())
		stop();
	MediaSource source = currentSource();
	if (!source.isValid())
		return false;
	QStringList args;
	args << "-slave" << "-noquiet" << "-nofs" << "-input" << "conf=\"" + d->dontmessup + '"'
		<< "-fontconfig" << "-zoom" << "-nokeepaspect" << "-noautosub" << "-osdlevel" << "0";
	if (!d->gotInfo)
		args << "-identify";
	if (d->video) {
		args << "-wid" << QString::number(d->video->videoWID());
		if (d->video->isSoftwareEqualizerEnabled())
			args << "-vf-add" << "eq2";
		if (!d->video->driver().isEmpty())
			args << "-vo" << d->video->driver();
		if (d->gotInfo && d->video->monitorRatio() < d->videoRatio)
			args << "-vf-add" << "expand=:::::" + QString::number(d->video->monitorRatio());
	} else
		args << "-vo" << "null";
	if (d->audio) {
		if (!d->audio->driver().isEmpty())
			args << "-ao" << d->audio->driver();
		if (d->audio->isEnabledSoftwareVolume())
			args << "-softvol" << "-softvol-max" << QString::number(d->audio->volumeAmplification());
	} else
		args << "-ao" << "null";
	if (d->subout) {
		SubtitleOutput::Font font = d->subout->font();
		if (!font.family.isEmpty())
			args << "-font" << font.family;
		if (!d->subout->encoding().isEmpty())
			args << "-subcp" << d->subout->encoding();
		args << "-subfont-autoscale" << QString::number(d->subout->autoScale());
	}
	//if (general.autoPitch)
	//	args << "-af" << "scaletempo";
	if (time > 1000)
		args << "-ss" << QString::number(static_cast<double>(time)/1000.0);
	
	args += d->options;
	
	args << source.url().toString();
	
	qDebug("%s %s", qPrintable(d->info->mplayerPath()), qPrintable(args.join(" ")));
	d->proc->start(d->info->mplayerPath(), args);
	if (!d->proc->waitForStarted())
		return false;
	return true;
}

void PlayEngine::setCurrentSource(const MediaSource &source) {
	if (!isStopped())
		stop();
	if (d->source != source) {
		emit currentSourceChanged(d->source = source);	
		d->gotInfo = false;
		d->totalTime = 0;
		d->videoRatio = -1.0;
		if (source.isLocalFile()) {
			QStringList args;
			args << "-slave" << "-quiet" << "-identify" << "-vo" << "null" << "-ao" << "null"
				<< source.url().toString();
			static QProcess *proc = new QProcess(this);
			proc->start(Informations::get()->mplayerPath(), args);
			if (proc->waitForStarted(5000)) {
				proc->write("quit\n");
				if (proc->waitForFinished(5000))
					d->interpretMessages(proc);
			}
			proc->kill();
			d->gotInfo = (d->totalTime > 0 && d->videoRatio > 0.0);
		} else
			emit totalTimeChanged(d->totalTime);
	}
}

bool PlayEngine::tellmp(const QString &command) {
	if (isRunning()) {
		d->proc->write(command.toLocal8Bit() + "\n");
		qDebug("told: %s", qPrintable(command));
		return true;
	} else
		qDebug("couldn't tell: %s", qPrintable(command));
	return false;
}

void PlayEngine::play() {
	if (isStopped()) {
		start();
	} else if (isPaused())
		tellmp("pause");
}

bool PlayEngine::isRunning() {
	return d->proc->state() != QProcess::NotRunning;
}

void PlayEngine::setSpeed(double speed) {
	if (d->speed != speed) {
		emit speedChanged(d->speed = qBound(0.1, speed, 100.0));
		tellmp("speed_set " + QString::number(d->speed));
	}
}

void PlayEngine::link(Controller *controller) {
	VideoOutput *video = qobject_cast<VideoOutput*>(controller);
	if (video) {
		if (d->video)
			unlink(d->video);
		d->video = video;
		return;
	}
	AudioOutput *audio = qobject_cast<AudioOutput*>(controller);
	if (audio) {
		if (d->audio)
			unlink(d->audio);
		d->audio = audio;
		return;
	}
	SubtitleOutput *subout = qobject_cast<SubtitleOutput*>(controller);
	if (subout) {
		if (d->subout)
			unlink(d->subout);
		d->subout = subout;
		return;
	}
}

void PlayEngine::unlink(Controller *controller) {
	if (d->video && d->video == controller) {
		d->video = 0;
	} else if (d->audio && d->audio == controller) {
		d->audio = 0;
	} else if (d->subout && d->subout == controller)
		d->subout = 0;
}

double PlayEngine::speed() const {
	return d->speed;
}

MediaSource PlayEngine::currentSource() const {
	return d->source;
}

qint64 PlayEngine::currentTime() const {
	return d->curTime;
}

bool PlayEngine::hasVideo() const {
	return !d->noVideo;
}

bool PlayEngine::isSeekable() const {
	return d->state != StoppedState;
}

qint64 PlayEngine::remainingTime() const {
	return d->totalTime - d->curTime;
}

State PlayEngine::state() const {
	return d->state;
}

qint32 PlayEngine::tickInterval() const {
	return 100;
}

qint64 PlayEngine::totalTime() const {
	return d->totalTime;
}

VideoOutput *PlayEngine::videoOutput() const {
	return d->video;
}

SubtitleOutput *PlayEngine::subtitleOutput() const {
	return d->subout;
}

AudioOutput *PlayEngine::audioOutput() const {
	return d->audio;
}

void PlayEngine::setOptions(const QStringList &options) {
	d->options = options;
}

const QStringList &PlayEngine::options() const {
	return d->options;
}

ABRepeater *PlayEngine::repeater() const {
	return d->repeater;
}

void PlayEngine::update() {
	if (isRunning())
		tellmp("speed_set " + QString::number(d->speed));
}

}
