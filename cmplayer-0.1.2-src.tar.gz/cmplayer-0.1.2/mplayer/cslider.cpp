#include "cslider.h"
#include <QApplication>
#include <QMouseEvent>
#include <QStyle>

CSlider::CSlider(QWidget *parent)
: QSlider(parent) {
	setOrientation(Qt::Horizontal);
	setFocusPolicy(Qt::NoFocus);
}

void CSlider::mousePressEvent(QMouseEvent *event) {
	const int range = maximum() - minimum();
	const int width = this->width();
	const int newVal = static_cast<qint64>(event->x()) * range / width;
	const int metric = qApp->style()->pixelMetric(QStyle::PM_SliderLength);
	const int sub = (metric * range)/width;
	if (qAbs(newVal - value()) > sub)
		setValue(newVal);
	else
		QSlider::mousePressEvent(event);
}
