#include "subtitleparsers/abstractparser.h"

class Subtitle;

namespace SubtitleParsers {

class AbstractParser;

bool parse(const QString &file, SubtitleList *subs, const QString &enc, int minimumInterval = 10);
bool save(const QString &file, const Subtitle &sub, const QString &enc);

}
