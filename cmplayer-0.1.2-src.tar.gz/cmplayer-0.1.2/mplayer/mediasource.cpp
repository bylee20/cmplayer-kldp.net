#include "mediasource.h"
#include <QFileInfo>
#include <QUrl>

namespace MPlayer {

struct MediaSource::Data : public QSharedData {
	Data(): type(Invalid) {}
	Data(const Data &rhs)
	: QSharedData(rhs), type(rhs.type), url(rhs.url) {}
	~Data() {}
	Type type;
	QUrl url;
};

MediaSource::MediaSource()
: d(new Data) {
	
}

MediaSource::MediaSource(const QString &filePath)
: d(new Data) {
	d->url = QUrl::fromLocalFile(filePath);
	if (!d->url.isEmpty()) {
		d->type = LocalFile;
	}
}

MediaSource::MediaSource(const QUrl &url)
: d(new Data) {
	d->url = url;
	if (!url.isEmpty()) {
		if (url.scheme() == "file") {
			d->type = LocalFile;
		} else
			d->type = Url;
	}
}

MediaSource::MediaSource(const MediaSource &rhs)
: d(rhs.d) {
}

MediaSource::~MediaSource() {
}

MediaSource &MediaSource::operator = (const MediaSource &rhs) {
	if (this != &rhs)
		d = rhs.d;
	return *this;
}

bool MediaSource::operator != (const MediaSource &rhs) const {
	return d->type != rhs.d->type || d->url != rhs.d->url;
}

bool MediaSource::operator == (const MediaSource &rhs) const {
	return !operator!=(rhs);
}

bool MediaSource::operator < (const MediaSource &rhs) const {
	return (isLocalFile() ? filePath() : d->url.toString())
			< (rhs.isLocalFile() ? rhs.filePath() : rhs.d->url.toString());
}

QString MediaSource::displayName() const {
	if (d->type == LocalFile)
		return QFileInfo(filePath()).fileName();
	else
		return d->url.toString();
}

QString MediaSource::filePath() const {
	return d->url.toLocalFile();
}

MediaSource::Type MediaSource::type () const {
	return d->type;
}

bool MediaSource::isValid() const {
	return d->type != Invalid;
}

bool MediaSource::isLocalFile() const {
	return d->type == LocalFile;
}

QUrl MediaSource::url () const {
	return d->type != Invalid ? d->url : QUrl();
}

}
