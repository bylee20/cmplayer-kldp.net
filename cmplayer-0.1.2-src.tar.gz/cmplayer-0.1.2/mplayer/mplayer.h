#ifndef MPLAYER_H
#define MPLAYER_H

namespace MPlayer {

enum State {
	StoppedState = 1,
	PlayingState = 2,
	PausedState = 4,
};

}

#endif
