#include "subtitleoutput.h"
#include "mediasource.h"
#include "playengine.h"
#include "informations.h"
#include <QSet>
#include <QDir>
#include <subtitleparsers.h>

namespace MPlayer {

struct SubtitleOutput::Data {
	Data(SubtitleOutput *parent)
	: p(parent), engine(0), tempsub(Informations::get()->privatePath() + "/temp.smi")
	, delay(0), pos(1.0), initPos(1.0), posScale(1.0), autoScale(FitToWidth), autoSelect(SameName)
	, loaded(false), onMargin(true) {}
	bool load();
	void clear(bool emits) {
		p->remove();
		current.clear();
		subtitles.clear();
		selected.clear();
		if (emits) {
			emit p->availableSubtitlesChanged(QStringList());
			emit p->selectedSubtitlesChanged(selected);
		}
	}
	void updateCurrent() {
		current.clear();
		QList<int> order;
		QList<int> indexes = selected;
		for (int i=0; i<priority.size(); ++i) {
			QString lang = priority[i];
			QMutableListIterator<int> it(indexes);
			while(it.hasNext()) {
				if (subtitles[it.next()].language() == lang) {
					order.append(it.value());
					it.remove();
				}
			}
		}
		order += indexes;
		for (int i=0; i<order.size(); ++i)
			current |= subtitles[order[i]];
		if (!engine || !engine->isRunning())
			return;
		p->remove();
		if (SubtitleParsers::save(tempsub, current, encoding))
			p->show();
	}
	SubtitleOutput *p;
	PlayEngine *engine;
	QString tempsub;
	qint64 delay;
	qreal pos, initPos, posScale;
	Font font;
	AutoScale autoScale;
	AutoSelect autoSelect;
	QString encoding;
	bool loaded, onMargin;
	SubtitleList subtitles;
	Subtitle current;
	QList<int> selected;
	QStringList priority;
};

bool SubtitleOutput::Data::load() {
	return loaded = (engine && engine->tellmp("sub_load \"" + tempsub + '\"'));
}

SubtitleOutput::SubtitleOutput(QObject *parent)
: Controller(parent), d(new Data(this)) {
}

SubtitleOutput::~SubtitleOutput() {
	delete d;
}

void SubtitleOutput::setPriority(const QStringList &priority) {
	d->priority = priority;
}

qint64 SubtitleOutput::syncDelay() const {
	return d->delay;
}

qreal SubtitleOutput::pos() const {
	return d->pos;
}

void SubtitleOutput::addSyncDelay(qint64 msec) {
	setSyncDelay(d->delay + msec);
}

void SubtitleOutput::remove() {
	if (d->engine) {
		 hide();
		 if (d->engine->tellmp("sub_remove"))
			d->loaded = false;
	}
}

void SubtitleOutput::clear() {
	d->clear(true);
}

void SubtitleOutput::moveUp() {
	move(d->pos + 0.01/d->posScale);
}

void SubtitleOutput::moveDown() {
	move(d->pos - 0.01/d->posScale);
}

void SubtitleOutput::move(qreal pos) {
	d->pos = qBound(0.0, pos, 1.0);
	if (d->engine)
		d->engine->tellmp("sub_pos "+QString::number(static_cast<int>(d->pos*d->posScale*100)) + " 1");
}

void SubtitleOutput::setSyncDelay(qint64 msec) {
	emit syncDelayChanged(d->delay = msec);
	if (d->engine)
		d->engine->tellmp("sub_delay " + QString::number(static_cast<double>(msec)/1000.0) + " 1");
}

const SubtitleOutput::Font &SubtitleOutput::font() const {
	return d->font;
}
	
void SubtitleOutput::setFont(const Font &font) {
	d->font = font;
}

SubtitleOutput::AutoScale SubtitleOutput::autoScale() const {
	return d->autoScale;
}

void SubtitleOutput::setAutoScale(AutoScale mode) {
	d->autoScale = mode;
}

const QString &SubtitleOutput::encoding() const {
	return d->encoding;
}

void SubtitleOutput::setEncoding(const QString &encoding) {
	d->encoding = encoding;
}

qreal SubtitleOutput::initialPos() const {
	return d->initPos;
}

void SubtitleOutput::setInitialPos(qreal pos) {
	d->initPos = pos;
}

void SubtitleOutput::show() {
	if (d->loaded || d->load())
		d->engine->tellmp("sub_select 0");
}

void SubtitleOutput::hide() {
	if (d->engine)
		d->engine->tellmp("sub_select -1");
}

void SubtitleOutput::slotFinished() {
	d->loaded = false;
}

void SubtitleOutput::load(const QStringList &files) {
	d->clear(false);
	for (int i=0; i<files.size(); ++i) {
		SubtitleList subs;
		if (SubtitleParsers::parse(files[i], &subs, d->encoding, 10))
			d->subtitles += subs;
	}
	QSet<QString> langs;
	QString base;
	if (d->engine)
		base = QFileInfo(d->engine->currentSource().filePath()).baseName();
	for (int i=0; i<d->subtitles.size(); ++i) {
		bool select = false;
		switch(d->autoSelect) {
		case SameName:
			select = QFileInfo(d->subtitles[i].file()).baseName() == base;
			break;
		case AllLoaded:
			select = true;
			break;
		case EachLanguage:
			if (select = (!langs.contains(d->subtitles[i].language())))
				langs.insert(d->subtitles[i].language());
			break;
		default:
			break;
		}
		if (select)
			d->selected.append(i);
	}
	emit availableSubtitlesChanged(names());
	if (!d->subtitles.isEmpty()) {
		d->updateCurrent();
		emit selectedSubtitlesChanged(d->selected);
	}
}

QStringList SubtitleOutput::names() const {
	QStringList names;
	for (int i=0; i<d->subtitles.size(); ++i)
		names.append(d->subtitles[i].name());
	return names;
}

void SubtitleOutput::appendSubtitles(const QStringList &files, bool display) {
	int index = d->subtitles.size();
	for (int i=0; i<files.size(); ++i) {
		SubtitleList subs;
		if (!SubtitleParsers::parse(files[i], &subs, d->encoding, 10))
			continue;
		d->subtitles += subs;
		if (display) {
			for (int j=0; j<subs.size(); ++j, ++index)
				d->selected.append(index);
		}
	}
	emit availableSubtitlesChanged(names());
	if (display) {
		d->updateCurrent();
		emit selectedSubtitlesChanged(d->selected);
	}
}

const QList<int> &SubtitleOutput::selectedIndexes() const {
	return d->selected;
}

void SubtitleOutput::setSelectedIndexes(const QList<int> indexes) {
	d->selected.clear();
	for (int i=0; i<indexes.size(); ++i) {
		if (i < 0 || i >= d->subtitles.size())
			continue;
		d->selected.append(indexes[i]);
	}
	d->updateCurrent();
	emit selectedSubtitlesChanged(d->selected);
}

void SubtitleOutput::select(int index) {
	if (d->selected.contains(index) || index < 0 || index >= d->subtitles.size())
		return;
	d->selected.append(index);
	d->updateCurrent();
	emit selectedSubtitlesChanged(d->selected);
}

void SubtitleOutput::deselect(int index) {
	const int pos = d->selected.indexOf(index);
	if (pos != -1) {
		d->selected.removeAt(pos);
		d->updateCurrent();
		emit selectedSubtitlesChanged(d->selected);
	}
}

void SubtitleOutput::deselectAll() {
	d->selected.clear();
	d->updateCurrent();
	emit selectedSubtitlesChanged(d->selected);
}

void SubtitleOutput::selectAll() {
	d->selected.clear();
	for (int i=0; i<d->subtitles.size(); ++i)
		d->selected.append(i);
	d->updateCurrent();
	emit selectedSubtitlesChanged(d->selected);
}

const QList<Subtitle> &SubtitleOutput::availableSubtitles() const {
	return d->subtitles;
}

SubtitleOutput::AutoSelect SubtitleOutput::autoSelect() const {
	return d->autoSelect;
}

void SubtitleOutput::setAutoSelect(AutoSelect mode) {
	d->autoSelect = mode;
}

const Subtitle &SubtitleOutput::currentSubtitle() const {
	return d->current;
}

void SubtitleOutput::link(Controller *controller) {
	PlayEngine *engine = qobject_cast<PlayEngine*>(controller);
	if (engine) {
		if (d->engine)
			unlink(d->engine);
		d->engine = engine;
		connect(d->engine, SIGNAL(finished()), this, SLOT(slotFinished()));
		connect(d->engine, SIGNAL(started()), this, SLOT(update()));
		return;
	}
}

void SubtitleOutput::unlink(Controller *controller) {
	if (d->engine && d->engine == controller) {
		disconnect(d->engine, 0, this, 0);
		d->engine = 0;
	}
}

void SubtitleOutput::setPosScale(qreal scale) {
	if (static_cast<int>(d->posScale*100) == static_cast<int>(scale*100))
		return;
	d->posScale = qBound(0.0, scale, 1.0);
	move(d->pos);
}

void SubtitleOutput::update() {
	if (d->engine && d->engine->isRunning()) {
		d->engine->tellmp("sub_scale " + QString::number(d->font.scale) + " 1");
		move(d->initPos);
		d->engine->tellmp("sub_delay " + QString::number(static_cast<double>(d->delay)/1000.0) + " 1");
	}
}

void SubtitleOutput::setDisplayOnMarginEnabled(bool enabled) {
	d->onMargin = enabled;
}

bool SubtitleOutput::isDisplayOnMarginEnabled() const {
	return d->onMargin;
}

}

