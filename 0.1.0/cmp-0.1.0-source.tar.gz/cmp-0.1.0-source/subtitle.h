#ifndef SUBTITLE_H
#define SUBTITLE_H

#include <QMap>
#include <QString>

class Subtitle;

typedef QMapIterator<qlonglong, QString> SubtitleIterator;
typedef QList<Subtitle> SubtitleList;

class Subtitle : public QMap<qlonglong, QString> {
public:
	Subtitle();
	inline const QString &file() const {return m_file;}
	inline void setFile(const QString &file) { m_file = file;}
	inline void setLanguage(const QString &lang) { m_lang = lang;}
	inline const QString &language() const {return m_lang;}
	inline Subtitle united(const Subtitle &other) const {Subtitle sub(*this); return sub.unite(other);}
	Subtitle &unite(const Subtitle &other);
	inline Subtitle operator | (const Subtitle &other) const {return united(other);}
	inline Subtitle &operator |= (const Subtitle &other) {return unite(other);}
	QString name() const;
private:
	QString m_file;
	QString m_lang;
};



#endif
