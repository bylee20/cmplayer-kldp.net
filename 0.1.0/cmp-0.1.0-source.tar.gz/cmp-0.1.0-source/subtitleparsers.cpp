#include "subtitleparsers.h"
#include "subtitleparsers/samiparser.h"
#include "subtitleparsers/subripparser.h"
#include "subtitle.h"
#include "helper.h"

namespace SubtitleParsers {

bool parse(const QString &file, SubtitleList *subs, int minimumInterval) {
	AbstractParser *parser = getNewParser(Helper::extension(file));
	bool result = false;
	if (parser) {
		parser->setMinimumInterval(minimumInterval);
		result = parser->parse(file, subs);
		if (!result) {
			subs->clear();
			Subtitle sub;
			sub.setFile(file);
			subs->append(sub);
		}
	}
	delete parser;
	return result;
}

bool save(const QString &file, const Subtitle &sub) {
	AbstractParser *parser = getNewParser(Helper::extension(file));
	bool result = false;
	if (parser)
		result = parser->save(file, sub);
	delete parser;
	return result;
}

AbstractParser *getNewParser(const QString &extension) {
	AbstractParser *p = 0;
	if (extension.compare("smi", Qt::CaseInsensitive) == 0)
		p = new SamiParser;
	else if(extension.compare("srt", Qt::CaseInsensitive)==0)
		p = new SubRipParser;
	return p;
}

}
