#ifndef EQUALIZERDIALOG_H
#define EQUALIZERDIALOG_H

#include <QDialog>

namespace MPlayer {class VideoWidget;}
namespace Ui {class Ui_EqualizerDialog;}

class EqualizerDialog : public QDialog {
	Q_OBJECT
public:
	EqualizerDialog(MPlayer::VideoWidget *engine, QWidget *parent = 0);
	~EqualizerDialog();
protected:
	void showEvent(QShowEvent *event);
private slots:
	void setBrightness(int value);
	void setContrast(int value);
	void setGamma(int value);
	void setHue(int value);
	void setSaturation(int value);
	void resetValues();
	void setValuesDefault();
private:
	static const int MaxValue = 100;
	Ui::Ui_EqualizerDialog *ui;
	MPlayer::VideoWidget *m_video;
	int m_brightness;
	int m_contrast;
	int m_gamma;
	int m_hue;
	int m_saturation;
};


#endif
