#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "mplayer.h"

class PlayMenuBar;				class QActionGroup;
class Subtitle;					class ABRepeater;
class PlayListDock;				class RecentInfo;
class CentralWidget;				class RecentStack;

namespace MPlayer {
class PlayEngine;					class VideoWidget;
class SubtitleOutput;			class AudioOutput;
}

namespace Preferences {class Settings;}
namespace Ui {class Ui_MainWindow;}

class MainWindow : public QMainWindow {
	Q_OBJECT
public:
	MainWindow(const QString &file = QString(), QWidget *parent = 0);
	~MainWindow();
	inline bool isCompactMode() const {return m_compact;}
	void open(const QString &file);
public slots:
	void setCompactMode(bool compact);
	void setFullScreen(bool full);
protected:
	virtual bool eventFilter(QObject *obj, QEvent *event);
	virtual void closeEvent(QCloseEvent *event);
	virtual void mouseMoveEvent(QMouseEvent *event);
	virtual void mouseDoubleClickEvent(QMouseEvent *event);
	virtual void mousePressEvent(QMouseEvent *event);
	virtual void dragEnterEvent(QDragEnterEvent *event);
	virtual void dropEvent(QDropEvent *event);
	virtual void wheelEvent(QWheelEvent *event);
	virtual void hideEvent(QHideEvent *event);
	virtual void showEvent(QShowEvent *event);
private slots:
	void open();
	void openRecent();
	void changeAspectRatio(QAction *act);
	void changeStaysOnTop(QAction *act);
	void slotStateChanged(MPlayer::State state);
	void slotResized();
	void setVideoSize(double rate);
	void changeVideoSize(QAction *act);
	void changeCurrentSubtitles(QAction *act);
	void updateSubtitleList(const QStringList &files);
	void updateCurrentSubtitleIndexes(const QList<int> &indexes);
	void showPreferencesDialog();
	void clearSubtitleList();
	void addSubtitles();
	void showEqualizer();
	void crop(QAction *act);
	void updateSyncDelay(int msec);
	void increaseVolume();
	void decreaseVolume();
	void forward();
	void forwardMore();
	void forwardMuchMore();
	void backward();
	void backwardMore();
	void backwardMuchMore();
	void stepDownSubtitle();
	void stepUpSubtitle();
	void increaseSyncDelay();
	void decreaseSyncDelay();
	void togglePlayPause();
	void updateRecentActions(const RecentStack &files);
	void updateRecentActionsSize(int size);
	void clearRecentFiles();
	void showMouseMenu(const QPoint &pos);
	void showAboutDialog();
	void selectABSection();
	void showABRepeatDialog();
	void togglePlayListVisibility();
	void adjustSizeForDock(bool visible);
	void updatePlayText();
private:
	QMenu *findMenuIn(QMenu *menu, const QString &title);
	enum StaysOnTop {AlwaysOnTop, OnlyPlaying, NotStayOnTop};
	void registerActions();
	void updateStaysOnTop();
	static const int subPosStep = 1;
	Ui::Ui_MainWindow *ui;
	bool m_compact, m_userSize, m_dragMove, m_repeating, m_pausedByHiding;
	StaysOnTop m_staysOnTop;
	QPoint m_dragPos;
	Preferences::Settings *m_pref;
	RecentInfo *m_recent;
	PlayMenuBar *m_pmb;
	QActionGroup *m_onTopActions, *m_videoSizeActions, *m_videoAspectActions;
	QActionGroup *m_videoCropActions, *m_subtitleListActions;
	QList<QAction *> m_recentActions;
	MPlayer::VideoWidget *m_video;
	MPlayer::PlayEngine *m_engine;
	MPlayer::SubtitleOutput *m_subout;
	MPlayer::AudioOutput *m_audio;
	PlayListDock *m_pld;
	ABRepeater *m_repeater;
	QMenu *m_subSelMenu, *m_recentMenu;
};

#endif
