#ifndef ABREPEATDIALOG_H
#define ABREPEATDIALOG_H

#include <QDialog>

namespace Ui {class Ui_ABRepeatDialog;}
class ABRepeater;			class QTime;

class ABRepeatDialog : public QDialog {
	Q_OBJECT
public:
	ABRepeatDialog(QWidget *parent = 0);
	~ABRepeatDialog();
private slots:
	void getAFromTime();
	void getAFromSubtitle();
	void getBFromTime();
	void getBFromSubtitle();
	void start();
private:
	Ui::Ui_ABRepeatDialog *ui;
	ABRepeater *m_repeater;	
	const QTime *const m_time;
};

#endif
