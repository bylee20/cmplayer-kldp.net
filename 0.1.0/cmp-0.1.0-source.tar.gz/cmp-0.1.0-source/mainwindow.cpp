#include <QToolButton>
#include <QActionGroup>
#include <QUrl>
#include <QRegExp>
#include <QDropEvent>
#include <QDir>
#include <QFileDialog>
#include <cmath>
#include "ui_mainwindow.h"
#include "ui_aboutdialog.h"
#include "mainwindow.h"
#include "preferences.h"
#include "prefgeneral.h"
#include "prefinterface.h"
#include "actioncollection.h"
#include "playmenubar.h"
#include "playlistdock.h"
#include "recentinfo.h"
#include "equalizerdialog.h"
#include "prefsettingsdialog.h"
#include "helper.h"
#include "menutreereader.h"
#include "abrepeater.h"
#include "abrepeatdialog.h"
#include "mplayer/playengine.h"
#include "mplayer/mediasource.h"
#include "mplayer/volumeslider.h"
#include "mplayer/seekslider.h"
#include "mplayer/informations.h"
#include "mplayer/videowidget.h"
#include "mplayer/subtitleoutput.h"
#include "mplayer/audiooutput.h"

static QMap<int, QAction*> mouseClickActions;
static QMap<int, QPair<QAction*, QAction*> > wheelScrollActions;

MainWindow::MainWindow(const QString &file, QWidget *parent)
: QMainWindow(parent), ui(new Ui::Ui_MainWindow), m_compact(false), m_userSize(true), m_dragMove(false), m_repeating(false)
, m_pausedByHiding(false), m_staysOnTop(NotStayOnTop), m_dragPos(), m_pref(Preferences::get())
, m_recent(RecentInfo::get()), m_pmb(new PlayMenuBar(this))
, m_onTopActions(new QActionGroup(this)), m_videoSizeActions(new QActionGroup(this))
, m_videoAspectActions(new QActionGroup(this)), m_videoCropActions(new QActionGroup(this))
, m_subtitleListActions(new QActionGroup(this)), m_recentActions()
, m_video(new MPlayer::VideoWidget(this)), m_engine(new MPlayer::PlayEngine(this))
, m_subout(new MPlayer::SubtitleOutput(this)), m_audio(new MPlayer::AudioOutput(this))
, m_pld(new PlayListDock(m_engine, this)), m_repeater(ABRepeater::get()) {
	MPlayer::connect(m_engine, m_video);
	MPlayer::connect(m_engine, m_audio);
	MPlayer::connect(m_engine, m_subout);
	
	ui->setupUi(this);
	
	connect(ui->file_open_action, SIGNAL(triggered()), this, SLOT(open()));
	connect(ui->file_recent_clear_action, SIGNAL(triggered()), this, SLOT(clearRecentFiles()));
	connect(ui->file_exit_action, SIGNAL(triggered()), qApp, SLOT(quit()));
	
	connect(ui->play_show_playlist_action, SIGNAL(triggered()), this, SLOT(togglePlayListVisibility()));
	connect(ui->play_pause_action, SIGNAL(triggered()), this, SLOT(togglePlayPause()));
	connect(ui->play_stop_action, SIGNAL(triggered()), m_engine, SLOT(stop()));
	connect(ui->play_previous_action, SIGNAL(triggered()), m_pld, SLOT(playPrevious()));
	connect(ui->play_next_action, SIGNAL(triggered()), m_pld, SLOT(playNext()));
	connect(ui->play_forward_action, SIGNAL(triggered()), this, SLOT(forward()));
	connect(ui->play_forward_more_action, SIGNAL(triggered()), this, SLOT(forwardMore()));
	connect(ui->play_forward_much_more_action, SIGNAL(triggered()), this, SLOT(forwardMuchMore()));
	connect(ui->play_backward_action, SIGNAL(triggered()), this, SLOT(backward()));
	connect(ui->play_backward_more_action, SIGNAL(triggered()), this, SLOT(backwardMore()));
	connect(ui->play_backward_much_more_action, SIGNAL(triggered()), this, SLOT(backwardMuchMore()));
	connect(ui->play_ab_select_action, SIGNAL(triggered()), this, SLOT(selectABSection()));
	connect(ui->play_ab_stop_action, SIGNAL(triggered()), m_repeater, SLOT(stop()));
	connect(ui->play_ab_advance_action, SIGNAL(triggered()), this, SLOT(showABRepeatDialog()));
	
	connect(ui->video_fullscreen_action, SIGNAL(toggled(bool)), this, SLOT(setFullScreen(bool)));
	connect(ui->video_compact_mode_action, SIGNAL(toggled(bool)), this, SLOT(setCompactMode(bool)));
	connect(m_onTopActions, SIGNAL(triggered(QAction*)), this, SLOT(changeStaysOnTop(QAction*)));	
	connect(m_videoSizeActions, SIGNAL(triggered(QAction*)), this, SLOT(changeVideoSize(QAction*)));
	connect(m_videoAspectActions, SIGNAL(triggered(QAction*)), this, SLOT(changeAspectRatio(QAction*)));	
	connect(m_videoCropActions, SIGNAL(triggered(QAction *)), this, SLOT(crop(QAction *)));
	connect(ui->video_equalizer_action, SIGNAL(triggered()), this, SLOT(showEqualizer()));
	
	connect(ui->audio_volume_up_action, SIGNAL(triggered()), this, SLOT(increaseVolume()));
	connect(ui->audio_volume_down_action, SIGNAL(triggered()), this, SLOT(decreaseVolume()));
	connect(ui->audio_mute_action, SIGNAL(toggled(bool)), m_audio, SLOT(setMuted(bool)));

	connect(m_subtitleListActions, SIGNAL(triggered(QAction*)), this,
			SLOT(changeCurrentSubtitles(QAction*)));
	connect(ui->subtitle_clear_action, SIGNAL(triggered()), m_subout, SLOT(clearSubtitles()));
	connect(ui->subtitle_add_action, SIGNAL(triggered()), this, SLOT(addSubtitles()));
	connect(ui->subtitle_step_up_action, SIGNAL(triggered()), this, SLOT(stepUpSubtitle()));
	connect(ui->subtitle_step_down_action, SIGNAL(triggered()), this, SLOT(stepDownSubtitle()));
	connect(ui->subtitle_sync_increase_action, SIGNAL(triggered()), this, SLOT(increaseSyncDelay()));
	connect(ui->subtitle_sync_decrease_action, SIGNAL(triggered()), this, SLOT(decreaseSyncDelay()));
	
	connect(ui->option_preferences_action, SIGNAL(triggered()), this, SLOT(showPreferencesDialog()));

	connect(ui->about_qt_action, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
	connect(ui->about_cmp_action, SIGNAL(triggered()), this, SLOT(showAboutDialog()));
	ui->video_on_top_only_playing_action->setData(OnlyPlaying);
	ui->video_on_top_off_action->setData(NotStayOnTop);
	ui->video_on_top_always_action->setData(AlwaysOnTop);
	m_onTopActions->addAction(ui->video_on_top_always_action);
	m_onTopActions->addAction(ui->video_on_top_only_playing_action);
	m_onTopActions->addAction(ui->video_on_top_off_action);
	
	ui->video_size_50_action->setData(0.5);
	ui->video_size_100_action->setData(1.0);
	ui->video_size_150_action->setData(1.5);
	ui->video_size_200_action->setData(2.0);
	ui->video_size_250_action->setData(2.5);
	ui->video_size_300_action->setData(3.0);
	ui->video_size_350_action->setData(3.5);
	ui->video_size_400_action->setData(4.0);
	ui->video_size_user_action->setData(-1.0);
	m_videoSizeActions->addAction(ui->video_size_50_action);
	m_videoSizeActions->addAction(ui->video_size_100_action);
	m_videoSizeActions->addAction(ui->video_size_150_action);
	m_videoSizeActions->addAction(ui->video_size_200_action);
	m_videoSizeActions->addAction(ui->video_size_250_action);
	m_videoSizeActions->addAction(ui->video_size_300_action);
	m_videoSizeActions->addAction(ui->video_size_350_action);
	m_videoSizeActions->addAction(ui->video_size_400_action);
	m_videoSizeActions->addAction(ui->video_size_user_action);
	
	ui->video_aspect_auto_action->setData(MPlayer::VideoWidget::AspectRatioAuto);
	ui->video_aspect_widget_action->setData(MPlayer::VideoWidget::AspectRatioWidget);
	ui->video_aspect_4_3_action->setData(static_cast<double>(4) / 3);
	ui->video_aspect_16_9_action->setData(static_cast<double>(16) / 9);
	ui->video_aspect_2_35_1_action->setData(2.35 / 1);
	m_videoAspectActions->addAction(ui->video_aspect_auto_action);
	m_videoAspectActions->addAction(ui->video_aspect_widget_action);
	m_videoAspectActions->addAction(ui->video_aspect_4_3_action);
	m_videoAspectActions->addAction(ui->video_aspect_16_9_action);
	m_videoAspectActions->addAction(ui->video_aspect_2_35_1_action);
	
	ui->video_crop_off_action->setData(MPlayer::VideoWidget::CropOff);
	ui->video_crop_4_3_action->setData(static_cast<double>(4) / 3);
	ui->video_crop_16_9_action->setData(static_cast<double>(16) / 9);
	ui->video_crop_2_35_1_action->setData(2.35 / 1);
	m_videoCropActions->addAction(ui->video_crop_off_action);
	m_videoCropActions->addAction(ui->video_crop_4_3_action);
	m_videoCropActions->addAction(ui->video_crop_16_9_action);
	m_videoCropActions->addAction(ui->video_crop_2_35_1_action);
	
	m_subtitleListActions->addAction(ui->subtitle_disable_action);
	m_subtitleListActions->setExclusive(false);
	connect(m_subout, SIGNAL(subtitleListChanged(const QStringList&)), this,
			SLOT(updateSubtitleList(const QStringList&)));
	connect(m_subout, SIGNAL(currentIndexesChanged(const QList<int>&)),
			this, SLOT(updateCurrentSubtitleIndexes(const QList<int>&)));

	menuBar()->insertSeparator(ui->help_menu->menuAction());
	
	addDockWidget(Qt::RightDockWidgetArea, m_pld);
	m_pld->setPlayList(m_recent->playList());
	m_pld->hide();
	
	QList<QWidget *> tools;
	#define addToolButton(act) {\
	QToolButton *tb = new QToolButton(m_pmb); tb->setAutoRaise(true); \
	tb->setFocusPolicy(Qt::NoFocus); tb->setIconSize(QSize(16, 16)); \
	tb->setDefaultAction(act); tools.append(tb);}
	addToolButton(ui->play_previous_action);
	addToolButton(ui->play_pause_action);
	addToolButton(ui->play_stop_action);
	addToolButton(ui->play_next_action);
	tools.append(new MPlayer::SeekSlider(m_engine, m_pmb));
	addToolButton(ui->audio_mute_action);
	tools.append(new MPlayer::VolumeSlider(m_audio, m_pmb));
	#undef makeToolButton
	m_pmb->init(tools);
	connect(m_engine, SIGNAL(totalTimeChanged(qint64)), m_pmb, SLOT(setTotalTime(qint64)));
	connect(m_engine, SIGNAL(tick(qint64)), m_pmb, SLOT(setCurrentTime(qint64)));
	ui->play_bar->layout()->setMargin(0);
	ui->play_bar->layout()->setSpacing(0);
	ui->play_bar->addWidget(m_pmb);
	
	connect(m_engine, SIGNAL(stateChanged(MPlayer::State, MPlayer::State)),
			this, SLOT(slotStateChanged(MPlayer::State)));
	connect(m_subout, SIGNAL(syncDelayChanged(int)), this, SLOT(updateSyncDelay(int)));
	connect(m_audio, SIGNAL(mutedChanged(bool)), ui->audio_mute_action, SLOT(setChecked(bool)));
	connect(m_video, SIGNAL(resized(const QSize&)), this, SLOT(slotResized()));
	connect(m_video, SIGNAL(sizeHintChanged(const QSize&)), ui->video_size_100_action, SLOT(trigger()));
	connect(m_recent, SIGNAL(filesChanged(const RecentStack&)),
			this, SLOT(updateRecentActions(const RecentStack&)));
	connect(m_recent, SIGNAL(rememberCountChanged(int)), this, SLOT(updateRecentActionsSize(int)));
	connect(m_video, SIGNAL(customContextMenuRequested(const QPoint&)),
			this, SLOT(showMouseMenu(const QPoint&)));
	connect(m_pld, SIGNAL(visibilityChanged(bool)), this, SLOT(adjustSizeForDock(bool)));
	m_video->setContextMenuPolicy(Qt::CustomContextMenu);	
	setMouseTracking(true);
	setAcceptDrops(true);
	setCentralWidget(m_video);
	m_repeater->setPlayEngine(m_engine);
	setWindowTitle(trUtf8("CMP") + ' ' + Helper::version());
	registerActions();	
	updateRecentActions(m_recent->files());
	menuBar()->hide();
	resize(300, 200);
	if (!file.isEmpty() && Helper::exists(file))
		open(file);
}

MainWindow::~MainWindow() {
	delete ui;
}

void MainWindow::showMouseMenu(const QPoint &pos) {
	ActionCollection::get()->mouseMenu()->exec(m_video->mapToGlobal(pos));
}

void MainWindow::togglePlayListVisibility() {
	m_pld->setVisible(m_pld->isHidden());
}

void MainWindow::registerActions() {
	mouseClickActions[Preferences::Interface::ToggleFullScreen] = ui->video_fullscreen_action;
	mouseClickActions[Preferences::Interface::ToggleCompacMode] = ui->video_compact_mode_action;
	mouseClickActions[Preferences::Interface::TogglePlayPause] = ui->play_pause_action;
	wheelScrollActions[Preferences::Interface::ForwardBackward]
			= qMakePair(ui->play_forward_action, ui->play_backward_action);
	wheelScrollActions[Preferences::Interface::ForwardBackwardMore]
			= qMakePair(ui->play_forward_more_action, ui->play_backward_more_action);
	wheelScrollActions[Preferences::Interface::ForwardBackwardMuchMore]
			= qMakePair(ui->play_forward_much_more_action, ui->play_backward_much_more_action);
	wheelScrollActions[Preferences::Interface::VolumeUpDown]
			= qMakePair(ui->audio_volume_up_action, ui->audio_volume_down_action);
	
	ActionCollection *ac = ActionCollection::get();
	QList<QAction *> acts = menuBar()->actions();
	ac->addActions(acts);
	QMenu *wholeMenu = new QMenu(this);
	wholeMenu->addActions(acts);
	QMenu *mouseMenu = new QMenu(this);
	MenuTreeReader reader;
	if (!reader.read(mouseMenu, Preferences::Interface::mouseMenuFile())) {
		mouseMenu->addAction(ui->file_open_action);
		mouseMenu->addMenu(ui->file_recent_menu);
		mouseMenu->addSeparator();
		mouseMenu->addMenu(ui->video_on_top_menu);
		mouseMenu->addMenu(ui->video_size_menu);
		mouseMenu->addMenu(ui->video_aspect_menu);
		mouseMenu->addMenu(ui->video_crop_menu);
		mouseMenu->addAction(ui->video_equalizer_action);
		mouseMenu->addSeparator();
		mouseMenu->addAction(ui->play_show_playlist_action);
		mouseMenu->addMenu(ui->play_ab_menu);
		mouseMenu->addSeparator();
		mouseMenu->addMenu(ui->subtitle_select_menu);
		mouseMenu->addAction(ui->subtitle_add_action);
		mouseMenu->addMenu(ui->subtitle_pos_menu);
		mouseMenu->addMenu(ui->subtitle_sync_menu);
		mouseMenu->addSeparator();
		mouseMenu->addAction(ui->option_preferences_action);
		mouseMenu->addSeparator();
		mouseMenu->addAction(ui->about_qt_action);
		mouseMenu->addAction(ui->about_cmp_action);
		mouseMenu->addSeparator();
		mouseMenu->addAction(ui->file_exit_action);
	}
	ac->setWholeMenu(wholeMenu);
	ac->setMouseMenu(mouseMenu);
	addActions(ac->actions());
	
	m_subSelMenu = findMenuIn(mouseMenu, ui->subtitle_select_menu->title());
	if (!m_subSelMenu)
		m_subSelMenu = ui->subtitle_select_menu;
	m_recentMenu = findMenuIn(mouseMenu, ui->file_recent_menu->title());
	if (!m_recentMenu)
		m_recentMenu = ui->file_recent_menu;
	
	const QMap<QString, QKeySequence> &shortcuts = Preferences::get()->interface().shortcuts;
	for (QMap<QString, QKeySequence>::const_iterator it = shortcuts.begin(); it != shortcuts.end(); ++it) {
		QAction *act = ac->action(it.key());
		if (act)
			act->setShortcut(it.value());
	}
}

void MainWindow::changeStaysOnTop(QAction *act) {
	m_staysOnTop = StaysOnTop(act->data().toInt());
	updateStaysOnTop();
}

void MainWindow::updatePlayText() {
	QString name = QFileInfo(m_engine->currentSource().fileName()).fileName();
	const int row = m_pld->currentRow();
	const int count = m_pld->count();
	if (row != -1 && count && row < count)
		name += QString(" (%1/%2)").arg(row + 1).arg(count);
	name += " - ";
	name += trUtf8(m_engine->isPlaying() ? "재생중" : m_engine->isPaused() ? "일시정지" : "정지");
	m_pmb->setPlayText(name);
}

void MainWindow::updateStaysOnTop() {
	Qt::WindowFlags f = windowFlags();
	bool wasOnTop =  f & Qt::WindowStaysOnTopHint;
	bool wasVisible = isVisible();
	bool isOnTop = (m_staysOnTop == AlwaysOnTop)
		|| (m_staysOnTop == OnlyPlaying && m_engine->state() == MPlayer::PlayingState);
	if (wasOnTop != isOnTop) {
		if (isOnTop)
			f |= Qt::WindowStaysOnTopHint;
		else
			f &= ~Qt::WindowStaysOnTopHint;
		setWindowFlags(f);
		setVisible(wasVisible);
	}
}

void MainWindow::clearRecentFiles() {
	m_recent->clearStack();
}

void MainWindow::updateRecentActionsSize(int size) {
	static ActionCollection *ac = ActionCollection::get();
	while (size != m_recentActions.size()) {
		if (size > m_recentActions.size()) {
			static QAction *sprt = m_recentMenu->actions()[0];
			QAction *act = new QAction(m_recentMenu);
			connect(act, SIGNAL(triggered()), this, SLOT(openRecent()));
			m_recentMenu->insertAction(sprt, act);
			m_recentActions.append(act);
		} else
			delete ac->take(m_recentActions.takeLast());
	}
	for (int i=0; i<m_recentActions.size(); ++i) {
		ac->addAction(trUtf8("최근 연 파일 %1").arg(i+1), ac->take(m_recentActions[i]));
	}
}

void MainWindow::updateRecentActions(const RecentStack &files) {
	const int count = files.size();
	if (count != m_recentActions.size())
		updateRecentActionsSize(count);
	for (int i=0; i<count; ++i) {
		QAction *act = m_recentActions[i];
		act->setData(files[i]);
		act->setText(Helper::fileName(files[i]));
		act->setVisible(!files[i].isEmpty());
	}
}

void MainWindow::openRecent() {
	QAction *act = qobject_cast<QAction *>(sender());
	if (act) {
		open(act->data().toString());
	}
}

void MainWindow::slotResized() {
	if (!m_userSize && !isFullScreen()) {
		ui->video_size_user_action->setChecked(m_userSize = true);
	}
}

void MainWindow::updateSyncDelay(int msec) {
	ui->subtitle_sync_current_action->setText(trUtf8("현재값: %1").arg(static_cast<double>(msec)/1000));
}

void MainWindow::crop(QAction *act) {
	m_video->crop(act->data().toDouble());
}

void MainWindow::showPreferencesDialog() {
	Preferences::SettingsDialog dlg(this);
	if (dlg.exec()) {
		m_engine->restart();
	}
}

void MainWindow::clearSubtitleList() {
	QList<QAction *> acts = m_subtitleListActions->actions();
	for (int i=0; i<acts.size()-1; ++i) {
		m_subtitleListActions->removeAction(acts[i]);
		delete acts[i];
	}
	m_subtitleListActions->removeAction(ui->subtitle_disable_action);
	ui->subtitle_disable_action->setVisible(false);
}

void MainWindow::updateCurrentSubtitleIndexes(const QList<int> &indexes) {
	ui->subtitle_disable_action->setChecked(!indexes.size());
	QList<QAction *> act = m_subtitleListActions->actions();
	for (int i=0; i<act.size()-1; ++i)
		act[i]->setChecked(indexes.contains(i));
}

void MainWindow::updateSubtitleList(const QStringList &files) {
	clearSubtitleList();
	const int count = files.size();
	const QList<int> &indexes = m_subout->currentIndexes();
	for (int i=0; i<count; ++i) {
		QAction *act = m_subSelMenu->addAction(QFileInfo(files[i]).fileName());
		act->setCheckable(true);
		act->setData(i);
		act->setChecked(indexes.contains(i));
		m_subtitleListActions->addAction(act);
	}
	m_subtitleListActions->addAction(ui->subtitle_disable_action);
	ui->subtitle_disable_action->setVisible(count);
	ui->subtitle_clear_action->setEnabled(count);
}

void MainWindow::addSubtitles() {
	static const QString Filter
		= trUtf8("자막 파일") + ' ' + MPlayer::Informations::get()->subtitleFilter().toFilter() + ";;"
		+ trUtf8("모든 파일") + ' ' + "(*.*)";
	const QStringList paths = QFileDialog::getOpenFileNames(this, trUtf8("파일 열기"),
		QString(), Filter);
	if (paths.size())
		m_subout->appendSubtitles(paths, true);
}

QMenu *MainWindow::findMenuIn(QMenu *menu, const QString &title) {
	QList<QAction*> acts = menu->actions();
	for (int i=0; i<acts.size(); ++i) {
		if (acts[i]->menu()) {
			if (acts[i]->text() != title) {
				QMenu *m = findMenuIn(acts[i]->menu(), title);
				if (m)
					return m;
			} else
				return acts[i]->menu();
		}
	}
	return 0;
}

void MainWindow::showEqualizer() {
	EqualizerDialog dlg(m_video, this);
	dlg.exec();
}

void MainWindow::changeCurrentSubtitles(QAction* act) {
	if (act != ui->subtitle_disable_action) {
		if (act->isChecked()) {
			m_subout->appendCurrentIndex(act->data().toInt());
		} else
			m_subout->removeCurrentIndex(act->data().toInt());
	} else
		m_subout->setCurrentIndexes(QList<int>());
}

void MainWindow::setFullScreen(bool full) {
	if (full == isFullScreen())
		return;
	static bool wasCompact = false;
	if (full) {
		wasCompact = isCompactMode();
		setCompactMode(true);
		m_pld->hide();
		setWindowState(windowState() ^ Qt::WindowFullScreen);
	} else {
		setWindowState(windowState() ^ Qt::WindowFullScreen);
		setCompactMode(wasCompact);
	}
	m_engine->setFullScreenState(full);
	m_videoSizeActions->setDisabled(full);
}

void MainWindow::setCompactMode(bool compact) {
	if (!compact && isFullScreen())
		return;
	if (isCompactMode() != compact) {
		if (compact)
			m_pld->hide();
		ui->play_bar->setHidden(compact);
		m_compact = compact;
	}
}

void MainWindow::changeVideoSize(QAction *act) {
	setVideoSize(act->data().toDouble());
}

void MainWindow::setVideoSize(double rate) {
	if (rate > 0.0)
		resize(size() + m_video->sizeHint()*std::sqrt(rate) - m_video->size());
	m_userSize = rate < 0.0;
}

void MainWindow::slotStateChanged(MPlayer::State /*state*/) {
	if (m_engine->isPlaying()) {
		ui->play_pause_action->setIcon(QIcon(":/img/media-playback-pause.png"));
		ui->play_pause_action->setText(trUtf8("일시정지"));
	} else {
		ui->play_pause_action->setIcon(QIcon(":/img/media-playback-start.png"));
		ui->play_pause_action->setText(trUtf8("재생"));
	}
	updatePlayText();
	updateStaysOnTop();
}

void MainWindow::hideEvent(QHideEvent *event) {
	QMainWindow::hideEvent(event);
	if (m_pref->general().pauseWhenMinimized && m_engine->isPlaying()) {
		m_engine->pause();
		m_pausedByHiding = true;
	}
}

void MainWindow::showEvent(QShowEvent *event) {
	QMainWindow::showEvent(event);
	if (m_pausedByHiding && m_pref->general().playWhenRestored) {
		m_engine->play();
		m_pausedByHiding = false;
	}
}

void MainWindow::closeEvent(QCloseEvent *event) {
	QMainWindow::closeEvent(event);
	m_engine->stop();
	m_recent->setPlayList(m_pld->playList());
	m_recent->save();
}

void MainWindow::changeAspectRatio(QAction *act) {
	m_video->setAspectRatio(act->data().toDouble());
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event) {
	return QMainWindow::eventFilter(obj, event);
}
	
void MainWindow::open() {
	static const MPlayer::Informations *info = MPlayer::Informations::get();
	static const QString Filter = trUtf8("비디오 파일") +' ' + info->videoExtensions().toFilter() + ";;"
			+ trUtf8("음악 파일") + ' ' + info->audioExtensions().toFilter() + ";;"
			+ trUtf8("모든 파일") + ' ' + "(*.*)";
	const QString file = QFileDialog::getOpenFileName(this, trUtf8("파일 열기"), QString(), Filter);
	if (!file.isEmpty())
		open(file);
}

void MainWindow::open(const QString &file) {
	static const QStringList NameFilter =
			MPlayer::Informations::get()->videoExtensions().toNameFilter();
	m_pld->clear();
	const QFileInfo info(file);
	if (m_pref->general().autoAddFiles != Preferences::General::DoNotAddFiles) {
		QString fileName = Helper::fileName(file);
		QStringList files = info.dir().entryList(NameFilter, QDir::Files, QDir::Name);
		bool all = m_pref->general().autoAddFiles == Preferences::General::AllFiles;
		bool prefix = false, suffix = false;
		for(QStringList::const_iterator it = files.begin(); it != files.end(); ++it) {
			if (!all) {
				static QRegExp rxs("(\\D*)\\d+(.*)");
				static QRegExp rxt("(\\D*)\\d+(.*)");
				if (rxs.indexIn(fileName) == -1 || rxt.indexIn(*it) == -1)
					continue;
				if (!prefix && !suffix) {
					if (rxs.cap(1) == rxt.cap(1))
						prefix = true;
					else if (rxs.cap(2) == rxt.cap(2))
						suffix = true;
					else
						continue;
				} else if (prefix) {
					if (rxs.cap(1) != rxt.cap(1))
						continue;
				} else if (suffix) {
					if (rxs.cap(2) != rxt.cap(2))
						continue;
				}
			}
			m_pld->add(info.path() + '/' + *it);
		}
	}
	m_pld->play(file);
	m_recent->stackFile(file);
}

void MainWindow::showAboutDialog() {
	QDialog dlg(this);
	Ui::Ui_AboutDialog ui;
	ui.setupUi(&dlg);
	dlg.exec();
}

void MainWindow::mouseMoveEvent(QMouseEvent *event) {
	QMainWindow::mouseMoveEvent(event);
	if (m_dragMove && event->buttons() & Qt::LeftButton)
		move(event->globalPos() - m_dragPos);
	if (isCompactMode()) {
		static const int h = m_pmb->height();
		QRect r = this->rect();
		r.setTop(r.height() - h);
		ui->play_bar->setVisible(r.contains(event->pos()));
	}
}

void MainWindow::mousePressEvent(QMouseEvent *event) {
	QMainWindow::mouseMoveEvent(event);
	bool inCentral = m_video->geometry().contains(event->pos());
	m_dragMove = event->buttons() & Qt::LeftButton && inCentral && !isFullScreen();
	if (m_dragMove)
		m_dragPos = event->globalPos() - frameGeometry().topLeft();
	if (event->button() == Qt::MidButton && inCentral)
		mouseClickActions[m_pref->interface().middleClickAction]->trigger();
}

void MainWindow::mouseDoubleClickEvent(QMouseEvent *event) {
	QMainWindow::mouseDoubleClickEvent(event);
	if (event->button() == Qt::LeftButton
			&& m_video->geometry().contains(event->pos()))
		mouseClickActions[m_pref->interface().doubleClickAction]->trigger();
}

void MainWindow::wheelEvent(QWheelEvent *event) {
	int d = event->delta();
	if (d > 0)
		wheelScrollActions[m_pref->interface().wheelScrollAction].first->trigger();
	else if (d < 0)
		wheelScrollActions[m_pref->interface().wheelScrollAction].second->trigger();
	else
		event->ignore();
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event) {
	if (event->mimeData()->hasUrls())
		event->acceptProposedAction();
}

void MainWindow::dropEvent(QDropEvent *event) {
	if (!event->mimeData()->hasUrls())
		return;
	QList<QUrl> urls = event->mimeData()->urls();
	if (urls.size()) {
		if (urls[0].scheme() == "file") {
			m_engine->play(urls[0].toLocalFile());
		}
	}
}

void MainWindow::increaseVolume() {
	m_audio->setVolume(m_pref->interface().volumeStep, true);
}

void MainWindow::decreaseVolume() {
	m_audio->setVolume(-m_pref->interface().volumeStep, true);
}

void MainWindow::forward() {
	m_engine->seek(m_pref->interface().seekingStep, true);
}

void MainWindow::forwardMore() {
	m_engine->seek(m_pref->interface().seekingMoreStep, true);
}

void MainWindow::forwardMuchMore() {
	m_engine->seek(m_pref->interface().seekingMuchMoreStep, true);
}

void MainWindow::backward() {
	m_engine->seek(-m_pref->interface().seekingStep, true);
}

void MainWindow::backwardMore() {
	m_engine->seek(-m_pref->interface().seekingMoreStep, true);
}

void MainWindow::backwardMuchMore() {
	m_engine->seek(-m_pref->interface().seekingMuchMoreStep, true);
}

void MainWindow::increaseSyncDelay() {
	m_subout->addSyncDelay(m_pref->interface().syncDelayStep);
}

void MainWindow::decreaseSyncDelay() {
	m_subout->addSyncDelay(-m_pref->interface().syncDelayStep);
}

void MainWindow::stepDownSubtitle() {
	m_subout->moveSubtitle(subPosStep);
}

void MainWindow::stepUpSubtitle() {
	m_subout->moveSubtitle(-subPosStep);
}

void MainWindow::togglePlayPause() {
	m_engine->isPlaying() ? m_engine->pause() : m_engine->play();
}

void MainWindow::selectABSection() {
	static bool a = false, b = false;
	if (m_repeater->isRepeating())
		a = b = false;
	if (a && !b) {
		m_repeater->setBToCurrentTime();
		b = true;
		m_repeater->start();
		a = b = false;
	} else if (!a) {
		m_repeater->setAToCurrentTime();
		m_repeater->stop();
		a = true;
	}
}

void MainWindow::showABRepeatDialog() {
	static ABRepeatDialog *dlg = new ABRepeatDialog(this);
	dlg->show();
}

void MainWindow::adjustSizeForDock(bool visible) {
	if (!isFullScreen() && !m_pld->isFloating())
		resize(width() + (visible ? 1 : -1 ) * m_pld->width(), height());
}

