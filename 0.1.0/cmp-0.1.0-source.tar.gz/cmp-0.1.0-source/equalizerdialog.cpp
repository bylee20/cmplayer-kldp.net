#include "equalizerdialog.h"
#include "ui_equalizerdialog.h"
#include "mplayer/videowidget.h"

EqualizerDialog::EqualizerDialog(MPlayer::VideoWidget *video, QWidget *parent)
: QDialog(parent), ui(new Ui::Ui_EqualizerDialog), m_video(video), m_brightness(video->brightness())
, m_contrast(video->contrast()), m_gamma(video->gamma())
, m_hue(video->hue()), m_saturation(video->saturation()) {
	ui->setupUi(this);
	connect(ui->brightness_spin, SIGNAL(valueChanged(int)), this, SLOT(setBrightness(int)));
	connect(ui->contrast_spin, SIGNAL(valueChanged(int)), this, SLOT(setContrast(int)));
	connect(ui->gamma_spin, SIGNAL(valueChanged(int)), this, SLOT(setGamma(int)));
	connect(ui->hue_spin, SIGNAL(valueChanged(int)), this, SLOT(setHue(int)));
	connect(ui->saturation_spin, SIGNAL(valueChanged(int)), this, SLOT(setSaturation(int)));
	connect(ui->reset_button, SIGNAL(clicked()), this, SLOT(resetValues()));
	connect(ui->default_button, SIGNAL(clicked()), this, SLOT(setValuesDefault()));
}

EqualizerDialog::~EqualizerDialog() {
	delete ui;
}

void EqualizerDialog::setBrightness(int value) {
	m_video->setBrightness(value);
	ui->brightness_spin->setValue(m_video->brightness());
}

void EqualizerDialog::setContrast(int value) {
	m_video->setContrast(value);
	ui->contrast_spin->setValue(m_video->contrast());
}

void EqualizerDialog::setGamma(int value) {
	m_video->setGamma(value);
	ui->gamma_spin->setValue(m_video->gamma());
}

void EqualizerDialog::setHue(int value) {
	m_video->setHue(value);
	ui->hue_spin->setValue(m_video->hue());
}

void EqualizerDialog::setSaturation(int value) {
	m_video->setSaturation(value);
	ui->saturation_spin->setValue(m_video->saturation());
}

void EqualizerDialog::showEvent(QShowEvent *event) {
	QDialog::showEvent(event);
	m_brightness = ui->brightness_spin->value();
	m_contrast = ui->contrast_spin->value();
	m_gamma = ui->gamma_spin->value();
	m_hue = ui->hue_spin->value();
	m_saturation = ui->saturation_spin->value();
}

void EqualizerDialog::resetValues() {
	ui->brightness_spin->setValue(m_brightness);
	ui->contrast_spin->setValue(m_contrast);
	ui->gamma_spin->setValue(m_gamma);
	ui->hue_spin->setValue(m_hue);
	ui->saturation_spin->setValue(m_saturation);
}

void EqualizerDialog::setValuesDefault() {
	ui->brightness_spin->setValue(0);
	ui->contrast_spin->setValue(0);
	ui->gamma_spin->setValue(0);
	ui->hue_spin->setValue(0);
	ui->saturation_spin->setValue(0);
}
