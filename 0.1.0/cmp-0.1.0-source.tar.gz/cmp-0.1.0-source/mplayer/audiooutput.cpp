#include "audiooutput.h"
#include "playengine.h"

namespace MPlayer {

AudioOutput::AudioOutput(QObject *parent)
: QObject(parent), m_engine(0), m_muted(false), m_volume(100) {}

AudioOutput::~AudioOutput() {}

void AudioOutput::setVolume(int volume, bool relative) {
	int temp = qBound(0, relative ? m_volume + volume : volume, 100);
	if (m_engine && m_engine->tellmp("volume " + QString::number(temp) + " 1"))
		emit volumeChanged(m_volume = temp);
}

void AudioOutput::setMuted(bool muted) {
	if (m_engine && m_engine->tellmp("mute " + QString::number(muted ? 1 : 0))) {
		if (m_muted != muted)
			emit mutedChanged(m_muted = muted);
	}
}

}
