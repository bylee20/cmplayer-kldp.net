#ifndef MPLAYERSUBTITLEMANAGER_H
#define MPLAYERSUBTITLEMANAGER_H

#include <QObject>

class Subtitle;

namespace MPlayer {

class PlayEngine;

class SubtitleOutput : public QObject {
	Q_OBJECT
public:
	SubtitleOutput(QObject *parent = 0);
	~SubtitleOutput();
	void initSubtitles(const QStringList &files);
	void appendSubtitles(const QStringList &files, bool display);
	void setSubtitleList(const QStringList &files);
	inline const QList<Subtitle> &subtitleList() const {return m_subtitles;}	
	void removeCurrentIndex(int index);
	void setCurrentIndexes(const QList<int> &indexes);
	inline void appendCurrentIndex(int index) {appendCurrentIndexes(QList<int>() << index);}
	void appendCurrentIndexes(const QList<int> &indexes);
	inline void setCurrentIndex(int index) {setCurrentIndexes(QList<int>() << index);}
	inline const QList<int> &currentIndexes() const {return m_curIdxes;}
	inline const Subtitle &currentSubtitle() const {return *m_cursub;}
	inline int syncDelay() const {return m_delay;}
public slots:
	void moveSubtitle(int dis);
	void setCurrentSubtitle(const Subtitle &sub);
	void clearSubtitles();
	void updateCurrentSubtitle();
	void addSyncDelay(int msec);
	void setSyncDelay(int msec, bool force = false);
signals:
	void subtitleListChanged(const QStringList &files);
	void currentIndexesChanged(const QList<int> &indexes);
	void syncDelayChanged(int);
private:
	friend void connect(PlayEngine *meida, SubtitleOutput *subout);
	inline void setPlayEngine(PlayEngine *engine) {m_engine = engine;}
	PlayEngine *m_engine;
	QString m_tempsub;
	int m_delay;
	Subtitle *m_cursub;
	QList<int> m_curIdxes;
	QList<Subtitle> m_subtitles;
};

}

#endif
