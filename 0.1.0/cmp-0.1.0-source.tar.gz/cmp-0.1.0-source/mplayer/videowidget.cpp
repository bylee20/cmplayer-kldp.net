#include <QEvent>
#include <QPainter>
#include <QTimer>
#include "videowidget.h"
#include "playengine.h"

namespace MPlayer {

VideoWidget::VideoWidget(QWidget *parent)
: QWidget(parent), m_engine(0), m_visual(new QWidget(this)), m_video(new QWidget(m_visual))
, m_mouseTimer(new QTimer(this)), m_cropRatio(CropOff), m_aspectRatio(AspectRatioAuto)
, m_brightness(0), m_contrast(0), m_gamma(0), m_hue(0), m_saturation(0) {
	setMouseTracking(true);
	m_visual->setMouseTracking(true);
	m_visual->move(0, 0);
	m_visual->resize(40, 30);
	
	m_video->setMouseTracking(true);
	m_video->setAutoFillBackground(true);
	m_video->setAttribute(Qt::WA_NoSystemBackground);
	m_video->setAttribute(Qt::WA_StaticContents);
	m_video->setAttribute(Qt::WA_PaintOnScreen);
	m_video->setAttribute(Qt::WA_PaintUnclipped);
	m_videoSize.scale(4, 3, Qt::IgnoreAspectRatio);
	m_video->resize(40, 30);
	m_video->installEventFilter(this);
	
	m_mouseTimer->setSingleShot(true);
	m_mouseTimer->setInterval(3000);
	connect(m_mouseTimer, SIGNAL(timeout()), this, SLOT(hideCursor()));
}

bool VideoWidget::eventFilter(QObject *obj, QEvent *event) {
	if (obj == m_video && event->type() == QEvent::Paint && (!m_engine || m_engine->isStopped())) {
		drawBackground(m_video);
		return true;
	} else
		return QWidget::eventFilter(obj, event);
}
	
void VideoWidget::drawBackground(QWidget *widget, const QColor &color) {
	QPainter painter(widget);
	painter.fillRect(widget->rect(), color);
}

void VideoWidget::resizeEvent(QResizeEvent *event) {
	QWidget::resizeEvent(event);
	updateVisual();
	emit resized(size());
}


void VideoWidget::paintEvent(QPaintEvent *event) {
	QWidget::paintEvent(event);
	drawBackground(this);
}

void VideoWidget::mouseMoveEvent(QMouseEvent *event) {
	QWidget::mouseMoveEvent(event);
	m_mouseTimer->stop();
	if (cursor().shape() != Qt::ArrowCursor)
		setCursor(Qt::ArrowCursor);
	m_mouseTimer->start();
}

void VideoWidget::scaleWidget(QWidget *widget, int w, int h, Qt::AspectRatioMode mode) {
	QSize size(widget->size());
	if (w > 0 && h > 0) {
		size.scale(w, h, mode);
		widget->resize(size);
	} else
		widget->resize(w, h);
}


void VideoWidget::updateVisual() {
	qreal ratio;
	if (isSame(m_aspectRatio, AspectRatioAuto))
		ratio = static_cast<qreal>(m_videoSize.width()) / m_videoSize.height();
	else if (isSame(m_aspectRatio, AspectRatioWidget))
		ratio = static_cast<qreal>(width()) / height();
	else
		ratio = m_aspectRatio;
	int backw = m_visual->width();
	int backh = m_visual->height();
	int w = m_video->width(), h = m_video->height(), x = 0, y = 0;
	if (ratio > 0.0) {
		double backRatio = static_cast<qreal>(backw) /backh;
		if (backRatio > ratio) {
			w = static_cast<int>(h*ratio);
			x = (backw - w)/2;
		} else {
			h = static_cast<int>(w/ratio);
			y = (backh - h)/2;
		}
		m_video->resize(w, h);
	}
	
	backw = width();
	backh = height();
	w = m_visual->width();
	h = m_visual->height();
	if (cropOn()) {
		double backRatio = static_cast<qreal>(backw) / backh;
		if (backRatio > m_cropRatio)
			w = static_cast<int>(h * m_cropRatio);
		else
			h = static_cast<int>(w / m_cropRatio);
		m_visual->resize(w, h);
		scaleWidget(m_visual, backw, backh, Qt::KeepAspectRatio);
		w = m_visual->width();
		h = m_visual->height();
		scaleWidget(m_video, w, h, Qt::KeepAspectRatioByExpanding);
	} else {
		m_visual->resize(w = backw, h = backh);
		scaleWidget(m_video, w, h, Qt::KeepAspectRatio);
	}
	m_visual->move((backw-w)/2, (backh-h)/2);
	m_video->move((w-m_video->width())/2, (h-m_video->height())/2);
}

QSize VideoWidget::sizeHint() const {
	if (cropOn()) {
		QSize hint = m_visual->size();
		hint.scale(m_videoSize, Qt::KeepAspectRatio);
		return hint;
	} else
		return m_videoSize;
}

void VideoWidget::setPlayEngine(PlayEngine *engine) {
	m_engine = engine;
	connect(engine, SIGNAL(videoSizeChanged(const QSize&)), this, SLOT(setVideoSize(const QSize&)));
}

void VideoWidget::setBrightness(int value) {
	int temp = qBound(-100, value, 100);
	if (m_engine && m_engine->tellmp("brightness " + QString::number(temp) + " 1"))
		m_brightness = temp;
}

void VideoWidget::setContrast(int value) {
	int temp = qBound(-100, value, 100);
	if (m_engine && m_engine->tellmp("contrast " + QString::number(temp) + " 1"))
		m_contrast = temp;
}

void VideoWidget::setGamma(int value) {
	int temp = qBound(-100, value, 100);
	if (m_engine && m_engine->tellmp("gamma " + QString::number(temp) + " 1"))
		m_gamma = temp;
}

void VideoWidget::setHue(int value) {
	int temp = qBound(-100, value, 100);
	if (m_engine && m_engine->tellmp("hue " + QString::number(temp) + " 1"))
		m_hue = temp;
}

void VideoWidget::setSaturation(int value) {
	int temp = qBound(-100, value, 100);
	if (m_engine && m_engine->tellmp("saturation " + QString::number(temp) + " 1"))
		m_saturation = temp;
}

}
