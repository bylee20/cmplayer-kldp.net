#ifndef MPLAYERVIDEOWIDGET_H
#define MPLAYERVIDEOWIDGET_H

#include <QWidget>

namespace MPlayer {

class PlayEngine;

class VideoWidget : public QWidget {
	Q_OBJECT
public:
	static const qreal CropOff = 0.0;
	static const qreal AspectRatioAuto = -1.0;
	static const qreal AspectRatioWidget = 0.0;
	VideoWidget(QWidget *parent = 0);
	inline MPlayer::PlayEngine *playEngine() const {return m_engine;}
	virtual QSize sizeHint() const;
	inline const QSize &videoSize() const {return m_videoSize;}
	inline qreal aspectRatio() const {return m_aspectRatio;}
	inline qreal cropRatio() const {return m_cropRatio;}
	inline bool cropOn() const {return !isSame(CropOff, m_cropRatio);}
	inline int videoWID() const {return int(m_video->winId());}
	inline int brightness() const {return m_brightness;}
	inline int contrast() const {return m_contrast;}
	inline int gamma() const {return m_gamma;}
	inline int hue() const {return m_hue;}
	inline int saturation() const {return m_saturation;}
public slots:
	void updateVisual();
	void crop(qreal ratio) {m_cropRatio = ratio; updateVisual();}
	void setAspectRatio(qreal ratio) {m_aspectRatio = ratio; updateVisual();}
	void setBrightness(int value);
	void setContrast(int value);
	void setGamma(int value);
	void setHue(int value);
	void setSaturation(int value);
	void resetEqualizer() {m_brightness = m_contrast = m_gamma = m_hue = m_saturation = 0;}
signals:
	void sizeHintChanged(const QSize &size);
	void resized(const QSize &size);
protected:
	void resizeEvent(QResizeEvent *event);
	void mouseMoveEvent(QMouseEvent *event);
	void paintEvent(QPaintEvent *event);
	bool eventFilter(QObject *obj, QEvent *event);
private slots:
	inline void hideCursor() {if (cursor().shape() != Qt::BlankCursor) setCursor(Qt::BlankCursor);}
	inline void setVideoSize(const QSize &size) {
		if (size != m_videoSize) {emit sizeHintChanged(m_videoSize = size); updateVisual();}}
private:
	friend void connect(PlayEngine *engine, VideoWidget *video);
	inline static bool isSame(qreal n1, qreal n2, qreal prec = 0.001) {return qAbs(n1 - n2) < prec;}
	static void scaleWidget(QWidget *widget, int w, int h, Qt::AspectRatioMode mode);
	void setPlayEngine(PlayEngine *engine);
	void drawBackground(QWidget *widget, const QColor &color = Qt::black);
	MPlayer::PlayEngine *m_engine;
	QWidget *m_visual, *m_video;
	QTimer *m_mouseTimer;
	qreal m_cropRatio, m_aspectRatio;
	int m_brightness, m_contrast, m_gamma, m_hue, m_saturation;
	QSize m_videoSize;
};

}



#endif

