#ifndef MPLAYERINFORMATIONS_H
#define MPLAYERINFORMATIONS_H

#include <QStringList>
#include <singletoninterface.h>

namespace MPlayer {

class Informations : public SingletonInterface<Informations> {
	SINGLE(Informations)
	class Extensions : public QStringList {
	public:
		QString toFilter() const;
		QStringList toNameFilter() const;
	};
public:
	inline const QStringList &videoOutputs() const {if (!m_vos.size()) getInfo(); return m_vos;}
	inline const QStringList &audioOutputs() const {if (!m_aos.size()) getInfo(); return m_aos;}
	inline const Extensions &videoExtensions() const {return m_ves;}
	inline const Extensions &audioExtensions() const {return m_aes;}
	inline const Extensions &subtitleFilter() const {return m_ses;}
	inline bool isPlayable(const QString ex) const {return m_ves.contains(ex) || m_aes.contains(ex);}
private:
	void getInfo() const;
	Informations();
	mutable QStringList m_vos, m_aos;
	Extensions m_ves, m_aes, m_ses;
};

}

#endif
