#ifndef MPLAYERPLAYENGINE_H
#define MPLAYERPLAYENGINE_H

#include <QObject>
#include "mplayer.h"

class QStringList;			class QProcess;
class QSize;

namespace Preferences {class Settings;}

namespace MPlayer {

class MediaSource;				class VideoWidget;
class SubtitleOutput;			class AudioOutput;

class PlayEngine : public QObject {
	Q_OBJECT
public:
	PlayEngine(QObject *parent);
	~PlayEngine();
	inline const MediaSource &currentSource() const {return *m_source;}
	inline qint64 currentTime() const {return m_curTime;}
	inline bool hasVideo() const {return !m_noVideo;}
	inline bool isSeekable() const {return m_state != StoppedState;}
	inline qint64 remainingTime() const {return m_totalTime - m_curTime;}
	inline State state() const {return m_state;}
	inline qint32 tickInterval() const {return 100;}
	inline qint64 totalTime() const {return m_totalTime;}
	void setFullScreenState(bool full);
	void expand(qreal ratio);
	inline bool isPlaying() const {return state() == PlayingState;}
	inline bool isPaused() const {return state() == PausedState;}
	inline bool isStopped() const {return state() == StoppedState;}
	bool tellmp(const QString &command);
	inline VideoWidget *videoWidget() const {return m_video;}
	inline SubtitleOutput *subtitleOutput() const {return m_subout;}
	bool isRunning();
public slots:
	void setCurrentSource(const MediaSource &source);
	void play(const QString &source);
	void stop();
	inline void pause() {if (isPlaying())tellmp("pause");}
	inline void play() {if (isPaused()) tellmp("pause"); else if (isStopped()) start();}
	inline void play(const MediaSource &source) {setCurrentSource(source); start();}
	inline void seek(qint64 time, bool relative = false) {
		tellmp("seek " + QString::number(static_cast<double>(time)/1000) + (relative ? " 0" : " 2"));}
	inline void restart() {pause(); m_dontReset = true; start(m_curTime);}
signals:
	void currentSourceChanged(const MPlayer::MediaSource &newSource);
	void finished();
	void hasVideoChanged(bool hasVideo);
	void seekableChanged(bool isSeekable);
	void stateChanged(MPlayer::State newstate, MPlayer::State oldstate);
	void tick(qint64 time);
	void totalTimeChanged(qint64 newTotalTime);
	void videoSizeChanged(const QSize &size);
private slots:
	void interpretMessages();
	void slotStateChanged(MPlayer::State newstate, MPlayer::State oldstate);
	void slotProcFinished();
private:
	friend void connect(PlayEngine *engine, VideoWidget *video);
	friend void connect(PlayEngine *engine, SubtitleOutput *subout);
	friend void connect(PlayEngine *engine, AudioOutput *audio);
	inline void setVideoWidget(VideoWidget *video) {m_video = video;}
	inline void setAudioOutput(AudioOutput *audio) {m_audio = audio;}
	inline void setSubtitleOutput(SubtitleOutput *subout) {m_subout = subout;}
	inline void setState(State state) {
		if (state != m_state) {State old = m_state; emit stateChanged(m_state = state, old);}}
	inline void setCurrentTime(qint64 msec) {emit tick(m_curTime = msec);}
	bool start(qint64 time = 0);
	MediaSource *m_source;
	QProcess *m_proc;
	Preferences::Settings *m_pref;
	VideoWidget *m_video;
	AudioOutput *m_audio;
	SubtitleOutput *m_subout;
	State m_state;
	qint64 m_totalTime, m_curTime;
	bool m_fullScreen, m_dontReset, m_justFinished, m_noVideo;
	QString m_dontmessup, m_dummysub;
};


}

#endif
