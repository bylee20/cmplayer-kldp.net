#include "mplayer.h"
#include "videowidget.h"
#include "playengine.h"
#include "subtitleoutput.h"
#include "audiooutput.h"

namespace MPlayer {

void connect(PlayEngine *engine, VideoWidget *video) {
	engine->setVideoWidget(video);
	video->setPlayEngine(engine);
}

void connect(PlayEngine *engine, SubtitleOutput *subout) {
	engine->setSubtitleOutput(subout);
	subout->setPlayEngine(engine);
}

void connect(PlayEngine *engine, AudioOutput *audio) {
	engine->setAudioOutput(audio);
	audio->setPlayEngine(engine);
}

}
