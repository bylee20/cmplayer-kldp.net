#include <QApplication>
#include <QStringList>
#include <helper.h>
#include <subtitleparsers.h>
#include <preferences.h>
#include <prefsubtitle.h>
#include "mediasource.h"
#include "playengine.h"
#include "subtitleoutput.h"

namespace MPlayer {

SubtitleOutput::SubtitleOutput(QObject *parent)
: QObject(parent), m_engine(0), m_tempsub(qApp->applicationDirPath() + '/' + "donttouch/temp.smi")
, m_delay(0), m_cursub(new Subtitle) { }

SubtitleOutput::~SubtitleOutput() {
	delete m_cursub;
}

void SubtitleOutput::appendSubtitles(const QStringList &files, bool display) {
	QStringList names;
	for (int i=0; i<m_subtitles.size(); ++i)
		names << m_subtitles[i].name();
	int index = m_subtitles.size() - 1;
	for (int i=0; i<files.size(); ++i) {
		SubtitleList subs;
		SubtitleParsers::parse(files[i], &subs, 10);
		m_subtitles += subs;
		for (int i=0; i<subs.size(); ++i) {
			names << subs[i].name();
			if (display)
				m_curIdxes.append(++index);
		}
	}
	emit subtitleListChanged(names);
	if (display)
		setCurrentIndexes(m_curIdxes);
}

void SubtitleOutput::clearSubtitles() {
	if (m_engine && m_engine->tellmp("sub_select -1") && m_engine->tellmp("sub_remove")
			&& !m_subtitles.isEmpty()) {
		m_subtitles.clear();
		emit subtitleListChanged(QStringList());
		m_curIdxes.clear();
		setCurrentIndexes(m_curIdxes);
	}
}

void SubtitleOutput::appendCurrentIndexes(const QList<int> &indexes) {
	m_curIdxes += indexes;
	updateCurrentSubtitle();
	emit currentIndexesChanged(m_curIdxes);
}

void SubtitleOutput::removeCurrentIndex(int index) {
	int pos = m_curIdxes.indexOf(index);
	if (pos != -1) {
		m_curIdxes.removeAt(pos);
		updateCurrentSubtitle();
		emit currentIndexesChanged(m_curIdxes);
	}
}

void SubtitleOutput::setCurrentSubtitle(const Subtitle &sub) {
	*m_cursub = sub;
	if (m_engine && m_engine->tellmp("sub_select -1") && m_engine->tellmp("sub_remove")) {
		QString file;
		if (sub.size()) {
			file = m_tempsub;
			if (!SubtitleParsers::save(m_tempsub, sub))
				return;
		} else
			file = sub.file();
		if (m_engine->tellmp("sub_load \"" + file + '\"'))
			m_engine->tellmp("sub_select 0");
	}
}

void SubtitleOutput::updateCurrentSubtitle() {
	const Preferences::Subtitle &subset = Preferences::get()->subtitle();
	QList<int> order;
	QList<int> indexes = m_curIdxes;
	for (int i=0; i<subset.classes.size(); ++i) {
		QString lang = subset.classes[i];
		QMutableListIterator<int> it(indexes);
		while(it.hasNext()) {
			if (m_subtitles[it.next()].language() == lang) {
				order.append(it.value());
				it.remove();
			}
		}
	}
	order += indexes;
	Subtitle sub;
	QListIterator<int> it(order);
	if (it.hasNext())
		sub = m_subtitles[it.next()];
	while (it.hasNext())
		sub |= m_subtitles[it.next()];
	setCurrentSubtitle(sub);
}

void SubtitleOutput::setCurrentIndexes(const QList<int> &indexes) {
	m_curIdxes = indexes;
	updateCurrentSubtitle();
	emit currentIndexesChanged(m_curIdxes);
}

void SubtitleOutput::initSubtitles(const QStringList &files) {
	if (m_engine && !files.isEmpty()) {
		setSubtitleList(files);
		static const Preferences::Subtitle &subset = Preferences::get()->subtitle();
		QList<int> indexes;
		if (subset.autoSelect == Preferences::Subtitle::SameName) {
			QString source = Helper::baseName(m_engine->currentSource().fileName());
			for (int i=0; i<m_subtitles.size(); ++i)
				if (Helper::baseName(m_subtitles[i].file()) == source)
					indexes.append(i);
		} else if (subset.autoSelect == Preferences::Subtitle::FirstFile) {
			QString file = m_subtitles[0].file();
			indexes.append(0);
			for (int i=1; i<m_subtitles.size(); ++i) {
				if (m_subtitles[i].file() == file)
					indexes.append(i);
				else
					break;
			}
		}
		setCurrentIndexes(indexes);
	} else
		clearSubtitles();
}

void SubtitleOutput::moveSubtitle(int dis) {
	if (m_engine)
		m_engine->tellmp("sub_pos " + QString::number(dis) + " 0");
}

void SubtitleOutput::setSubtitleList(const QStringList &files) {
	m_subtitles.clear();
	appendSubtitles(files, false);
}

void SubtitleOutput::addSyncDelay(int msec) {
	if (m_engine && m_engine->tellmp("sub_delay "
			+ QString::number(static_cast<double>(msec)/1000.0) + " 0"))
		emit syncDelayChanged(m_delay += msec);
}

void SubtitleOutput::setSyncDelay(int msec, bool force) {
	if ((!force && m_engine && m_engine->tellmp("sub_delay " 
			+ QString::number(static_cast<double>(msec)/1000.0) + " 1")) || force)
		emit syncDelayChanged(m_delay = msec);
}

}

