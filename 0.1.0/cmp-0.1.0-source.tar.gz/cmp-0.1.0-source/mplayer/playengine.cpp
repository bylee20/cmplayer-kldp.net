#include <QApplication>
#include <QStringList>
#include <QMultiMap>
#include <QFile>
#include <QProcess>
#include <QDir>
#include <QFileInfo>
#include <helper.h>
#include <preferences.h>
#include <prefgeneral.h>
#include <prefsubtitle.h>
#include "playengine.h"
#include "mediasource.h"
#include "videowidget.h"
#include "audiooutput.h"
#include "subtitleoutput.h"

namespace MPlayer {

PlayEngine::PlayEngine(QObject *parent)
: QObject(parent), m_source(new MediaSource()), m_proc(new QProcess(this)), m_pref(Preferences::get())
, m_video(0), m_audio(0), m_subout(0), m_state(StoppedState), m_totalTime(0), m_curTime(0)
, m_fullScreen(false), m_dontReset(false), m_justFinished(false), m_noVideo(true) {
	const QString appdir = qApp->applicationDirPath() + '/';
	m_dontmessup = (appdir + "donttouch/input.conf");
	QFile file(m_dontmessup);
	if (!file.exists() && file.open(QFile::WriteOnly)) {
		file.write(
			"## prevent mplayer from messing up our shortcuts\n\n"
			"RIGHT gui_about\nLEFT gui_about\nDOWN gui_about\n"
			"UP gui_about\nPGUP gui_about\nPGDWN gui_about\n"
			"- gui_about\n+ gui_about\nESC gui_about\nENTER gui_about\n"
			"SPACE pausing_keep invalid_command\nHOME gui_about\n"
			"END gui_about\n> gui_about\n< gui_about\nINS gui_about\n"
			"DEL gui_about\n[ gui_about\n] gui_about\n{ gui_about\n"
			"} gui_about\nBS gui_about\nTAB gui_about\n. gui_about\n"
			"# gui_about\n@ gui_about\n! gui_about\n9 gui_about\n"
			"/ gui_about\n0 gui_about\n* gui_about\n1 gui_about\n"
			"2 gui_about\n3 gui_about\n4 gui_about\n5 gui_about\n"
			"6 gui_about\n7 gui_about\n8 gui_about\na gui_about\n"
			"b gui_about\nc gui_about\nd gui_about\ne gui_about\n"
			"F invalid_command\nf invalid_command\ng gui_about\n"
			"h gui_about\ni gui_about\nj gui_about\nk gui_about\n"
			"l gui_about\nm gui_about\nn gui_about\no gui_about\n"
			"p gui_about\nq gui_about\nr gui_about\ns gui_about\n"
			"t gui_about\nT gui_about\nu gui_about\nv gui_about\n"
			"w gui_about\nx gui_about\ny gui_about\nz gui_about\n"
			"S gui_about\n"
		);
	}
	m_dummysub = appdir + "donttouch/dummy.smi";
	QFile dummy(m_dummysub);
	if (!dummy.exists() && dummy.open(QFile::WriteOnly))
		dummy.write("<SAMI>\n<BODY>\n<SYNC Start=1000>&nbsp;\n</BODY>\n</SAMI>");
	
	connect(m_proc, SIGNAL(readyReadStandardOutput()), this, SLOT(interpretMessages()));
	connect(m_proc, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(slotProcFinished()));
	connect(this, SIGNAL(stateChanged(MPlayer::State, MPlayer::State)),
			this, SLOT(slotStateChanged(MPlayer::State, MPlayer::State)));
}

PlayEngine::~PlayEngine() {
	delete m_source;
}

void PlayEngine::slotStateChanged(MPlayer::State newState, MPlayer::State oldState) {
	if (isSeekable() && oldState == StoppedState)
		emit seekableChanged(true);
	else if (!isSeekable() && oldState != StoppedState)
		emit seekableChanged(false);
	if (oldState == StoppedState && newState == PlayingState) {
		if (m_audio)
			m_audio->setVolume(m_pref->general().resetVolume
					? m_pref->general().defaultVolume : m_audio->volume());
	}
}

void PlayEngine::slotProcFinished() {
	setState(StoppedState);
	if (m_justFinished) {
		emit finished();
		m_justFinished = false;
	}
}

void PlayEngine::play(const QString &source) {
	play(MediaSource(source));
}

void PlayEngine::stop() {
	if (tellmp("quit") && !m_proc->waitForFinished(5000))
		m_proc->kill();
}

void PlayEngine::interpretMessages() {
	static bool initializing = false;
	static int subID = 0;
	static QStringList subs;
	static QRegExp rxAV("^[AV]: *([0-9,:.-]+)");
	static QRegExp rxVO("^VO: \\[(.*)\\] (\\d+)x(\\d+) => (\\d+)x(\\d+)");
	static QRegExp rxID("^ID_(.*)=(.*)");
	static QRegExp rxInitStart("^Playing (.+)");
	static QRegExp rxInitEnd("^Starting playback.+");
	static QRegExp rxFinished("^Exiting\\.+\\s+\\(End of file\\)");
	static QRegExp rxNoVideo("^Video:\\s+no video");
	static QRegExp rxLineBreak("[\\n\\r]");
	QStringList lines = QString::fromLocal8Bit(m_proc->readAllStandardOutput()).split(rxLineBreak);
	for (int i=0; i<lines.size(); ++i) {
		const QString &message = lines[i];
		if (message.isEmpty())
			continue;
		if (rxAV.indexIn(message) != -1) {
			qint64 msec = static_cast<int>(rxAV.cap(1).toDouble()*1000);
			setState(PlayingState);
			setCurrentTime(msec);
		} else if (message.contains(" PAUSE ")) 
			setState(PausedState);
		else if (rxNoVideo.indexIn(message) != -1) {
			m_noVideo = true;
		} else if (rxVO.indexIn(message) != -1) {
			emit videoSizeChanged(QSize(rxVO.cap(2).toInt(), rxVO.cap(3).toInt()));
		} else if (rxInitStart.indexIn(message) != -1) {
			initializing = true;
			subs.clear();
		} else if (rxInitEnd.indexIn(message) != -1) {
			initializing = false;
			if (m_subout)
				m_dontReset ? m_subout->updateCurrentSubtitle() : m_subout->initSubtitles(subs);
			m_dontReset = false;
		} else if (rxFinished.indexIn(message) != -1) {
			m_justFinished = true;
		} else if (rxID.indexIn(message) != -1) {
			QString id = rxID.cap(1);
			if (id == "LENGTH")
				emit totalTimeChanged(m_totalTime = static_cast<int>(rxID.cap(2).toDouble()*1000));
			else if (id == "FILE_SUB_ID") {
				subID = rxID.cap(2).toInt();
			} else if (id == "FILE_SUB_FILENAME" && subID != 0) {
				subs.append(rxID.cap(2));
			}
		}
	}
}

bool PlayEngine::start(qint64 time) {
	if (m_proc->state() != QProcess::NotRunning)
		stop();
	if (m_source->fileName().isEmpty())
		return false;

	static const Preferences::General &general = m_pref->general();
	static const Preferences::Subtitle &subtitle = m_pref->subtitle();
	
	if (!m_dontReset) {
		if (m_video)
			m_video->resetEqualizer();
		if (m_subout)
			m_subout->setSyncDelay(0, true);
	}
	
	QStringList args;
	args << "-slave" << "-noquiet" << "-nofs" <<  "-identify"
		<< "-input" << "conf=\"" + m_dontmessup + '"' << "-fontconfig"
		<< "-zoom" << "-nokeepaspect";
	if (m_video)
		args << "-wid" << QString::number(m_video->videoWID());
	if (general.useExpand && (!general.expandOnlyFullScreen || m_fullScreen))
		args << "-vf-add" << "expand=:::::" + QString::number(general.expandWidth/general.expandHeight);
	if (general.useSoftwareEqualizer)
		args << "-vf-add" << "eq2";
	if (general.useSoftwareVolume)
		args << "-softvol" << "-softvol-max" << QString::number(general.volumeAmplification);
#define addPrefArg(arg, str) \
	if (!str.isEmpty()) \
		args << arg << str;
	addPrefArg("-vo", general.videoOutput)
	addPrefArg("-ao", general.audioOutput)
	addPrefArg("-font", subtitle.family)
	addPrefArg("-subcp", subtitle.encoding)
#undef addPrefArg
	args << "-subfont-text-scale" << QString::number(subtitle.defaultScale)
			<< "-subfont-autoscale" << QString::number(subtitle.autoScale)
			<< "-subpos" << QString::number(subtitle.initialPosition)
			<< "-subdelay" << QString::number(static_cast<double>(m_subout->syncDelay())/1000.0)
			<< "-sub" << m_dummysub;
	if (subtitle.useAutoLoad)
		args << "-sub-fuzziness" << QString::number(subtitle.autoLoad);
	else
		args << "-noautosub";
	
	if (time > 1000)
		args << "-ss" << QString::number(static_cast<double>(time)/1000.0);
	
	if (!general.additionalOptions.isEmpty())
		args += general.additionalOptions.split(' ');
	
	args << m_source->fileName();
	m_proc->start(m_pref->general().mplayerPath, args);
	return 	(m_proc->state() != QProcess::NotRunning);
}

void PlayEngine::setCurrentSource(const MediaSource &source) {
	*m_source = source;
}

void PlayEngine::setFullScreenState(bool full) {
	if (m_fullScreen != full) {
		m_fullScreen = full;
		static const Preferences::General &general = m_pref->general();
		if (general.useExpand && general.expandOnlyFullScreen)
			restart();
	}
}

bool PlayEngine::tellmp(const QString &command) {
	if (isRunning()) {
		m_proc->write(command.toLocal8Bit() + "\n");
		return true;
	}
	return false;
}

bool PlayEngine::isRunning() {
	return m_proc->state() != QProcess::NotRunning;
}

}
