#include <QFileInfo>
#include "helper.h"

static QFileInfo info;

Helper::Helper(): m_configFile("config.ini") {}

QString Helper::dirSlash(const QString &file) {
	info.setFile(file);
	return info.path() + '/';
}

QString Helper::fileName(const QString &file) {
	info.setFile(file);
	return info.fileName();
}

QString Helper::baseName(const QString &file) {
	info.setFile(file);
	return info.completeBaseName();
}

bool Helper::exists(const QString &file) {
	info.setFile(file);
	return info.exists();
}

QString Helper::extension(const QString &file) {
	info.setFile(file);
	return info.suffix();
}

