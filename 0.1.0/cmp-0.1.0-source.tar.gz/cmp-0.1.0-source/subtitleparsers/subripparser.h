#ifndef SUBTITLEPARSERSSUBRIPPARSER_H
#define SUBTITLEPARSERSSUBRIPPARSER_H

#include "abstractparser.h"

namespace SubtitleParsers {

class SubRipParser : public AbstractParser {
public:
	SubRipParser();
	virtual bool parse(const QString &path, SubtitleList *subs);
	virtual bool save(const QString &path, const Subtitle &sub) const;
};

}

#endif
