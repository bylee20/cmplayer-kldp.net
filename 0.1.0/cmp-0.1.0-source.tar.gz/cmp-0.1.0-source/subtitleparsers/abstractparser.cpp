#include <QTextStream>
#include <preferences.h>
#include <prefsubtitle.h>
#include "abstractparser.h"

namespace SubtitleParsers {

AbstractParser::AbstractParser()
: m_interval(1), m_stream(new QTextStream) {
}

AbstractParser::~AbstractParser() {
	delete m_stream;
}

void AbstractParser::setDevice(QIODevice *device) const {
	static const Preferences::Subtitle &subset = Preferences::get()->subtitle();
	m_stream->setDevice(device);
	if (!subset.encoding.isEmpty())
		m_stream->setCodec(subset.encoding.toLocal8Bit());
}

}
