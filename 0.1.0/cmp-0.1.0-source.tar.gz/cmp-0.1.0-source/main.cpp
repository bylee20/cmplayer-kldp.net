#include <QApplication>
#include <QDir>
#include "mainwindow.h"
#include "singletoninterface.h"

int main(int argc, char **argv) {
	QApplication app(argc, argv);
	
	QDir dir(app.applicationDirPath());
	dir.mkdir("donttouch");
	
	MainWindow mw(argc < 2 ? "" : argv[1]);
	mw.show();
	int result = app.exec();
	return result;
}

