#include <QTimer>
#include "subtitle.h"
#include "abrepeater.h"
#include "mplayer/subtitleoutput.h"
#include "mplayer/playengine.h"

ABRepeater::ABRepeater()
: SingletonInterface<ABRepeater>()
, m_engine(0), m_timer(new QTimer(this)), m_a(-1), m_b(-1), m_repeating(false)
, m_times(0), m_nth(0) {
	connect(m_timer, SIGNAL(timeout()), this, SLOT(slotTimer()));
}

void ABRepeater::slotTimer() {
	m_engine->seek(m_a - 1000);
	if (m_times && m_times == ++m_nth)
		stop();
}

qint64 ABRepeater::setAToCurrentTime() {
	return (m_a = m_engine->currentTime());
}

qint64 ABRepeater::setBToCurrentTime() {
	return (m_b = m_engine->currentTime());
}

qint64 ABRepeater::setAToSubtitleTime() {
	qint64 curTime = m_engine->currentTime();
	const Subtitle &sub = m_engine->subtitleOutput()->currentSubtitle();
	Subtitle::const_iterator it = sub.find(curTime);
	if (it == sub.end() && (it = sub.upperBound(curTime)) != sub.begin())
		--it;
	return (m_a = it.key());
}

qint64 ABRepeater::setBToSubtitleTime() {
	qint64 curTime = m_engine->currentTime();
	const Subtitle &sub = m_engine->subtitleOutput()->currentSubtitle();
	Subtitle::const_iterator it = sub.upperBound(curTime);
	return (m_a = it == sub.end() ? m_engine->totalTime() : it.key());
}

bool ABRepeater::start(int times) {
	if (m_repeating)
		m_timer->stop();
	m_times = times;
	m_nth = 0;
	if (m_repeating = (m_a >= 0 && m_b > m_a)) {
		slotTimer();
		m_timer->start(m_b - m_a + 500);
	}
	return m_repeating;
}

void ABRepeater::stop() {
	m_timer->stop();
	m_repeating = false;
}

void ABRepeater::setPlayEngine(MPlayer::PlayEngine *engine) {
	m_engine = engine;
	connect(m_engine, SIGNAL(finished()), this, SLOT(stop()));
}

