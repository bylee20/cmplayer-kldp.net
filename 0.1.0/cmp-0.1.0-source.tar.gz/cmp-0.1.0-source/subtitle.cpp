#include "subtitle.h"
#include "helper.h"

Subtitle::Subtitle() {}

Subtitle &Subtitle::unite(const Subtitle &other) {
	if (this == &other || other.isEmpty())
		return *this;
	else if (isEmpty())
		return (*this = other);
	QMapIterator<qlonglong, QString> it1(*this);
	QMapIterator<qlonglong, QString> it2(other);
	qlonglong t3 = -1;
	while(it1.hasNext()) {
		qlonglong t1 = it1.next().key();
		qlonglong t2 = it1.hasNext() ? it1.peekNext().key() : -1;
		if (t3 != -1 && it2.hasPrevious())
			(*this)[t1] = it1.value() + "<br>" + it2.peekPrevious().value();
		else
			(*this)[t1] = it1.value();
		while(it2.hasNext()) {
			t3 = it2.next().key();
			if (t2 == -1) {
				(*this)[t3] = it1.value() + "<br>" + it2.value();
			} else if (t3 >= t2) {
				it2.previous();
				break;
			} else if (t3 == t1) {
				(*this)[t1] = it1.value() + "<br>" + it2.value();
			} else if (t3 > t1)
				(*this)[t3] = it1.value() + "<br>" + it2.value();
			else if (t3 < t1)
				(*this)[t3] = it2.value();
		}
	}
	return *this;
}

QString Subtitle::name() const {
	QString file = Helper::fileName(m_file);
	if (!m_lang.isEmpty())
		file += " (" + m_lang + ')';
	return file;
}

