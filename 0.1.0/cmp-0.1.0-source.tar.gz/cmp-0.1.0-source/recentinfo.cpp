#include <QSettings>
#include "helper.h"
#include "recentinfo.h"

RecentStack::RecentStack(int size)
: QStringList() {
	setSize(size);
}


RecentInfo::RecentInfo(): m_files(DefaultRememberCount) {load();}


void RecentInfo::setFiles(const QStringList &files) {
	m_files = files;
	m_path = m_files.size() ? Helper::dirSlash(m_files[0]) : "";
	emit filesChanged(m_files);
}

void RecentInfo::stackFile(const QString &file) {
	m_files.stack(file);
	m_path = Helper::dirSlash(file);
	emit filesChanged(m_files);
}

void RecentInfo::load() {
	QSettings set(Helper::configFile(), QSettings::IniFormat);
	set.beginGroup("RecentInfo");
	setFiles(set.value("Files", QStringList()).toStringList());
	m_list = set.value("PlayList", QStringList()).toStringList();
	m_path = set.value("Path", QString()).toString();
	set.endGroup();
}

void RecentInfo::save() const {
	QSettings set(Helper::configFile(), QSettings::IniFormat);
	set.beginGroup("RecentInfo");
	set.setValue("Files", m_files.toStringList());
	set.setValue("PlayList", m_list);
	set.setValue("Path", m_path);
	set.endGroup();
}
