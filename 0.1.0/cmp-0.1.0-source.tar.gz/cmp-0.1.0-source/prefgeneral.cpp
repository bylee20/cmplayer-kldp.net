#include <QSettings>
#include "prefgeneral.h"

namespace Preferences {

void General::save(QSettings *set) const {
	set->beginGroup("General");
	set->setValue("VideoOutput", videoOutput);
	set->setValue("AudioOutput", audioOutput);
	set->setValue("MPlayerPath", mplayerPath);
	set->setValue("UseSoftwareVolume", useSoftwareVolume);
	set->setValue("VolumeAmplification", volumeAmplification);
	set->setValue("AdditionalOptions", additionalOptions);
	set->setValue("UseExpand", useExpand);
	set->setValue("ExpandWidth", expandWidth);
	set->setValue("ExpandHeight", expandHeight);
	set->setValue("ExpandOnlyFullScreen", expandOnlyFullScreen);
	set->setValue("ResetVolume", resetVolume);
	set->setValue("DefaultVolume", defaultVolume);
	set->setValue("UseSoftwareEqualizer", useSoftwareEqualizer);
	set->setValue("AutoAddFiles", autoAddFiles);
	set->setValue("PauseWhenMinimized", pauseWhenMinimized);
	set->setValue("PlayWhenRestored", playWhenRestored);
	set->endGroup();
}

void General::load(QSettings *set) {
	set->beginGroup("General");
	videoOutput = set->value("VideoOutput", "").toString();
	audioOutput = set->value("AudioOutput", "").toString();
	mplayerPath = set->value("MPlayerPath", "mplayer").toString();
	useSoftwareVolume = set->value("UseSoftwareVolume", true).toBool();
	volumeAmplification = set->value("VolumeAmplification", 110.0).toDouble();
	additionalOptions = set->value("AdditionalOptions", QString()).toString();
	useExpand = set->value("UseExpand", true).toBool();
	expandWidth = set->value("ExpandWidth", 4.0).toDouble();
	expandHeight = set->value("ExpandHeight", 3.0).toDouble();
	expandOnlyFullScreen = set->value("ExpandOnlyFullScreen", true).toBool();
	resetVolume = set->value("ResetVolume", true).toBool();
	defaultVolume = set->value("DefaultVolume", 100).toInt();
	useSoftwareEqualizer = set->value("UseSoftwareEqualizer", false).toBool();
	autoAddFiles = AutoAddFiles(set->value("AutoAddFiles", SimilarFiles).toInt());
	pauseWhenMinimized = set->value("PauseWhenMinimized", false).toBool();
	playWhenRestored = set->value("PlayWhenRestored", true).toBool();
	set->endGroup();
}

}
