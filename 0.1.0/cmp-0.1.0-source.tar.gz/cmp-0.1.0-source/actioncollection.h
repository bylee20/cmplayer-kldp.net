#ifndef ACTIONCOLLECTION_H
#define ACTIONCOLLECTION_H

#include <QString>
#include <QMap>
#include "singletoninterface.h"

class QMenu;			class QAction;

class ActionCollection : public SingletonInterface<ActionCollection> {
	SINGLE(ActionCollection)
public:
	void addAction(const QString &name, QAction *action);
	void addAction(QAction *action);
	void addActions(const QList<QAction*> &actions);
	void addActions(QMenu *menu);
	inline QList<QAction *> actions() const {return m_actions.values();}
	inline QString name(QAction *action) const {return m_names.value(action);}
	inline QAction *action(const QString &name) const {return m_actions.value(name);}
	inline void setAction(const QString &name, QAction *action) {
		if (m_actions.contains(name)) {m_names.remove(m_actions[name]);} addAction(name, action);}
	void setName(QAction *action, const QString &name);
	QAction* take(QAction *action);
	inline void setWholeMenu(QMenu *menu) {m_wholeMenu = menu;}
	inline void setMouseMenu(QMenu *menu) {m_mouseMenu = menu;}
	inline QMenu *wholeMenu() const {return m_wholeMenu;}
	inline QMenu *mouseMenu() const {return m_mouseMenu;}
private:
	ActionCollection();
	QMap<QAction*, QString> m_names;
	QMap<QString, QAction*> m_actions;
	QMenu *m_wholeMenu, *m_mouseMenu;
};

#endif
