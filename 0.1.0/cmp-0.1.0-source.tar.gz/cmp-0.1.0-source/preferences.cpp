#include <QSettings>
#include <QApplication>
#include "preferences.h"
#include "prefgeneral.h"
#include "prefsubtitle.h"
#include "prefinterface.h"
#include "helper.h"

namespace Preferences {

Settings *get() {
	return Settings::get();
}

Settings::Settings()
: m_general(new General()), m_subtitle(new Subtitle()), m_interface(new Interface()) {
	Helper::setConfigFile(qApp->applicationDirPath() + '/' + "config.ini");
	load();
}

void Settings::setGeneral(const General &general) {
	*m_general = general;
}

void Settings::setSubtitle(const Subtitle &subtitle) {
	*m_subtitle = subtitle;
}

void Settings::setInterface(const Interface &interface) {
	*m_interface = interface;
}
	
void Settings::load() {
	QSettings set(Helper::configFile(), QSettings::IniFormat);
	m_general->load(&set);
	m_subtitle->load(&set);
	m_interface->load(&set);
}

void Settings::save() const {
	QSettings set(Helper::configFile(), QSettings::IniFormat);
	m_general->save(&set);
	m_subtitle->save(&set);
	m_interface->save(&set);
}

}
