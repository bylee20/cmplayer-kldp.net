#ifndef HELPER_H
#define HELPER_H

#include <QString>
#include <QSize>
#include "singletoninterface.h"

class Helper : public SingletonInterface<Helper> {
	SINGLE(Helper)
public:
	static QString extension(const QString &file);
	static QString dirSlash(const QString &file);
	static QString fileName(const QString &file);
	static bool exists(const QString &file);
	inline static const QString &configFile() {return get()->m_configFile;}
	inline static void setConfigFile(const QString &file) {get()->m_configFile = file;}
	inline static bool isSame(qreal n1, qreal n2, qreal prec = 0.001) {return qAbs(n1-n2) < prec;}
	static QString baseName(const QString &file);
	inline static const char *const version() {return "0.1.0";}
private:
	Helper();
	QString m_configFile;
};

#endif
