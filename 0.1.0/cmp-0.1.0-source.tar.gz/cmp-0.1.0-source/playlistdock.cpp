#include <QFileDialog>
#include <QFileInfo>
#include <QProcess>
#include <QTimer>
#include "helper.h"
#include "playlistdock.h"
#include "ui_getpassworddialog.h"
#include "ui_playlistwidget.h"
#include "mplayer/playengine.h"
#include "mplayer/informations.h"

PlayListDock::PlayListDock(MPlayer::PlayEngine *engine, QWidget *parent)
: QDockWidget(parent), ui(new Ui::Ui_PlayListWidget), m_engine(engine), m_proc(new QProcess(this))
, m_timer(new QTimer(this)), m_playingItem(0), m_pwd(new QDialog(this))
, m_pwUi(new Ui::Ui_GetPasswordDialog), m_items(), m_checking(false), m_adding(false) {
	QWidget *w = new QWidget(this);
	ui->setupUi(w);
	setWidget(w);
	setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
	m_pwUi->setupUi(m_pwd);
	m_timer->setInterval(700);
	m_timer->setSingleShot(true);
	
	connect(ui->add_button, SIGNAL(clicked()), this, SLOT(add()));
	connect(ui->erase_button, SIGNAL(clicked()), this, SLOT(erase()));
	connect(ui->up_button, SIGNAL(clicked()), this, SLOT(up()));
	connect(ui->down_button, SIGNAL(clicked()), this, SLOT(down()));
	connect(ui->clear_button, SIGNAL(clicked()), this, SLOT(clear()));
	connect(ui->close_button, SIGNAL(clicked()), this, SLOT(hide()));
	connect(ui->list, SIGNAL(itemActivated(QListWidgetItem*)), this, SLOT(play(QListWidgetItem*)));
	connect(ui->shutdown_check, SIGNAL(toggled(bool)), this, SLOT(getPassword(bool)));
	connect(m_engine, SIGNAL(finished()), this, SLOT(checkNext()));
	connect(m_pwUi->check_button, SIGNAL(clicked()), this, SLOT(checkPassword()));	
	connect(m_proc, SIGNAL(readyReadStandardOutput()), this, SLOT(readStdOut()));
	connect(m_proc, SIGNAL(started()), this, SLOT(slotProcStarted()));
	connect(m_timer, SIGNAL(timeout()), this, SLOT(slotTimer()));
}

PlayListDock::~PlayListDock() {
	if (m_proc->state() == QProcess::Running)
		m_proc->kill();
	delete m_pwUi;
	delete ui;
}

void PlayListDock::checkPassword() {
	m_pwUi->password_edit->setEnabled(false);
	m_pwUi->check_button->setEnabled(false);
	m_checking = true;
	m_proc->start("sudo", QStringList() << "-S" << "whoami");
	m_timer->start();
}

void PlayListDock::slotTimer() {
	if (m_checking) {
		m_pwUi->check_label->setText(trUtf8("불일치!"));
		m_pwUi->ok_button->setEnabled(false);
		m_pwUi->check_button->setEnabled(true);
		m_pwUi->password_edit->setEnabled(true);
		m_pwUi->password_edit->setFocus();
		if (m_proc->state() == QProcess::Running)
			m_proc->kill();
		m_checking = false;
	}
}

void PlayListDock::getPassword(bool checked) {
	if (checked && !m_pwd->exec())
		ui->shutdown_check->setChecked(false);
}

void PlayListDock::slotProcStarted() {
	m_proc->write((m_pwUi->password_edit->text() + '\n').toLocal8Bit());
}
	
void PlayListDock::readStdOut() {
	if (m_checking && QString::fromLocal8Bit(m_proc->readAllStandardOutput()).left(4) == "root") {
		m_checking = false;
		m_pwUi->check_label->setText(trUtf8("일치!"));
		m_pwUi->ok_button->setEnabled(true);
		m_pwUi->ok_button->setFocus();
		m_pwUi->check_button->setEnabled(false);
		m_pwUi->password_edit->setEnabled(false);
		if (m_proc->state() == QProcess::Running)
			m_proc->kill();
	}
}

int PlayListDock::count() const {
	return ui->list->count();
}

int PlayListDock::currentRow() const {
	return ui->list->row(m_playingItem);
}

#define emitCount() emit countChanged(ui->list->count())
#define emitCurrent() emit currentRowChanged(ui->list->row(m_playingItem))

void PlayListDock::add() {
	static const MPlayer::Informations *info = MPlayer::Informations::get();
	static const QString Filter = trUtf8("비디오 파일") +' ' + info->videoExtensions().toFilter() + ";;"
			+ trUtf8("음악 파일") + ' ' + info->audioExtensions().toFilter() + ";;"
			+ trUtf8("모든 파일") + ' ' + "(*.*)";
	QStringList files = QFileDialog::getOpenFileNames(this, trUtf8("파일 열기"), QString(), Filter);
	add(files);
}

void PlayListDock::add(const QStringList &files) {
	m_adding = true;
	for (QStringList::const_iterator it = files.begin(); it != files.end(); ++it)
		add(*it);
	m_adding = false;
	emitCount();
}

QListWidgetItem *PlayListDock::add(const QString &file) {
	QListWidgetItem *item = new QListWidgetItem(Helper::fileName(file), ui->list);
	item->setData(Qt::UserRole, file);
	if (!m_adding)
		emitCount();
	return (m_items[file] = item);
}

void PlayListDock::erase() {
	const int row = ui->list->currentRow();
	if (row <0)
		return;
	QListWidgetItem *item = m_items.take(ui->list->takeItem(row)->data(Qt::UserRole).toString());
	if (item == m_playingItem)
		m_playingItem = 0;
	delete item;
	const int count = ui->list->count();
	if (count)
		ui->list->setCurrentRow(qMin(row, count-1));
	emitCount();
}

void PlayListDock::move(bool up) {
	const int row = ui->list->currentRow();
	int target;
	if (up) {
		if (row <= 0)
			return;
		target = row-1;
	} else {
		if (row < 0 || row >= ui->list->count()-1)
			return;
		target = row + 1;
	}
	QListWidgetItem *item = ui->list->takeItem(row);
	ui->list->insertItem(target, item);
	ui->list->setCurrentItem(item);
	if (item == m_playingItem)
		emitCurrent();
}

void PlayListDock::clear() {
	ui->list->clear();
	m_items.clear();
	m_playingItem = 0;
	emitCount();
	emitCurrent();
}

void PlayListDock::play(QListWidgetItem *item) {
	if (!item)
		return;
	QString file = item->data(Qt::UserRole).toString();
	m_engine->play(file);
	QFont f = font();
	if (m_playingItem && ui->list->row(m_playingItem) != -1)
		m_playingItem->setFont(f);
	f.setItalic(true);
	item->setFont(f);
	ui->list->setCurrentItem(m_playingItem = item);
	emitCurrent();
}

void PlayListDock::checkNext() {
	const int count = ui->list->count();
	if (!count)
		return;
	const int curRow = ui->list->row(m_playingItem);
	if (curRow == count - 1 && ui->shutdown_check->isChecked())
		m_proc->start("sudo", QStringList() << "-S" << "shutdown" << "-h" << "now");
	else
		playNext();
}

void PlayListDock::playNext() {
	const int count = ui->list->count();
	if (!count)
		return;
	const int curRow = ui->list->row(m_playingItem);
	const int nextRow = (curRow != -1 && curRow != count-1) ? curRow + 1 : 0;
	play(ui->list->item(nextRow));
}

void PlayListDock::playPrevious() {
	const int count = ui->list->count();
	if (!count)
		return;
	const int curRow = ui->list->row(m_playingItem);
	int prevRow = (curRow > 0) ? curRow-1 : count-1;
	play(ui->list->item(prevRow));
}


QStringList PlayListDock::playList() const {
	QStringList files;
	for (int i=0; i<ui->list->count(); ++i)
		files << ui->list->item(i)->data(Qt::UserRole).toString();
	return files;
}

#undef emitCount
#undef emitCurrent
