#ifndef PLAYLISTDOCK_H
#define PLAYLISTDOCK_H

#include <QDockWidget>
#include <QMap>

namespace MPlayer {class PlayEngine;}

class QProcess;							class QDialog;
class QTimer;								class QListWidgetItem;

namespace Ui {class Ui_GetPasswordDialog;	class Ui_PlayListWidget;}

class PlayListDock : public QDockWidget {
	Q_OBJECT
public:
	PlayListDock(MPlayer::PlayEngine *engine, QWidget *parent = 0);
	~PlayListDock();
	int count() const;
	int currentRow() const;
public slots:
	void playNext();
	void playPrevious();
	inline void setPlayList(const QStringList &files) {clear(); add(files);}
	QStringList playList() const;
	inline void play(const QString &file) {play(m_items.contains(file) ? m_items[file] : add(file));}
	void add(const QStringList &files);
	QListWidgetItem *add(const QString &file);
	void clear();
signals:
	void currentRowChanged(int row);
	void countChanged(int count);
private slots:
	void add();
	void erase();
	inline void up() {move(true);}
	inline void down() {move(false);}
	void play(QListWidgetItem *item);
	void slotProcStarted();
	void readStdOut();
	void getPassword(bool checked);
	void checkPassword();
	void slotTimer();
	void checkNext();
private:
	void move(bool up);
	Ui::Ui_PlayListWidget *ui;
	MPlayer::PlayEngine *m_engine;
	QProcess *m_proc;
	QTimer *m_timer;
	QListWidgetItem *m_playingItem;
	QDialog *m_pwd;
	Ui::Ui_GetPasswordDialog *m_pwUi;
	QMap<QString, QListWidgetItem*> m_items;
	bool m_checking, m_adding;
};

#endif // PLAYLISTDOCK_H
