/*#ifndef VIDEOWIDGET_H
#define VIDEOWIDGET_H

#include <QWidget>
#include <QGLWidget>

class QGLFormat;
class OSDWidget;

class VideoArea : public QWidget {
	Q_OBJECT
public:
	enum AspectRatio {AspectAuto = 0, AspectFit = 1, Aspect43 = 2, Aspect169 = 3};
	VideoArea(QWidget *parent = 0);
protected:
	void resizeEvent(QResizeEvent *event);
};

class MPlayerEngine;

class VideoWidget : public QWidget {
	Q_OBJECT
public:
	enum AspectRatio {AspectAuto = 0, AspectFit = 1, Aspect43 = 2, Aspect169 = 3};
	VideoWidget(MPlayerEngine *engine, QWidget *parent = 0);
	QWidget *videoArea() {return area;}
	OSDWidget *subtitleWidget() const {return m_osd;}
	void setAspectRatio(AspectRatio ar);
signals:
	void resized(const QSize &size);
protected:
	virtual void keyPressEvent(QKeyEvent *event);
	virtual void resizeEvent(QResizeEvent *event);
	virtual void paintEvent(QPaintEvent *event);
	virtual bool eventFilter(QObject *obj, QEvent *event);
private slots:
	//	void slotStarted();
	void slotSizeHintChanged(const QSize &hint);
	void adjustSubtitlePosition();
private:
	void updateVideoArea();
	VideoArea *area;
	MPlayerEngine *engine;
	AspectRatio asp;
	QSize videoSize;
	OSDWidget *m_osd;
};

#endif
*/
/*#include <QDebug>
#include <QGLFormat>
#include <QResizeEvent>
#include <QGLWidget>
#include <QPainter>
#include <QPaintEvent>
#include <QGridLayout>
#include <cmath>
#include <QSpacerItem>
#include "videowidget.h"
#include "mplayerengine.h"
#include "helper.h"
#include "osdwidget.h"
#include "preferences.h"
#include "prefsubtitle.h"

VideoArea::VideoArea(QWidget *parent)
: QWidget(parent) {}

void VideoArea::resizeEvent(QResizeEvent *event) {
	
}

VideoWidget::VideoWidget(MPlayerEngine *engine, QWidget *parent)
: QWidget(parent), engine(engine) {
	setStyleSheet("background-color: black;");
	setAutoFillBackground(true);
	area = new VideoArea(this);
	area->setAutoFillBackground(true);
	area->setAttribute(Qt::WA_NoSystemBackground);
	area->setAttribute(Qt::WA_StaticContents);
	area->setAttribute(Qt::WA_PaintOnScreen);
	area->setAttribute(Qt::WA_PaintUnclipped);
	engine->setVideoWidget(this);
	area->installEventFilter(this);
	connect(engine, SIGNAL(sizeHintChanged(const QSize&)), this, SLOT(slotSizeHintChanged(const QSize&)));
	m_osd = new OSDWidget(this, true);
	m_osd->show();
	connect(m_osd, SIGNAL(sizeAdjusted(QSize)), this, SLOT(adjustSubtitlePosition()));
}

void VideoWidget::adjustSubtitlePosition() {
	m_osd->move(0, height()-m_osd->height());
}

bool VideoWidget::eventFilter(QObject *obj, QEvent *event) {
	if (obj == area && event->type() == QEvent::Paint && engine->isStopped()) {
		QPainter painter(area);
		painter.fillRect(static_cast<QPaintEvent*>(event)->rect(), Qt::black);
		return true;
	} else
		return QWidget::eventFilter(obj, event);
}
		

void VideoWidget::paintEvent(QPaintEvent *event) {
	QWidget::paintEvent(event);
	QPainter painter(this);
	painter.fillRect(event->rect(), Qt::black);
}

void VideoWidget::slotSizeHintChanged(const QSize &hint) {
	videoSize = hint;
	setAspectRatio(AspectAuto);
	updateVideoArea();
}

void VideoWidget::keyPressEvent(QKeyEvent *event) {
	QWidget::keyPressEvent(event);
}


void VideoWidget::setAspectRatio(AspectRatio ar) {
	if (asp != ar) {
		asp = ar;
		updateVideoArea();
	}
}

void VideoWidget::updateVideoArea() {
	QSize backSize = size();
	int w = width(), h = height(), x = 0, y = 0;
	double ratio;
	switch(asp) {
	case AspectFit:
		ratio = -1.0;
		break;
	case Aspect43:
		ratio = Helper::toDouble(4)/Helper::toDouble(3);
		break;
	case Aspect169:
		ratio = Helper::toDouble(16)/Helper::toDouble(9);
		break;
	default:
		ratio = Helper::toDouble(videoSize.width())/Helper::toDouble(videoSize.height());
		break;
	}
	if (ratio > 0) {
		double backRatio = Helper::toDouble(w)/Helper::toDouble(h);
		if (backRatio > ratio) {
			w = h*ratio;
			x = (width() - w)/2;
		} else {
			h = w/ratio;
			y = (height() - h)/2;
		}
	}
	area->resize(w, h);
	area->move(x, y);
	m_osd->resize(w, m_osd->height());
	Preferences::Settings *pref = Preferences::get();
	if (pref->subtitle().autoScale != Preferences::Subtitle::NoAutoScale) {
		qreal scale = pref->subtitle().defaultScale/150.0;
		switch(pref->subtitle().autoScale) {
		case Preferences::Subtitle::FitToDiagonal:
			scale = std::sqrt(w*w+h*h)*scale;
			break;
		case Preferences::Subtitle::FitToHeight:
			scale = scale * h;
			break;
		case Preferences::Subtitle::FitToWidth:
			scale = scale * w;
			break;
		}
		m_osd->setFontPixelSize(static_cast<int>(scale));
	}
	adjustSubtitlePosition();
}

void VideoWidget::resizeEvent(QResizeEvent *event) {
	QWidget::resizeEvent(event);
	emit resized(size());
	updateVideoArea();
}
*/
