#include <QAction>
#include <QMenu>
#include <QFile>
#include "menutreewriter.h"
#include "actioncollection.h"

MenuTreeWriter::MenuTreeWriter() : QXmlStreamWriter(), m_ac(ActionCollection::get()) {}

bool MenuTreeWriter::write(QMenu *menu, const QString &file) {
	setAutoFormatting(true);
	QFile device(file);
	if (!device.open(QFile::WriteOnly | QFile::Text))
		return false;
	setDevice(&device);
	
	writeStartDocument();
	writeStartElement("Root");
	writeActions(menu->actions());
	writeEndDocument();
	
	return true;
}

void MenuTreeWriter::writeAction(QAction *action) {
	if (action->menu())
		writeMenu(action->menu());
	else {
		writeStartElement("Action");
		writeAttribute("IsSeparator", action->isSeparator() ? "true" : "false");
		writeTextElement("Name", m_ac->name(action));
		writeEndElement();
	}
}

void MenuTreeWriter::writeMenu(QMenu *menu) {
	writeStartElement("Menu");
	writeAttribute("Title", menu->title());
	writeActions(menu->actions());
	writeEndElement();
}

void MenuTreeWriter::writeActions(const QList<QAction*> &actions) {
	for (int i=0; i<actions.size(); ++i)
		writeAction(actions[i]);
}

