#ifndef PLAYMENUBAR_H
#define PLAYMENUBAR_H

#include <QWidget>

class QTime;
namespace Ui {class Ui_PlayMenuBar;}

class PlayMenuBar : public QWidget {
	Q_OBJECT
public:
	PlayMenuBar(QWidget *parent = 0);
	~PlayMenuBar();
	void init(const QList<QWidget *> &tools);
public slots:
	void setTotalTime(qint64 msec);
	void setCurrentTime(qint64 msec);
	void setPlayText(const QString text);
private:
	Ui::Ui_PlayMenuBar *ui;
	const QTime *const m_zero;
};

#endif
