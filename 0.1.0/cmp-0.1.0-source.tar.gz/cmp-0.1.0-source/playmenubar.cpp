#include <QTime>
#include "playmenubar.h"
#include "ui_playmenubar.h"


PlayMenuBar::PlayMenuBar(QWidget *parent)
: QWidget(parent), ui(new Ui::Ui_PlayMenuBar), m_zero(new QTime) {
	ui->setupUi(this);
}

PlayMenuBar::~PlayMenuBar() {
	delete ui;
	delete m_zero;
}

void PlayMenuBar::init(const QList<QWidget *> &tools) {
	QHBoxLayout *layout = new QHBoxLayout;
	layout->setMargin(0);
	layout->setSpacing(0);
	for (int i=0; i<tools.size(); ++i)
		layout->addWidget(tools[i]);
	ui->tools_widget->setLayout(layout);
	adjustSize();
	setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
}

void PlayMenuBar::setPlayText(const QString text) {
	ui->play_info_label->setText(text);
}

void PlayMenuBar::setTotalTime(qint64 ms) {
	ui->total_time_label->setText(m_zero->addMSecs(ms).toString("h:mm:ss"));
}

void PlayMenuBar::setCurrentTime(qint64 ms) {
	static qint64 before = -1;
	if (ms != before) {
		ui->current_time_label->setText(m_zero->addMSecs(ms).toString("h:mm:ss"));
		before = ms;
	}
}
