#include "abrepeatdialog.h"
#include "ui_abrepeatdialog.h"
#include "abrepeater.h"

ABRepeatDialog::ABRepeatDialog(QWidget *parent)
: QDialog(parent), ui(new Ui::Ui_ABRepeatDialog), m_repeater(ABRepeater::get()), m_time(new QTime) {
	ui->setupUi(this);
	connect(ui->a_time_button, SIGNAL(clicked()), this, SLOT(getAFromTime()));
	connect(ui->b_time_button, SIGNAL(clicked()), this, SLOT(getBFromTime()));
	connect(ui->a_subtitle_button, SIGNAL(clicked()), this, SLOT(getAFromSubtitle()));
	connect(ui->b_subtitle_button, SIGNAL(clicked()), this, SLOT(getBFromSubtitle()));
	connect(ui->quit_button, SIGNAL(clicked()), m_repeater, SLOT(stop()));
	connect(ui->start_button, SIGNAL(clicked()), this, SLOT(start()));
}

ABRepeatDialog::~ABRepeatDialog() {
	delete ui;
}

void ABRepeatDialog::start() {
	int a = m_time->msecsTo(ui->a_time_edit->time());
	int b = m_time->msecsTo(ui->b_time_edit->time());
	int dif = static_cast<int>(ui->add_time_spin->value()*1000);
	m_repeater->repeat(a - dif, b+ dif, ui->times_spin->value());
}

void ABRepeatDialog::getAFromTime() {
	ui->a_time_edit->setTime(m_time->addMSecs(m_repeater->setAToCurrentTime()));
}

void ABRepeatDialog::getAFromSubtitle() {
	ui->a_time_edit->setTime(m_time->addMSecs(m_repeater->setAToSubtitleTime()));
}

void ABRepeatDialog::getBFromTime() {
	ui->b_time_edit->setTime(m_time->addMSecs(m_repeater->setBToCurrentTime()));
}

void ABRepeatDialog::getBFromSubtitle() {
	ui->b_time_edit->setTime(m_time->addMSecs(m_repeater->setBToSubtitleTime()));
}

