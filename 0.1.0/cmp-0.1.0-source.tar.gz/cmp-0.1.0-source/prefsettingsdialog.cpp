#include "prefsettingsdialog.h"
#include "preferences.h"
#include "prefgeneralwidget.h"
#include "prefsubtitlewidget.h"
#include "prefinterfacewidget.h"
#include "ui_prefsettingsdialog.h"

namespace Preferences {

SettingsDialog::SettingsDialog(QWidget *parent)
: QDialog(parent), ui(new Ui::Ui_SettingsDialog), m_pref(get())
, m_general(new GeneralWidget(m_pref->general(), this))
, m_subtitle(new SubtitleWidget(m_pref->subtitle(), this))
, m_interface(new InterfaceWidget(m_pref->interface(), this)) {
	ui->setupUi(this);
	connect(ui->ok_button, SIGNAL(clicked()), this, SLOT(save()));
	while (ui->stack->count()) {
		QWidget *w = ui->stack->widget(0);
		ui->stack->removeWidget(w);
		delete w;
	}
	ui->stack->addWidget(m_general);
	ui->stack->addWidget(m_subtitle);
	ui->stack->addWidget(m_interface);
}

SettingsDialog::~SettingsDialog() {
	delete ui;
}

void SettingsDialog::save() {
	m_pref->setGeneral(m_general->general());
	m_pref->setSubtitle(m_subtitle->subtitle());
	m_pref->setInterface(m_interface->interface());
	m_pref->save();
	accept();
}

}

