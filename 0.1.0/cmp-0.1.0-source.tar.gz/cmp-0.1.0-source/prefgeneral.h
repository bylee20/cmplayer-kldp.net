#ifndef PREFERENCESPREFGENERAL_H
#define PREFERENCESPREFGENERAL_H

#include <QString>

class QSettings;

namespace Preferences {

class General {
public:
	enum AutoAddFiles {
		SimilarFiles = 0,
		AllFiles,
		DoNotAddFiles
	};
	QString mplayerPath;
	QString videoOutput;
	QString audioOutput;
	bool useSoftwareVolume;
	double volumeAmplification;
	QString additionalOptions;
	bool useExpand;
	qreal expandWidth;
	qreal expandHeight;
	bool expandOnlyFullScreen;
	bool resetVolume;
	int defaultVolume;
	bool useSoftwareEqualizer;
	bool playWhenRestored;
	AutoAddFiles autoAddFiles;
	bool pauseWhenMinimized;
	void save(QSettings *set) const;
	void load(QSettings *set);
};

}

#endif
