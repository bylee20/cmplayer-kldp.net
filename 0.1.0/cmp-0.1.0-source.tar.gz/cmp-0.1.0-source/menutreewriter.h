#ifndef MENUTREEWRITER_H
#define MENUTREEWRITER_H

#include <QXmlStreamWriter>

class QMenu;							class QAction;
class ActionCollection;

class MenuTreeWriter : public QXmlStreamWriter {
public:
	MenuTreeWriter();
	bool write(QMenu *menu, const QString &file);
private:
	void writeAction(QAction *action);
	void writeMenu(QMenu *menu);
	void writeActions(const QList<QAction*> &actions);
	ActionCollection *m_ac;
};

#endif
