#include <QRegExp>
#include <QFont>
#include <QFile>
#include <QTextStream>
#include <QFileInfo>
#include <mplayer/playengine.h>
#include <mplayer/mediasource.h>
#include "recentinfo.h"
#include "playlistmodel.h"

struct PlayListModel::Data {
	Data(MPlayer::PlayEngine *engine, PlayListModel *parent)
	: p(parent), engine(engine), curRow(-1), loop(false) {
		 curFont.setItalic(true);
		 connect(engine, SIGNAL(finished()), p, SLOT(playNext()));
	}
	bool isValid(int row) const {
		return 0 <= row && row < sources.size();
	}
	PlayListModel *p;
	MPlayer::PlayEngine *engine;
	QList<MPlayer::MediaSource> sources;
	int curRow;
	QFont curFont;
	bool loop;
};
	
PlayListModel::PlayListModel(MPlayer::PlayEngine *engine, QObject *parent)
: QAbstractTableModel(parent) {
	d = new Data(engine, this);
}

PlayListModel::~PlayListModel() {
	delete d;
}

void PlayListModel::setLoop(bool loop) {
	d->loop = loop;
}

int PlayListModel::rowCount(const QModelIndex &/*parent*/) const {
	return d->sources.size();
}

int PlayListModel::columnCount(const QModelIndex &/*parent*/) const {
	return 1;
}

QVariant PlayListModel::headerData(int section, Qt::Orientation orientation, int role) const {
	return QVariant();
	if (role != Qt::DisplayRole)
		return QVariant();
	if (orientation == Qt::Horizontal && section == 0)
		return trUtf8("파일명");
}

QVariant PlayListModel::data(const QModelIndex &index, int role) const {
	const int row = index.row();
	if (!d->isValid(row))
		return QVariant();
	if (role == Qt::DisplayRole)
		return QFileInfo(d->sources[row].fileName()).fileName();
	else if (role == Qt::FontRole) {
		if (row == d->curRow)
			return d->curFont;
		else
			QFont();
	}
	return QVariant();
}

bool PlayListModel::setMediaSource(int row, const MPlayer::MediaSource &source) {
	if (!d->isValid(row))
		return false;
	d->sources[row] = source;
	emit dataChanged(index(row, 0), index(row, columnCount()-1));
	return true;
}

bool PlayListModel::append(const MPlayer::MediaSource &source) {
	return insert(rowCount(), source);
}

MPlayer::MediaSource PlayListModel::mediaSource(int row) const {
	return d->sources.value(row);
}

bool PlayListModel::swap(int row1, int row2) {
	if (row1 < 0 || row2 < 0 || row1 >= rowCount() || row2 >= rowCount())
		return false;
	if (d->curRow == row1)
		emit currentRowChanged(d->curRow = row2);
	else if (d->curRow == row2)
		emit currentRowChanged(d->curRow = row1);
	MPlayer::MediaSource temp = d->sources[row1];
	d->sources[row1] = d->sources[row2];
	emit dataChanged(index(row1, 0), index(row1, columnCount() - 1));
	d->sources[row2] = temp;
	emit dataChanged(index(row2, 0), index(row2, columnCount() - 1));
	return true;
}

bool PlayListModel::insert(int row, const MPlayer::MediaSource &source) {
	emit layoutAboutToBeChanged();
	d->sources.insert(row, source);
	emit rowCountChanged(d->sources.size());
	emit layoutChanged();
	return setMediaSource(row, source);
}

void PlayListModel::clear() {
	d->sources.clear();
	d->curRow = -1;
	reset();
}

int PlayListModel::currentRow() const {
	return d->curRow;
}

MPlayer::MediaSource PlayListModel::currentMediaSource() const {
	return mediaSource(d->curRow);
}

bool PlayListModel::remove(int row) {
	if (!d->isValid(row))
		return false;
	emit layoutAboutToBeChanged();
	if (d->curRow > row)
		--d->curRow;
	else if (d->curRow == row)
		d->curRow = -1;
	d->sources.removeAt(row);
	emit layoutChanged();
	return true;
}

void PlayListModel::play(const QModelIndex &index) {
	play(index.row());
}

void PlayListModel::play(const MPlayer::MediaSource &source) {
	const int row = d->sources.indexOf(source);
	if (row != -1)
		play(row);
	else {
		append(source);
		play(rowCount() - 1);
	}
}

bool PlayListModel::play(int row) {
	if (!setCurrentRow(row))
		return false;
	d->engine->stop();
	d->engine->play(d->sources[row], RecentInfo::get()->stoppedTime(d->sources[row].fileName()));
	return true;
}

void PlayListModel::playNext() {
	if (d->sources.isEmpty() || d->curRow == -1)
		return;
	if (d->curRow == d->sources.size() - 1)
		emit finished();
	else
		play(d->curRow + 1);
}

void PlayListModel::playPrevious() {
	if (!d->sources.isEmpty())
		play((d->curRow > 0) ? d->curRow-1 : d->sources.size() - 1);
}

bool PlayListModel::setCurrentRow(int row) {
	if (!d->isValid(row))
		return false;
	if (row != d->curRow) {
		int temp = d->curRow;
		d->curRow = row;
		emit dataChanged(index(temp, 0), index(temp, columnCount()-1));
		emit dataChanged(index(row, 0), index(row, columnCount()-1));
		emit currentRowChanged(d->curRow);
	}
	return true;
}

bool PlayListModel::save(const QString &fileName) const {
	QFile file(fileName);
	if (!file.open(QFile::WriteOnly | QFile::Truncate))
		return false;
	QTextStream out(&file);
	const int size = rowCount();
	out << "[playlist]" << endl << "NumberOfEntries=" << size << endl << endl;
	for (int i=0; i<size; ++i)
		out << "File" << i+1 << '=' << d->sources[i].fileName() << endl
				<< "Length" << i+1 << '=' << -1 << endl << endl;
	out << "Version=2" << endl;
	return true;
}

bool PlayListModel::load(const QString &fileName) {
	d->sources.clear();
	QFile file(fileName);
	if (!file.open(QFile::ReadOnly))
		return false;
	QTextStream in(&file);
	while (!in.atEnd()) {
		QString line = in.readLine();
		if (line.isEmpty())
			continue;
		static QRegExp rxFile("^File\\d+=(.+)$");
		if (rxFile.indexIn(line) != -1)
			d->sources.append(rxFile.cap(1));
	}
	emit currentRowChanged(d->curRow = -1);
	emit rowCountChanged(d->sources.size());
	reset();
	return true;
}

