#ifndef MPLAYERAUDIOOUTPUT_H
#define MPLAYERAUDIOOUTPUT_H

#include <QObject>

namespace MPlayer {

class PlayEngine;

class AudioOutput : public QObject {
	Q_OBJECT
public:
	AudioOutput(QObject *parent = 0);
	~AudioOutput();
	inline int volume() const {return m_volume;}
	inline bool isMuted() const {return m_muted;}
public slots:
	void setVolume(int value, bool relative = false);
	void setMuted(bool muted);
	void updateAudio();
signals:
	void volumeChanged(int value);
	void mutedChanged(bool muted);
private:
	friend void connect(PlayEngine *engine, AudioOutput *audio);
	void setPlayEngine(PlayEngine *engine);
	PlayEngine *m_engine;
	bool m_muted;
	int m_volume;
};

}

#endif
