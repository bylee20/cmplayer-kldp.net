#include <QDir>
#include <QApplication>
#include <subtitleparsers.h>
#include <preferences.h>
#include <prefsubtitle.h>
#include "mediasource.h"
#include "playengine.h"
#include "subtitleoutput.h"
#include "informations.h"
#include "helper.h"

namespace MPlayer {

struct SubtitleOutput::Data {
	Data(SubtitleOutput *parent)
	: p(parent), engine(0), tempsub(Helper::privatePath() + "/temp.smi")
	, delay(0), pos(100) {}
	SubtitleOutput *p;
	PlayEngine *engine;
	QString tempsub;
	int delay, pos;
	Subtitle cursub;
	QList<int> curIdxes;
	QList<Subtitle> subtitles;
};
	
SubtitleOutput::SubtitleOutput(QObject *parent)
: QObject(parent) {
	d = new Data(this);
}

SubtitleOutput::~SubtitleOutput() {
	delete d;
}

const QList<Subtitle> &SubtitleOutput::subtitleList() const {
	return d->subtitles;
}

void SubtitleOutput::appendCurrentIndexes(const QList<int> &indexes) {
	emit currentIndexesChanged(d->curIdxes += indexes);
	updateCurrentSubtitle();
}

void SubtitleOutput::setCurrentIndexes(const QList<int> &indexes) {
	emit currentIndexesChanged(d->curIdxes = indexes);
	updateCurrentSubtitle();
}

const QList<int> &SubtitleOutput::currentIndexes() const {
	return d->curIdxes;
}

const Subtitle &SubtitleOutput::currentSubtitle() const {
	return d->cursub;
}

int SubtitleOutput::syncDelay() const {
	return d->delay;
}

int SubtitleOutput::pos() const {
	return d->pos;
}

void SubtitleOutput::addSyncDelay(int msec) {
	setSyncDelay(d->delay + msec);
}

void SubtitleOutput::appendSubtitles(const QStringList &files, bool display) {
	QStringList names;
	int index = d->subtitles.size();
	for (int i=0; i<index; ++i)
		names << d->subtitles[i].name();
	for (int i=0; i<files.size(); ++i) {
		SubtitleList subs;
		SubtitleParsers::parse(files[i], &subs, 10);
		d->subtitles += subs;
		for (int j=0; j<subs.size(); ++j, ++index) {
			names << subs[j].name();
			if (display)
				d->curIdxes.append(index);
		}
	}
	emit subtitlesChanged(names);
	if (display)
		setCurrentIndexes(d->curIdxes);
}

void SubtitleOutput::clearSubtitles() {
	if (d->engine)
		d->engine->tellmp("sub_select -1");
	if (!d->subtitles.isEmpty()) {
		d->subtitles.clear();
		emit subtitlesChanged(QStringList());
	}
	if (!d->curIdxes.isEmpty()) {
		d->curIdxes.clear();
		emit currentIndexesChanged(d->curIdxes);
	}
}

void SubtitleOutput::removeCurrentIndex(int index) {
	const int pos = d->curIdxes.indexOf(index);
	if (pos != -1) {
		d->curIdxes.removeAt(pos);
		updateCurrentSubtitle();
		emit currentIndexesChanged(d->curIdxes);
	}
}

void SubtitleOutput::updateCurrentSubtitle() {
	if (!d->engine || !d->engine->isRunning())
		return;
	const Preferences::Subtitle &subset = Preferences::get()->subtitle();
	QList<int> order;
	QList<int> indexes = d->curIdxes;
	for (int i=0; i<subset.classes.size(); ++i) {
		QString lang = subset.classes[i];
		QMutableListIterator<int> it(indexes);
		while(it.hasNext()) {
			if (d->subtitles[it.next()].language() == lang) {
				order.append(it.value());
				it.remove();
			}
		}
	}
	order += indexes;
	d->cursub.clear();
	for (int i=0; i<order.size(); ++i)
		d->cursub |= d->subtitles[order[i]];
	if (d->engine->tellmp("sub_select -1") && d->engine->tellmp("sub_remove")
			&& SubtitleParsers::save(d->tempsub, d->cursub)
			&& d->engine->tellmp("sub_load \"" + d->tempsub + '\"'))
		d->engine->tellmp("sub_select 0");
}

void SubtitleOutput::initSubtitles() {
	static const Preferences::Subtitle &subset = Preferences::get()->subtitle();
	d->subtitles.clear();
	d->curIdxes.clear();
	QStringList names;
	if (d->engine && subset.useAutoLoad) {
		static const QStringList NameFilter = Informations::get()->subtitleFilter().toNameFilter();
		QString dir = QFileInfo(d->engine->currentMediaSource().fileName()).path() + '/';
		QStringList all = QDir(dir).entryList(NameFilter, QDir::Files, QDir::Name);
		QString base = QFileInfo(d->engine->currentMediaSource().fileName()).baseName();
		for (int i=0, idx=0; i<all.size(); ++i) {
			bool select = false;
			bool add = false;
			if (subset.autoLoad == Preferences::Subtitle::Matched) {
				add = base == QFileInfo(all[i]).baseName();
				select = add && subset.autoSelect == Preferences::Subtitle::SameName;
			} else if (subset.autoLoad == Preferences::Subtitle::SamePath) {
				add = true;
				select = subset.autoSelect == Preferences::Subtitle::AllLoaded;
			} else {
				add = all[i].contains(base);
				select = add && subset.autoSelect == Preferences::Subtitle::SameName
						&& base == QFileInfo(all[i]).baseName();
			}
			if (!add)
				continue;
			SubtitleList subs;
			if (!SubtitleParsers::parse(dir + all[i], &subs, 10))
				continue;
			d->subtitles += subs;
			for (int j=0; j<subs.size(); ++j, ++idx) {
				names << subs[j].name();
				if (select || (idx == 0 && subset.autoSelect == Preferences::Subtitle::FirstFile))
					d->curIdxes.append(idx);
			}
		}
	}
	if (!d->subtitles.isEmpty() && d->engine->isRunning())
			updateCurrentSubtitle();
	else if (d->engine && d->engine->tellmp("sub_select -1"))
		 d->engine->tellmp("sub_remove");
	emit subtitlesChanged(names);
	emit currentIndexesChanged(d->curIdxes);
}

void SubtitleOutput::move(int pos, bool relative) {
	d->pos = qBound(0, relative ? d->pos + pos : pos, 100);
	if (d->engine)
		d->engine->tellmp("sub_pos " + QString::number(d->pos) + " 1");
}

void SubtitleOutput::setSyncDelay(int msec) {
	emit syncDelayChanged(d->delay = msec);
	if (d->engine)
		d->engine->tellmp("sub_delay " + QString::number(static_cast<double>(msec)/1000.0) + " 1");
}

void SubtitleOutput::setPlayEngine(PlayEngine *engine) {
	d->engine = engine;
	connect(d->engine, SIGNAL(started()), this, SLOT(updateCurrentSubtitle()));
}

}

