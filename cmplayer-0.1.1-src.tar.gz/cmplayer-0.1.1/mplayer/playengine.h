#ifndef MPLAYERPLAYENGINE_H
#define MPLAYERPLAYENGINE_H

#include <QObject>
#include "mplayer.h"

class QStringList;			class QProcess;
class QSize;

namespace Preferences {class Settings;}

namespace MPlayer {

class MediaSource;				class VideoWidget;
class SubtitleOutput;			class AudioOutput;

class PlayEngine : public QObject {
	Q_OBJECT
public:
	PlayEngine(QObject *parent);
	~PlayEngine();
	const MediaSource &currentMediaSource() const;
	qint64 currentTime() const;
	bool hasVideo() const;
	bool isSeekable() const;
	qint64 remainingTime() const;
	State state() const;
	qint32 tickInterval() const;
	qint64 totalTime() const;
	void setFullScreenState(bool full);
	void expand(qreal ratio);
	inline bool isPlaying() const {return state() == PlayingState;}
	inline bool isPaused() const {return state() == PausedState;}
	inline bool isStopped() const {return state() == StoppedState;}
	bool tellmp(const QString &command);
	VideoWidget *videoWidget() const;
	SubtitleOutput *subtitleOutput() const;
	bool isRunning();
	double speed() const;
public slots:
	void setCurrentMediaSource(const MediaSource &source);
	bool start(qint64 time = 0);
	void stop();
	inline void pause() {if (isPlaying())tellmp("pause");}
	inline void play() {if (isPaused()) tellmp("pause"); else if (isStopped()) start();}
	inline void play(const MediaSource &source, qint64 time) {
		setCurrentMediaSource(source); start(time);}
	inline void seek(qint64 time, bool relative = false) {
		tellmp("seek " + QString::number(static_cast<double>(time)/1000) + (relative ? " 0" : " 2"));}
	void restart();
	void setSpeed(double speed);
signals:
	void currentMediaSourceChanged(const MPlayer::MediaSource &source);
	void aboutToFinished();
	void finished();
	void hasVideoChanged(bool hasVideo);
	void seekableChanged(bool isSeekable);
	void stateChanged(MPlayer::State newstate, MPlayer::State oldstate);
	void tick(qint64 time);
	void totalTimeChanged(qint64 newTotalTime);
	void videoSizeChanged(const QSize &size);
	void started();
	void speedChanged(double speed);
	void stopped(qint64 time);
private slots:
	void interpretMessages();
	void slotStateChanged(MPlayer::State newstate, MPlayer::State oldstate);
	void slotProcFinished();
private:
	class Data;
	friend class Data;
	friend void connect(PlayEngine *engine, VideoWidget *video);
	friend void connect(PlayEngine *engine, SubtitleOutput *subout);
	friend void connect(PlayEngine *engine, AudioOutput *audio);
	void setVideoWidget(VideoWidget *video);
	void setAudioOutput(AudioOutput *audio);
	void setSubtitleOutput(SubtitleOutput *subout);
	Data *d;
};


}

#endif
