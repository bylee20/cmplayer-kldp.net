#include <QApplication>
#include <QFile>
#include <QProcess>
#include <QDir>
#include <QFileInfo>
#include <preferences.h>
#include <prefgeneral.h>
#include <prefsubtitle.h>
#include "playengine.h"
#include "mediasource.h"
#include "videowidget.h"
#include "audiooutput.h"
#include "subtitleoutput.h"
#include "informations.h"
#include "helper.h"

namespace MPlayer {

struct PlayEngine::Data {
	Data(PlayEngine *parent)
	: p(parent), proc(p), pref(Preferences::get())
	, video(0), audio(0), subout(0), state(StoppedState), totalTime(0), curTime(0)
	, fullScreen(false), dontReset(false), justFinished(false), noVideo(true), speed(1.0)
	, dontmessup(Helper::privatePath() +"/input.conf") {
		connect(&proc, SIGNAL(readyReadStandardOutput()), p, SLOT(interpretMessages()));
		connect(&proc, SIGNAL(finished(int, QProcess::ExitStatus)), p, SLOT(slotProcFinished()));
		connect(&proc, SIGNAL(started()), p, SIGNAL(started()));
		connect(p, SIGNAL(stateChanged(MPlayer::State, MPlayer::State)),
				  p, SLOT(slotStateChanged(MPlayer::State, MPlayer::State)));
	}
	void setState(State state) {
		if (this->state != state) {
			State old = this->state;
			emit p->stateChanged(this->state = state, old);
		}
	}
	PlayEngine *p;
	MediaSource source;
	QProcess proc;
	Preferences::Settings *pref;
	VideoWidget *video;
	AudioOutput *audio;
	SubtitleOutput *subout;
	State state;
	qint64 totalTime, curTime;
	bool fullScreen, dontReset, justFinished, noVideo;
	double speed;
	QString dontmessup;
};


PlayEngine::PlayEngine(QObject *parent)
: QObject(parent) {
	d = new Data(this);
	QFile file(d->dontmessup);
	if (!file.exists() && file.open(QFile::WriteOnly)) {
		file.write(
			"## prevent mplayer from messing up our shortcuts\n\n"
			"RIGHT gui_about\nLEFT gui_about\nDOWN gui_about\n"
			"UP gui_about\nPGUP gui_about\nPGDWN gui_about\n"
			"- gui_about\n+ gui_about\nESC gui_about\nENTER gui_about\n"
			"SPACE pausing_keep invalid_command\nHOME gui_about\n"
			"END gui_about\n> gui_about\n< gui_about\nINS gui_about\n"
			"DEL gui_about\n[ gui_about\n] gui_about\n{ gui_about\n"
			"} gui_about\nBS gui_about\nTAB gui_about\n. gui_about\n"
			"# gui_about\n@ gui_about\n! gui_about\n9 gui_about\n"
			"/ gui_about\n0 gui_about\n* gui_about\n1 gui_about\n"
			"2 gui_about\n3 gui_about\n4 gui_about\n5 gui_about\n"
			"6 gui_about\n7 gui_about\n8 gui_about\na gui_about\n"
			"b gui_about\nc gui_about\nd gui_about\ne gui_about\n"
			"F invalid_command\nf invalid_command\ng gui_about\n"
			"h gui_about\ni gui_about\nj gui_about\nk gui_about\n"
			"l gui_about\nm gui_about\nn gui_about\no gui_about\n"
			"p gui_about\nq gui_about\nr gui_about\ns gui_about\n"
			"t gui_about\nT gui_about\nu gui_about\nv gui_about\n"
			"w gui_about\nx gui_about\ny gui_about\nz gui_about\n"
			"S gui_about\n"
		);
	}
}

PlayEngine::~PlayEngine() {
	delete d;
}

void PlayEngine::slotStateChanged(MPlayer::State newState, MPlayer::State oldState) {
	if (isSeekable() && oldState == StoppedState)
		emit seekableChanged(true);
	else if (!isSeekable() && oldState != StoppedState)
		emit seekableChanged(false);
	if (oldState == StoppedState && newState == PlayingState) {
		if (d->audio)
			d->audio->setVolume(d->pref->general().resetVolume
					? d->pref->general().defaultVolume : d->audio->volume());
	}
}

void PlayEngine::slotProcFinished() {
	d->setState(StoppedState);
	if (d->justFinished) {
		emit finished();
		d->justFinished = false;
	}
}

void PlayEngine::stop() {
	qint64 time = d->curTime;
	if (d->state == StoppedState || !tellmp("quit"))
		return;
	emit stopped(time);
	if (!d->proc.waitForFinished(5000))
		d->proc.kill();
}

void PlayEngine::interpretMessages() {
	static bool initializing = false;
	static int subID = 0;
	static QStringList subs;
	static QRegExp rxAV("^[AV]: *([0-9,:.-]+)");
	static QRegExp rxVO("^VO: \\[(.*)\\] (\\d+)x(\\d+) => (\\d+)x(\\d+)");
	static QRegExp rxID("^ID_(.*)=(.*)");
	static QRegExp rxInitStart("^Playing (.+)");
	static QRegExp rxInitEnd("^Starting playback.+");
	static QRegExp rxFinished("^Exiting\\.+\\s+\\(End of file\\)");
	static QRegExp rxNoVideo("^Video:\\s+no d->video");
	static QRegExp rxLineBreak("[\\n\\r]");
	QStringList lines = QString::fromLocal8Bit(d->proc.readAllStandardOutput()).split(rxLineBreak);
	for (int i=0; i<lines.size(); ++i) {
		const QString &message = lines[i];
		if (message.isEmpty())
			continue;
		if (rxAV.indexIn(message) != -1) {
			qint64 msec = static_cast<int>(rxAV.cap(1).toDouble()*1000);
			d->setState(PlayingState);
			emit tick(d->curTime = msec);
		} else if (message.contains(" PAUSE ")) 
			d->setState(PausedState);
		else if (rxNoVideo.indexIn(message) != -1) {
			d->noVideo = true;
		} else if (rxVO.indexIn(message) != -1) {
			emit videoSizeChanged(QSize(rxVO.cap(2).toInt(), rxVO.cap(3).toInt()));
		} else if (rxInitStart.indexIn(message) != -1) {
			initializing = true;
			subs.clear();
		} else if (rxInitEnd.indexIn(message) != -1) {
			initializing = false;
			d->dontReset = false;
		} else if (rxFinished.indexIn(message) != -1) {
			emit aboutToFinished();
			d->justFinished = true;
		} else if (rxID.indexIn(message) != -1) {
			QString id = rxID.cap(1);
			if (id == "LENGTH")
				emit totalTimeChanged(d->totalTime = static_cast<int>(rxID.cap(2).toDouble()*1000));
			else if (id == "FILE_SUB_ID") {
				subID = rxID.cap(2).toInt();
			} else if (id == "FILE_SUB_FILENAME" && subID != 0)
				subs.append(rxID.cap(2));
		}
	}
}

bool PlayEngine::start(qint64 time) {
	if (d->proc.state() != QProcess::NotRunning)
		stop();
	if (d->source.fileName().isEmpty())
		return false;

	static const Preferences::General &general = d->pref->general();
	static const Preferences::Subtitle &subtitle = d->pref->subtitle();
	
	if (!d->dontReset) {
		if (d->video) {
			d->video->setGamma(0);
			d->video->setBrightness(0);
			d->video->setContrast(0);
			d->video->setHue(0);
			d->video->setSaturation(0);
		}
		if (d->subout) {
			d->subout->initSubtitles();
			d->subout->setSyncDelay(0);
		}
		if (d->audio && general.resetVolume) {
			d->audio->setVolume(general.defaultVolume);
		}
		setSpeed(1.0);
	}
	
	QStringList args;
	args << "-slave" << "-noquiet" << "-nofs" <<  "-identify"
		<< "-input" << "conf=\"" + d->dontmessup + '"' << "-fontconfig"
		<< "-zoom" << "-nokeepaspect";
	if (d->video)
		args << "-wid" << QString::number(d->video->videoWID());
	if (general.useSoftwareEqualizer)
		args << "-vf-add" << "eq2";
	if (general.useExpand && (!general.expandOnlyFullScreen || d->fullScreen))
		args << "-vf-add" << "expand=:::::" + QString::number(general.expandWidth/general.expandHeight);
	if (general.useSoftwareVolume)
		args << "-softvol" << "-softvol-max" << QString::number(general.volumeAmplification);
#define addPrefArg(arg, str) \
	if (!str.isEmpty()) \
		args << arg << str;
	addPrefArg("-vo", general.videoOutput)
	addPrefArg("-ao", general.audioOutput)
	addPrefArg("-font", subtitle.family)
	addPrefArg("-subcp", subtitle.encoding)
#undef addPrefArg
	args << "-subfont-text-scale" << QString::number(subtitle.defaultScale)
			<< "-subfont-autoscale" << QString::number(subtitle.autoScale)
			<< "-subpos" << QString::number(subtitle.initialPosition)
			<< "-subdelay" << QString::number(static_cast<double>(d->subout->syncDelay())/1000.0)
			<< "-noautosub";

	if (general.autoPitch)
		args << "-af" << "scaletempo";
	if (time > 1000)
		args << "-ss" << QString::number(static_cast<double>(time)/1000.0);
	
	if (!general.additionalOptions.isEmpty())
		args += general.additionalOptions.split(' ');
	
	args << d->source.fileName();
	
	d->proc.start(d->pref->general().mplayerPath, args);
	if (!d->proc.waitForStarted())
		return false;
	tellmp("speed_set " + QString::number(d->speed));
	return true;
}

void PlayEngine::setCurrentMediaSource(const MediaSource &source) {
	if (d->source != source)
		emit currentMediaSourceChanged(d->source = source);
}

void PlayEngine::setFullScreenState(bool full) {
	if (d->fullScreen != full) {
		d->fullScreen = full;
		static const Preferences::General &general = d->pref->general();
		if (general.useExpand && general.expandOnlyFullScreen)
			restart();
	}
}

bool PlayEngine::tellmp(const QString &command) {
	if (isRunning()) {
		d->proc.write(command.toLocal8Bit() + "\n");
		return true;
	}
	return false;
}

bool PlayEngine::isRunning() {
	return d->proc.state() != QProcess::NotRunning;
}

void PlayEngine::setSpeed(double speed) {
	if (d->speed != speed) {
		emit speedChanged(d->speed = qBound(0.1, speed, 100.0));
		tellmp("speed_set " + QString::number(d->speed));
	}
}


void PlayEngine::restart() {
	pause();
	d->dontReset = true;
	start(d->curTime);
}

void PlayEngine::setVideoWidget(VideoWidget *video) {
	d->video = video;
}

void PlayEngine::setAudioOutput(AudioOutput *audio) {
	d->audio = audio;
}

void PlayEngine::setSubtitleOutput(SubtitleOutput *subout) {
	d->subout = subout;
}

double PlayEngine::speed() const {
	return d->speed;
}

const MediaSource &PlayEngine::currentMediaSource() const {
	return d->source;
}

qint64 PlayEngine::currentTime() const {
	return d->curTime;
}

bool PlayEngine::hasVideo() const {
	return !d->noVideo;
}

bool PlayEngine::isSeekable() const {
	return d->state != StoppedState;
}

qint64 PlayEngine::remainingTime() const {
	return d->totalTime - d->curTime;
}

State PlayEngine::state() const {
	return d->state;
}

qint32 PlayEngine::tickInterval() const {
	return 100;
}

qint64 PlayEngine::totalTime() const {
	return d->totalTime;
}

VideoWidget *PlayEngine::videoWidget() const {
	return d->video;
}

SubtitleOutput *PlayEngine::subtitleOutput() const {
	return d->subout;
}


}
