#include "mediasource.h"

namespace MPlayer {

MediaSource::MediaSource()
: m_type(Invalid)
, m_url() {}

MediaSource::MediaSource(const QString &fileName)
: m_type(LocalFile)
, m_url(QUrl::fromLocalFile(fileName)) {}

MediaSource::MediaSource(const QUrl &url)
: m_type(LocalFile)
, m_url(url) {}

MediaSource::MediaSource(const MediaSource &other)
: m_type(other.m_type)
, m_url(other.m_url) {}

MediaSource::~MediaSource() {}

}
