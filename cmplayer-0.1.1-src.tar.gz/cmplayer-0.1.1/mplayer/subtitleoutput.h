#ifndef MPLAYERSUBTITLEMANAGER_H
#define MPLAYERSUBTITLEMANAGER_H

#include <QObject>

class Subtitle;

namespace MPlayer {

class PlayEngine;

class SubtitleOutput : public QObject {
	Q_OBJECT
public:
	SubtitleOutput(QObject *parent = 0);
	~SubtitleOutput();
	void initSubtitles();
	void appendSubtitles(const QStringList &files, bool display);
	void removeCurrentIndex(int index);
	const QList<Subtitle> &subtitleList() const;
	inline void appendCurrentIndex(int index) {appendCurrentIndexes(QList<int>() << index);}
	void appendCurrentIndexes(const QList<int> &indexes);
	void setCurrentIndexes(const QList<int> &indexes);
	inline void setCurrentIndex(int index) {setCurrentIndexes(QList<int>() << index);}
	const QList<int> &currentIndexes() const;
	const Subtitle &currentSubtitle() const;
	int syncDelay() const;
	int pos() const;
public slots:
	void move(int pos, bool relative = false);
	void clearSubtitles();
	void updateCurrentSubtitle();
	void setSyncDelay(int msec);
	void addSyncDelay(int msec);
signals:
	void subtitlesChanged(const QStringList &names);
	void currentIndexesChanged(const QList<int> &indexes);
	void syncDelayChanged(int);
private:
	struct Data;
	friend struct Data;
	friend void connect(PlayEngine *meida, SubtitleOutput *subout);
	void setPlayEngine(PlayEngine *engine);
	Data *d;
};

}

#endif
