#include <QRegExp>
#include <QProcess>
#include "informations.h"
#include "preferences.h"
#include "prefgeneral.h"

namespace MPlayer {

QString Informations::Extensions::toFilter() const {
	QString filter;
	for (QStringList::const_iterator it = begin(); it != end(); ++it)
		filter += "*." + *it + ' ';
	const int size = filter.size();
	if (size) {
		filter.remove(size-1, 1);
		return '(' + filter + ')';
	} else
		return QString();
}

QStringList Informations::Extensions::toNameFilter() const {
	QStringList nameFilter;
	for (QStringList::const_iterator it = begin(); it != end(); ++it)
		nameFilter << "*." + *it;
	return nameFilter;
}

Informations::Informations() {
	m_ves << "asf" << "avi" << "dvix" << "mkv" << "mov" << "mp4" << "mpeg" << "mpg"
		<< "vob" << "ogg" << "ogm"<< "qt" << "rm" << "wmv";
	m_aes << "mp3" << "ogg" << "ra" << "wav" << "wma";
	m_ses << "smi" << "srt";
}


void Informations::getInfo() const {
	QProcess proc;
	QStringList args;
	args << "-identify" << "-vo" << "help" << "-ao" << "help";
	proc.start(Preferences::get()->general().mplayerPath, args);
	if (!proc.waitForFinished())
		proc.kill();
	static QRegExp rxOuts("(\\s+)(\\S+)(.*)");
	static QRegExp rxVO("^ID_VIDEO_OUTPUTS");
	static QRegExp rxAO("^ID_AUDIO_OUTPUTS");
	enum What {Nothing = 0, VO = 1, AO = 2};
	What what = Nothing;
	m_vos.clear();
	m_aos.clear();
	while (proc.canReadLine()) {
		QString line = QString::fromLocal8Bit(proc.readLine());
		line.replace("\n", "");
		line.replace("\r", "");
		if (rxVO.indexIn(line) != -1)
			what = VO;
		else if (rxAO.indexIn(line) != -1)
			what = AO;
		else if (line.isEmpty())
			what = Nothing;
		else if (what == VO) {
			if (rxOuts.indexIn(line) != -1)
				m_vos.append(rxOuts.cap(2));
		} else if (what == AO) {
			if (rxOuts.indexIn(line) != -1)
				m_aos.append(rxOuts.cap(2));
		}
	}
}


}
