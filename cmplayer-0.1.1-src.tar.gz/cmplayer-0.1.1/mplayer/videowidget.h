#ifndef MPLAYERVIDEOWIDGET_H
#define MPLAYERVIDEOWIDGET_H

#include <QWidget>

namespace MPlayer {

class PlayEngine;

class VideoWidget : public QWidget {
	Q_OBJECT
public:
	static const qreal CropOff = 0.0;
	static const qreal AspectRatioAuto = -1.0;
	static const qreal AspectRatioWidget = 0.0;
	VideoWidget(QWidget *parent = 0);
	~VideoWidget();
	PlayEngine *playEngine() const;
	virtual QSize sizeHint() const;
	const QSize &videoSize() const;
	qreal aspectRatio() const;
	qreal cropRatio() const;
	bool cropOn() const;
	int videoWID() const;
	int brightness() const;
	int contrast() const;
	int gamma() const;
	int hue() const;
	int saturation() const;
public slots:
	void updateVideo();
	void setBrightness(int value);
	void setContrast(int value);
	void setGamma(int value);
	void setHue(int value);
	void setSaturation(int value);
	void crop(qreal ratio);
	void setAspectRatio(qreal ratio);
signals:
	void sizeHintChanged(const QSize &size);
	void resized(const QSize &size);
protected:
	void resizeEvent(QResizeEvent *event);
	void mouseMoveEvent(QMouseEvent *event);
	void paintEvent(QPaintEvent *event);
	bool eventFilter(QObject *obj, QEvent *event);
private slots:
	void updateVisual();
	void hideCursor() {if (cursor().shape() != Qt::BlankCursor) setCursor(Qt::BlankCursor);}
	void setVideoSize(const QSize &size);
private:
	struct Data;
	friend struct Data;
	friend void connect(PlayEngine *engine, VideoWidget *video);
	void setPlayEngine(PlayEngine *engine);
	Data *d;
};

}



#endif

