#include "audiooutput.h"
#include "playengine.h"

namespace MPlayer {

AudioOutput::AudioOutput(QObject *parent)
: QObject(parent), m_engine(0), m_muted(false), m_volume(100) {}

AudioOutput::~AudioOutput() {}

void AudioOutput::setPlayEngine(PlayEngine *engine) {
	m_engine = engine;
	connect(m_engine, SIGNAL(started()), this, SLOT(updateAudio()));
}

void AudioOutput::setVolume(int volume, bool relative) {
	emit volumeChanged(m_volume = qBound(0, relative ? m_volume + volume : volume, 100));
	if (m_engine)
		 m_engine->tellmp("volume " + QString::number(m_volume) + " 1");
}

void AudioOutput::setMuted(bool muted) {
	emit mutedChanged(m_muted = muted);
	if (m_engine)
		m_engine->tellmp("mute " + QString::number(m_muted ? 1 : 0));
}

void AudioOutput::updateAudio() {
	if (!m_engine)
		return;
	m_engine->tellmp("volume " + QString::number(m_volume) + " 1");
	m_engine->tellmp("mute " + QString::number(m_muted ? 1 : 0));
}

}
