#ifndef MPLAYER_H
#define MPLAYER_H

namespace MPlayer {

class PlayEngine;				class VideoWidget;
class MediaSource;			class SubtitleOutput;
class AudioOutput;

enum State {
	StoppedState = 1,
	PlayingState = 2,
	PausedState = 4,
};

void connect(PlayEngine *engine, VideoWidget *video);
void connect(PlayEngine *engine, SubtitleOutput *subout);
void connect(PlayEngine *engine, AudioOutput *audio);

}

#endif
