#ifndef MPLAYERMPMEDIASOURCE_H
#define MPLAYERMPMEDIASOURCE_H

#include <QUrl>

namespace MPlayer {

class MediaSource{
public:
	enum Type {Invalid = 0, LocalFile = 1, Url = 2, Disc = 3, Stream = 4};
	MediaSource();
	MediaSource(const QString &fileName);
	MediaSource(const QUrl &url);
	MediaSource(const MediaSource &other);
	~MediaSource();
	inline MediaSource &operator= (const MediaSource &other) {
		if (this != &other) {m_type = other.m_type; m_url = other.m_url;} return *this;}
	inline bool operator== (const MediaSource &other) const {
		return m_type == other.m_type && m_url == other.m_url;}
	inline bool operator!= (const MediaSource &other) const {
		return m_type != other.m_type || m_url != other.m_url;}
	inline QString fileName() const {return m_url.toLocalFile();}
	inline Type type () const {return m_type;}
	inline QUrl url () const {return m_type == LocalFile ? m_url : QUrl();}
private:
	Type m_type;
	QUrl m_url;
};

}

#endif
