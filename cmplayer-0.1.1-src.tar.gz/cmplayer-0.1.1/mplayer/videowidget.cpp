#include <QEvent>
#include <QPainter>
#include <QTimer>
#include "videowidget.h"
#include "playengine.h"

namespace MPlayer {

struct VideoWidget::Data {
	Data(VideoWidget *parent)
	: p(parent), engine(0), visual(new QWidget(p)), video(new QWidget(visual))
	, mouseTimer(new QTimer(p)), cropRatio(CropOff), aspectRatio(AspectRatioAuto)
	, brightness(0), contrast(0), gamma(0), hue(0), saturation(0) {
		p->setStyleSheet("background-color: black;");
		p->setMouseTracking(true);

		video->setStyleSheet("background-color: black;");
		visual->setMouseTracking(true);
		visual->move(0, 0);
		visual->resize(40, 30);

		video->setMouseTracking(true);
		video->setAutoFillBackground(true);
		video->setAttribute(Qt::WA_NoSystemBackground);
		video->setAttribute(Qt::WA_StaticContents);
		video->setAttribute(Qt::WA_PaintOnScreen);
		video->setAttribute(Qt::WA_PaintUnclipped);
		videoSize.scale(4, 3, Qt::IgnoreAspectRatio);
		video->resize(40, 30);
		video->installEventFilter(p);

		mouseTimer->setSingleShot(true);
		mouseTimer->setInterval(3000);
		connect(mouseTimer, SIGNAL(timeout()), p, SLOT(hideCursor()));
	}
	static bool isSame(qreal n1, qreal n2, qreal prec = 0.001) {
		return qAbs(n1 - n2) < prec;
	}
	static void scaleWidget(QWidget *widget, int w, int h, Qt::AspectRatioMode mode) {
		QSize size(widget->size());
		if (w > 0 && h > 0) {
			size.scale(w, h, mode);
			widget->resize(size);
		} else
			widget->resize(w, h);
	}
	static void drawBG(QWidget *widget, const QColor &color = Qt::black) {
		QPainter painter(widget);
		painter.fillRect(widget->rect(), color);
	}
	VideoWidget *p;
	MPlayer::PlayEngine *engine;
	QWidget *visual, *video;
	QTimer *mouseTimer;
	qreal cropRatio, aspectRatio;
	int brightness, contrast, gamma, hue, saturation;
	QSize videoSize;
};
	
VideoWidget::VideoWidget(QWidget *parent)
: QWidget(parent) {
	d = new Data(this);
}

VideoWidget::~VideoWidget() {
	delete d;
}

PlayEngine *VideoWidget::playEngine() const {
	return d->engine;
}

const QSize &VideoWidget::videoSize() const {
	return d->videoSize;
}

qreal VideoWidget::aspectRatio() const {
	return d->aspectRatio;
}

qreal VideoWidget::cropRatio() const {
	return d->cropRatio;
}

bool VideoWidget::cropOn() const {
	return !Data::isSame(CropOff, d->cropRatio);
}

int VideoWidget::videoWID() const {
	return int(d->video->winId());
}

int VideoWidget::brightness() const {
	return d->brightness;
}

int VideoWidget::contrast() const {
	return d->contrast;
}

int VideoWidget::gamma() const {
	return d->gamma;
}

int VideoWidget::hue() const {
	return d->hue;
}

int VideoWidget::saturation() const {
	return d->saturation;
}

void VideoWidget::crop(qreal ratio) {
	d->cropRatio = ratio;
	updateVisual();
}

void VideoWidget::setAspectRatio(qreal ratio) {
	d->aspectRatio = ratio;
	updateVisual();
}

bool VideoWidget::eventFilter(QObject *obj, QEvent *event) {
	if (obj == d->video && event->type() == QEvent::Paint && (!d->engine || d->engine->isStopped())) {
		Data::drawBG(d->video);
		return true;
	} else
		return QWidget::eventFilter(obj, event);
}
	
void VideoWidget::resizeEvent(QResizeEvent *event) {
	QWidget::resizeEvent(event);
	updateVisual();
	emit resized(size());
}


void VideoWidget::paintEvent(QPaintEvent *event) {
	QWidget::paintEvent(event);
	Data::drawBG(this);
}

void VideoWidget::mouseMoveEvent(QMouseEvent *event) {
	QWidget::mouseMoveEvent(event);
	d->mouseTimer->stop();
	if (cursor().shape() != Qt::ArrowCursor)
		setCursor(Qt::ArrowCursor);
	d->mouseTimer->start();
}

void VideoWidget::setVideoSize(const QSize &size) {
	if (size != d->videoSize) {
		emit sizeHintChanged(d->videoSize = size);
		updateVisual();
	}
}

void VideoWidget::updateVisual() {
	qreal ratio;
	if (Data::isSame(d->aspectRatio, AspectRatioAuto))
		ratio = static_cast<qreal>(d->videoSize.width()) / d->videoSize.height();
	else if (Data::isSame(d->aspectRatio, AspectRatioWidget))
		ratio = static_cast<qreal>(width()) / height();
	else
		ratio = d->aspectRatio;
	int backw = d->visual->width();
	int backh = d->visual->height();
	int w = d->video->width(), h = d->video->height(), x = 0, y = 0;
	if (ratio > 0.0) {
		double backRatio = static_cast<qreal>(backw) /backh;
		if (backRatio > ratio) {
			w = static_cast<int>(h*ratio);
			x = (backw - w)/2;
		} else {
			h = static_cast<int>(w/ratio);
			y = (backh - h)/2;
		}
		d->video->resize(w, h);
	}
	
	backw = width();
	backh = height();
	w = d->visual->width();
	h = d->visual->height();
	if (cropOn()) {
		double backRatio = static_cast<qreal>(backw) / backh;
		if (backRatio > d->cropRatio)
			w = static_cast<int>(h * d->cropRatio);
		else
			h = static_cast<int>(w / d->cropRatio);
		d->visual->resize(w, h);
		Data::scaleWidget(d->visual, backw, backh, Qt::KeepAspectRatio);
		w = d->visual->width();
		h = d->visual->height();
		Data::scaleWidget(d->video, w, h, Qt::KeepAspectRatioByExpanding);
	} else {
		d->visual->resize(w = backw, h = backh);
		Data::scaleWidget(d->video, w, h, Qt::KeepAspectRatio);
	}
	d->visual->move((backw-w)/2, (backh-h)/2);
	d->video->move((w-d->video->width())/2, (h-d->video->height())/2);
}

QSize VideoWidget::sizeHint() const {
	if (cropOn()) {
		QSize hint = d->visual->size();
		hint.scale(d->videoSize, Qt::KeepAspectRatio);
		return hint;
	} else
		return d->videoSize;
}

void VideoWidget::setPlayEngine(PlayEngine *engine) {
	d->engine = engine;
	connect(engine, SIGNAL(videoSizeChanged(const QSize&)), this, SLOT(setVideoSize(const QSize&)));
	connect(engine, SIGNAL(started()), this, SLOT(updateVideo()));
}

void VideoWidget::setBrightness(int value) {
	d->brightness = qBound(-100, value, 100);
	if (d->engine)
		d->engine->tellmp("brightness " + QString::number(d->brightness) + " 1");
}

void VideoWidget::setContrast(int value) {
	d->contrast = qBound(-100, value, 100);
	if (d->engine)
		d->engine->tellmp("contrast " + QString::number(d->contrast) + " 1");
}

void VideoWidget::setGamma(int value) {
	d->gamma = qBound(-100, value, 100);
	if (d->engine)
		d->engine->tellmp("gamma " + QString::number(d->gamma) + " 1");
}

void VideoWidget::setHue(int value) {
	d->hue = qBound(-100, value, 100);
	if (d->engine)
		d->engine->tellmp("hue " + QString::number(d->hue) + " 1");
}

void VideoWidget::setSaturation(int value) {
	d->saturation = qBound(-100, value, 100);
	if (d->engine)
		d->engine->tellmp("saturation " + QString::number(d->saturation) + " 1");
}

void VideoWidget::updateVideo() {
	d->engine->tellmp("brightness " + QString::number(d->brightness) + " 1");
	d->engine->tellmp("contrast " + QString::number(d->contrast) + " 1");
	d->engine->tellmp("gamma " + QString::number(d->gamma) + " 1");
	d->engine->tellmp("hue " + QString::number(d->hue) + " 1");
	d->engine->tellmp("saturation " + QString::number(d->saturation) + " 1");
	updateVisual();
}


}
