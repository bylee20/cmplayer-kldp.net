#ifndef SINGLETONINTERFACE_H
#define SINGLETONINTERFACE_H

#define SINGLE(Class) friend Class *SingletonInterface<Class>::get();

template <class T>
class SingletonInterface {
public:
	inline static T *get() {static T obj; return &obj;}
	inline virtual ~SingletonInterface() {}
protected:
	inline SingletonInterface() {}
};

#endif

