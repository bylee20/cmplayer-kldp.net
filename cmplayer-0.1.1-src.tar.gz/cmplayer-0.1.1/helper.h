#ifndef HELPER_H
#define HELPER_H

#include "singletoninterface.h"

class Helper : public SingletonInterface<Helper> {
	SINGLE(Helper)
public:
	~Helper();
	static const QString &configFile();
	static const QString &appPath();
	static const QString &recentFile();
	static const QString &menuFile();
	static const QString &homePath();
	static const QString &privatePath();
	static const char *const version() {return "0.1.1";}
private:
	struct Data;
	friend struct Data;
	Helper();
	Data *d;
};

#endif
