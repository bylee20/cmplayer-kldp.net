#include "subtitleparsers/abstractparser.h"

class Subtitle;

namespace SubtitleParsers {

class AbstractParser;

bool parse(const QString &file, SubtitleList *subs, int minimumInterval = 10);
bool save(const QString &file, const Subtitle &sub);
AbstractParser *getNewParser(const QString &extension);

}
