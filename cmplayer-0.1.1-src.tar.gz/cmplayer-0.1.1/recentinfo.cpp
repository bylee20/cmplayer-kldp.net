#include <QSettings>
#include <mplayer/mediasource.h>
#include "preferences.h"
#include "prefgeneral.h"
#include "playlistmodel.h"
#include "helper.h"
#include "recentinfo.h"

RecentStack::RecentStack(int size)
: QStringList() {
	setSize(size);
}

RecentInfo::RecentInfo(): m_files(DefaultRememberCount) {}

void RecentInfo::setStopped(const QString &file, qint64 time) {
	if (Preferences::get()->general().playFromStoppedPoint)
		m_stopped[file] = time;
}

void RecentInfo::setFinished(const QString &file) {
	m_stopped.remove(file);
}

qint64 RecentInfo::stoppedTime(const QString &file) {
	if (Preferences::get()->general().playFromStoppedPoint)
		return m_stopped.value(file, 0);
	else
		return 0;
}

void RecentInfo::setFiles(const QStringList &files) {
	emit filesChanged(m_files = files);
}

void RecentInfo::stackFile(const QString &file) {
	m_files.stack(file);
	emit filesChanged(m_files);
}

void RecentInfo::load() {
	QSettings set(Helper::recentFile(), QSettings::IniFormat);
	set.beginGroup("RecentInfo");
	setFiles(set.value("Files", QStringList()).toStringList());
	QStringList list = set.value("PlayList", QStringList()).toStringList();
	for (int i=0; i<list.size(); ++i)
		m_list->append(list[i]);
	m_list->setCurrentRow(set.value("CurrentRow", -1).toInt());
	if (Preferences::get()->general().playFromStoppedPoint) {
		const int size = set.beginReadArray("StoppedList");
		for (int i=0; i<size; ++i) {
			set.setArrayIndex(i);
			m_stopped.insert(set.value("File").toString(), set.value("Time").toLongLong());
		}
		set.endArray();
	}
	set.endGroup();
}

void RecentInfo::save() const {
	QSettings set(Helper::recentFile(), QSettings::IniFormat);
	set.beginGroup("RecentInfo");
	set.setValue("Files", m_files.toStringList());
	QStringList list;
	for (int i=0; i<m_list->rowCount(); ++i)
		list << m_list->mediaSource(i).fileName();
	set.setValue("PlayList", list);
	set.setValue("CurrentRow", m_list->currentRow());
	if (Preferences::get()->general().playFromStoppedPoint) {
		const int size = m_stopped.size();
		set.beginWriteArray("StoppedList", size);
		int i=0;
		for (StoppedInfo::const_iterator it = m_stopped.begin(); it != m_stopped.end(); ++it, ++i) {
			set.setArrayIndex(i);
			set.setValue("File", it.key());
			set.setValue("Time", it.value());
		}
		set.endArray();
	}
	set.endGroup();
}

