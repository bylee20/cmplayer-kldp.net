#ifndef ABREPEATER_H
#define ABREPEATER_H

#include <QObject>
#include "singletoninterface.h"

namespace MPlayer {class PlayEngine;}
class QTimer;

class ABRepeater : public QObject, public SingletonInterface<ABRepeater> {
	SINGLE(ABRepeater)
	Q_OBJECT
public:
	qint64 setAToCurrentTime();
	qint64 setBToCurrentTime();
	qint64 setAToSubtitleTime();
	qint64 setBToSubtitleTime();
	inline void setA(qint64 a) {m_a = a;}
	inline void setB(qint64 b) {m_b = b;}
	bool start(int times = 0);
	inline bool repeat(qint64 a, qint64 b, int times = 0) {m_a = a; m_b = b; return start(times);}
	void setPlayEngine(MPlayer::PlayEngine *engine);
	inline bool isRepeating() {return m_repeating;}
	inline qint64 a() const {return m_a;}
	inline qint64 b() const {return m_b;}
public slots:
	void stop();
private slots:
	void slotTimer();
private:
	ABRepeater();
	MPlayer::PlayEngine *m_engine;
	QTimer *m_timer;
	qint64 m_a, m_b;
	bool m_repeating;
	int m_times, m_nth;
};

#endif
