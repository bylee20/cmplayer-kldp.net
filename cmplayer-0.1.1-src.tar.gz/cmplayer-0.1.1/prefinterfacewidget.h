#ifndef PREFERENCESPREFINTERFACEWIDGET_H
#define PREFERENCESPREFINTERFACEWIDGET_H

#include <QWidget>

class QTreeWidgetItem;
class ActionCollection;

namespace Preferences {

class Interface;
namespace Ui {class Ui_InterfaceWidget;}

class InterfaceWidget : public QWidget {
	Q_OBJECT
public:
	InterfaceWidget(const Interface &interface, QWidget *parent = 0);
	~InterfaceWidget();
	const Interface &interface() const;
private slots:
	void getShortcut(QTreeWidgetItem *item);
	bool eraseAction();
	void insertAction();
	void actionUp();
	void actionDown();
private:
	void moveAction(bool up);
	void insertItem(QTreeWidgetItem *item);
	Ui::Ui_InterfaceWidget *ui;
	mutable Interface *m_interface;
	const ActionCollection *const m_ac;
};

}

#endif
