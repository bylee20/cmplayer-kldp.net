#ifndef MPLAYERPLAYLISTMODEL_H
#define MPLAYERPLAYLISTMODEL_H

#include <QAbstractTableModel>

namespace MPlayer {class PlayEngine;				class MediaSource;}

class PlayListModel : public QAbstractTableModel {
	Q_OBJECT
public:
	PlayListModel(MPlayer::PlayEngine *engine, QObject *parent = 0);
	~PlayListModel();
	int rowCount(const QModelIndex &parent = QModelIndex()) const;
	int columnCount(const QModelIndex &parent = QModelIndex()) const;
	QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
	QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const;
	bool append(const MPlayer::MediaSource &source);
	bool swap(int row1, int row2);
	bool insert(int row, const MPlayer::MediaSource &source);
	MPlayer::MediaSource mediaSource(int row) const;
	bool setMediaSource(int row, const MPlayer::MediaSource &source);
	int currentRow() const;
	MPlayer::MediaSource currentMediaSource() const;
	void play(const MPlayer::MediaSource &source);
	bool save(const QString &fileName) const;
	bool load(const QString &fileName);
	bool setCurrentRow(int row);
public slots:
	void playNext();
	void playPrevious();
	void clear();
	bool play(int row);
	bool remove(int row);
	void setLoop(bool loop);
signals:
	void finished();
	void currentRowChanged(int row);
	void rowCountChanged(int count);
private slots:
	void play(const QModelIndex &index);
private:
	struct Data;
	friend struct Data;
	Data *d;
};


#endif
