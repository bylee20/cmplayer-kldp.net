#ifndef MENUTREEREADER_H
#define MENUTREEREADER_H

#include <QXmlStreamReader>

class QMenu;					class ActionCollection;

class MenuTreeReader : public QXmlStreamReader {
public:
	MenuTreeReader();
	bool read(QMenu *menu, const QString &file);
private:
	void readAction();
	void readMenu();
	void readRoot();
	void readAny();
	ActionCollection *m_ac;
	QMenu *m_menu;
	QMenu *m_curParent;
};

#endif
