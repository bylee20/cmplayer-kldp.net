#include <QTextStream>
#include <QSettings>
#include <QApplication>
#include <QRegExp>
#include <QFileDialog>
#include <QProcess>
#include <QTimer>
#include <QMessageBox>
#include <QFile>
#include <mplayer/informations.h>
#include <mplayer/mediasource.h>
#include "playlistdock.h"
#include "ui_getpassworddialog.h"
#include "ui_playlistwidget.h"
#include "playlistmodel.h"

struct PlayListDock::Data {
	Data(PlayListModel *model, PlayListDock *parent)
	: p(parent), model(model), proc(new QProcess(p)), timer(new QTimer(p))
	, pwd(new QDialog(p)), checking(false), adding(false) {
		QWidget *w = new QWidget(p);
		ui.setupUi(w);
		p->setWidget(w);
		p->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
		pwUi.setupUi(pwd);
		timer->setInterval(700);
		timer->setSingleShot(true);
	
		connect(ui.open_button, SIGNAL(clicked()), p, SLOT(open()));
		connect(ui.add_button, SIGNAL(clicked()), p, SLOT(add()));
		connect(ui.erase_button, SIGNAL(clicked()), p, SLOT(erase()));
		connect(ui.up_button, SIGNAL(clicked()), p, SLOT(up()));
		connect(ui.down_button, SIGNAL(clicked()), p, SLOT(down()));
		connect(ui.clear_button, SIGNAL(clicked()), model, SLOT(clear()));
		connect(ui.close_button, SIGNAL(clicked()), p, SLOT(hide()));
		connect(ui.list, SIGNAL(activated(const QModelIndex&)), model, SLOT(play(const QModelIndex&)));
		connect(ui.shutdown_check, SIGNAL(toggled(bool)), p, SLOT(checkRoot(bool)));
		connect(ui.save_button, SIGNAL(clicked()), p, SLOT(save()));
		connect(pwUi.ok_button, SIGNAL(clicked()), p, SLOT(checkPassword()));	
		connect(proc, SIGNAL(readyReadStandardOutput()), p, SLOT(readStdOut()));
		connect(timer, SIGNAL(timeout()), p, SLOT(slotTimer()));
		connect(model, SIGNAL(finished()), p, SLOT(checkShutdown()));
		identified = false;
		ui.list->setModel(model);
		p->setWindowTitle(trUtf8("재생 목록"));
	}
	void move(bool up) {
		const int row = ui.list->currentIndex().row();
		int target = up ? row-1 : row + 1;
		if (model->swap(row, target))
			ui.list->setCurrentIndex(model->index(target, 0));
	}
	PlayListDock *p;
	Ui::Ui_PlayListWidget ui;
	PlayListModel *model;
	QProcess *proc;
	QTimer *timer;
	QDialog *pwd;
	Ui::Ui_GetPasswordDialog pwUi;
	bool checking, adding;
	bool identified;
	static QRegExp rxRoot;
};

QRegExp PlayListDock::Data::rxRoot("^root\\r*\\n*$");

PlayListDock::PlayListDock(PlayListModel *model, QWidget *parent)
: QDockWidget(parent) {
	d = new Data(model, this);
}

PlayListDock::~PlayListDock() {
	d->proc->kill();
	delete d;
}

void PlayListDock::checkRoot(bool checked) {
	if (!checked)
		return;
	QProcess proc;
	proc.start("whoami");
	if (!proc.waitForFinished(1000))
		proc.kill();
	if (Data::rxRoot.indexIn(proc.readAllStandardOutput()) != -1)
		return;
	if (d->pwd->exec()) {
		QStringList args;
		args << QApplication::applicationFilePath() << "-shutdown";
		if (QProcess::startDetached("sudo", args))
			qApp->quit();
	}
	d->ui.shutdown_check->setChecked(false);
}

void PlayListDock::checkPassword() {
	d->pwUi.ok_button->setText(trUtf8("확인중"));
	d->pwUi.ok_button->setEnabled(false);
	d->pwUi.password_edit->setEnabled(false);
	
	d->proc->start("sudo", QStringList() << "-k");
	d->proc->waitForFinished(1000);
	d->proc->start("sudo", QStringList() << "-S" << "whoami");
	if (d->proc->waitForStarted(1000))
		d->proc->write((d->pwUi.password_edit->text() + '\n').toLocal8Bit());
	
	d->timer->start();
}

void PlayListDock::slotTimer() {
	QMessageBox::warning(this, trUtf8("확인 실패"), trUtf8("잘못된 암호입니다."));
	d->pwUi.ok_button->setText(trUtf8("확인"));
	d->pwUi.ok_button->setEnabled(true);
	d->pwUi.password_edit->setEnabled(true);
	d->pwUi.password_edit->clear();
	d->pwUi.password_edit->setFocus();
	d->proc->kill();
}

void PlayListDock::readStdOut() {
	if (Data::rxRoot.indexIn(QString::fromLocal8Bit(d->proc->readAllStandardOutput())) != -1) {
		d->timer->stop();
		d->pwUi.ok_button->setEnabled(false);
		d->pwUi.password_edit->setEnabled(false);
		if (d->proc->state() == QProcess::Running)
			d->proc->kill();
		d->pwUi.password_edit->clear();
		d->pwd->accept();
	}
}

void PlayListDock::up() {
	d->move(true);
}

void PlayListDock::down() {
	d->move(false);
}

void PlayListDock::open() {
	QString file = QFileDialog::getOpenFileName(this, trUtf8("파일 열기"), QString(),
			trUtf8("재생 목록") + " (*.pls)");
	if (!file.isEmpty())
		d->model->load(file);
}

void PlayListDock::save() {
	QString filePath = QFileDialog::getSaveFileName(this, trUtf8("파일 저장"), QString(),
			trUtf8("재생 목록") + " (*.pls)");
	if (!filePath.isEmpty()) {
		if (QFileInfo(filePath).suffix().compare("pls", Qt::CaseInsensitive) != 0)
			filePath += ".pls";
		d->model->save(filePath);
	}
}

void PlayListDock::setAutoShutdown(bool shut) {
	d->ui.shutdown_check->setChecked(shut);
}

void PlayListDock::add() {
	static const MPlayer::Informations *info = MPlayer::Informations::get();
	static const QString Filter = trUtf8("비디오 파일") +' ' + info->videoExtensions().toFilter() + ";;"
			+ trUtf8("음악 파일") + ' ' + info->audioExtensions().toFilter() + ";;"
			+ trUtf8("모든 파일") + ' ' + "(*.*)";
	QStringList files = QFileDialog::getOpenFileNames(this, trUtf8("파일 열기"), QString(), Filter);
	for (int i=0; i<files.size(); ++i)
		d->model->append(files[i]);
}


void PlayListDock::erase() {
	const int row = d->ui.list->currentIndex().row();
	if (d->model->remove(row))
		d->ui.list->setCurrentIndex(d->model->index(row, 0));
}

void PlayListDock::checkShutdown() {
	if (!d->ui.shutdown_check->isChecked())
		return;
	if (QProcess::startDetached("sudo", QStringList() << "-S" << "shutdown" << "-h" << "now"))
		qApp->quit();
}
