#ifndef PREFERENCES_H
#define PREFERENCES_H

#include <QStringList>
#include "singletoninterface.h"

namespace Preferences {

class General;			class Subtitle;
class Interface;

class Settings : public SingletonInterface<Settings> {
	SINGLE(Settings)
public:
	void load();
	void save() const;
	void setGeneral(const General &general);
	void setSubtitle(const Subtitle &subtitle);
	void setInterface(const Interface &interface);
	inline const General &general() const {return *m_general;}
	inline const Subtitle &subtitle() const {return *m_subtitle;}
	inline const Interface &interface() const {return *m_interface;}
private:
	Settings();
	General *m_general;
	Subtitle *m_subtitle;
	Interface *m_interface;
};

Settings *get();

}

#endif
