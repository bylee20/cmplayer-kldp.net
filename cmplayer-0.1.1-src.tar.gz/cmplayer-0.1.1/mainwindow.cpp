#include <QApplication>
#include <QToolButton>
#include <QActionGroup>
#include <QUrl>
#include <QRegExp>
#include <QDropEvent>
#include <QDir>
#include <QFileDialog>
#include <cmath>
#include <mplayer/playengine.h>
#include <mplayer/mediasource.h>
#include <mplayer/volumeslider.h>
#include <mplayer/seekslider.h>
#include <mplayer/informations.h>
#include <mplayer/videowidget.h>
#include <mplayer/subtitleoutput.h>
#include <mplayer/audiooutput.h>
#include "ui_mainwindow.h"
#include "ui_aboutdialog.h"
#include "mainwindow.h"
#include "preferences.h"
#include "prefgeneral.h"
#include "prefinterface.h"
#include "actioncollection.h"
#include "playmenubar.h"
#include "playlistdock.h"
#include "recentinfo.h"
#include "equalizerdialog.h"
#include "prefsettingsdialog.h"
#include "helper.h"
#include "menutreereader.h"
#include "abrepeater.h"
#include "abrepeatdialog.h"
#include "playlistmodel.h"

struct MainWindow::Data {
	enum StaysOnTop {AlwaysOnTop, OnlyPlaying, NotStayOnTop};
	static const int subPosStep = 1;
	MainWindow *p;
	Ui::Ui_MainWindow ui;
	bool dragMove, repeating, pausedByHiding, resizedByAct;
	StaysOnTop staysOnTop;
	QPoint dragPos;
	Preferences::Settings *pref;
	RecentInfo *recent;
	PlayMenuBar *pmb;
	QActionGroup *onTopActions, *videoSizeActions, *videoAspectActions;
	QActionGroup *videoCropActions, *subListActions;
	QList<QAction *> recentActions;
	MPlayer::VideoWidget *video;
	MPlayer::PlayEngine *engine;
	MPlayer::SubtitleOutput *subout;
	MPlayer::AudioOutput *audio;
	PlayListModel *plm;
	PlayListDock *pld;
	ABRepeater *repeater;
	QMenu *subSelMenu, *recentMenu;
	QMap<int, QAction*> mouseClickActions;
	QMap<int, QPair<QAction*, QAction*> > wheelScrollActions;
	Data(MainWindow *parent)
	: p(parent), dragMove(false), repeating(false), pausedByHiding(false), resizedByAct(false)
	, staysOnTop(NotStayOnTop), pref(Preferences::get()), recent(RecentInfo::get())
	, pmb(new PlayMenuBar(p)), onTopActions(new QActionGroup(p))
	, videoSizeActions(new QActionGroup(p)), videoAspectActions(new QActionGroup(p))
	, videoCropActions(new QActionGroup(p)), subListActions(new QActionGroup(p))
	, video(new MPlayer::VideoWidget(p)), engine(new MPlayer::PlayEngine(p))
	, subout(new MPlayer::SubtitleOutput(p)), audio(new MPlayer::AudioOutput(p))
	, plm(new PlayListModel(engine, p)), pld(new PlayListDock(plm, p))
	, repeater(ABRepeater::get()) {
		ui.setupUi(p);
		
		MPlayer::connect(engine, video);
		MPlayer::connect(engine, audio);
		MPlayer::connect(engine, subout);
		
		connect(ui.file_open_action, SIGNAL(triggered()), p, SLOT(open()));
		connect(ui.file_recent_clear_action, SIGNAL(triggered()), p, SLOT(clearRecentFiles()));
		connect(ui.file_exit_action, SIGNAL(triggered()), qApp, SLOT(quit()));
		
		connect(ui.play_show_playlist_action, SIGNAL(triggered()), p, SLOT(togglePlayListVisibility()));
		connect(ui.play_pause_action, SIGNAL(triggered()), p, SLOT(togglePlayPause()));
		connect(ui.play_stop_action, SIGNAL(triggered()), engine, SLOT(stop()));
		connect(ui.play_previous_action, SIGNAL(triggered()), plm, SLOT(playPrevious()));
		connect(ui.play_next_action, SIGNAL(triggered()), plm, SLOT(playNext()));
		connect(ui.play_forward_action, SIGNAL(triggered()), p, SLOT(forward()));
		connect(ui.play_forward_more_action, SIGNAL(triggered()), p, SLOT(forwardMore()));
		connect(ui.play_forward_much_more_action, SIGNAL(triggered()), p, SLOT(forwardMuchMore()));
		connect(ui.play_backward_action, SIGNAL(triggered()), p, SLOT(backward()));
		connect(ui.play_backward_more_action, SIGNAL(triggered()), p, SLOT(backwardMore()));
		connect(ui.play_backward_much_more_action, SIGNAL(triggered()), p, SLOT(backwardMuchMore()));
		connect(ui.play_ab_select_action, SIGNAL(triggered()), p, SLOT(selectABSection()));
		connect(ui.play_ab_stop_action, SIGNAL(triggered()), repeater, SLOT(stop()));
		connect(ui.play_ab_advance_action, SIGNAL(triggered()), p, SLOT(showABRepeatDialog()));
		connect(ui.play_speed_restore_action, SIGNAL(triggered()), p, SLOT(restoreSpeed()));
		connect(ui.play_speed_increase_action, SIGNAL(triggered()), p, SLOT(increaseSpeed()));
		connect(ui.play_speed_decrease_action, SIGNAL(triggered()), p, SLOT(decreaseSpeed()));
		connect(ui.play_speed_double_action, SIGNAL(triggered()), p, SLOT(doubleSpeed()));
		connect(ui.play_speed_half_action, SIGNAL(triggered()), p, SLOT(halfSpeed()));
	
		connect(ui.video_fullscreen_action, SIGNAL(toggled(bool)), p, SLOT(setFullScreen(bool)));
		connect(onTopActions, SIGNAL(triggered(QAction*)), p, SLOT(changeStaysOnTop(QAction*)));	
		connect(videoSizeActions, SIGNAL(triggered(QAction*)), p, SLOT(changeVideoSize(QAction*)));
		connect(videoAspectActions, SIGNAL(triggered(QAction*)), p, SLOT(changeAspectRatio(QAction*)));	
		connect(videoCropActions, SIGNAL(triggered(QAction *)), p, SLOT(crop(QAction *)));
		connect(ui.video_equalizer_action, SIGNAL(triggered()), p, SLOT(showEqualizer()));
	
		connect(ui.audio_volume_up_action, SIGNAL(triggered()), p, SLOT(increaseVolume()));
		connect(ui.audio_volume_down_action, SIGNAL(triggered()), p, SLOT(decreaseVolume()));
		connect(ui.audio_mute_action, SIGNAL(toggled(bool)), audio, SLOT(setMuted(bool)));

		connect(subListActions, SIGNAL(triggered(QAction*)), p, SLOT(changeCurrentSubtitles(QAction*)));
		connect(ui.subtitle_clear_action, SIGNAL(triggered()), subout, SLOT(clearSubtitles()));
		connect(ui.subtitle_add_action, SIGNAL(triggered()), p, SLOT(addSubtitles()));
		connect(ui.subtitle_step_up_action, SIGNAL(triggered()), p, SLOT(stepUpSubtitle()));
		connect(ui.subtitle_step_down_action, SIGNAL(triggered()), p, SLOT(stepDownSubtitle()));
		connect(ui.subtitle_sync_increase_action, SIGNAL(triggered()), p, SLOT(increaseSyncDelay()));
		connect(ui.subtitle_sync_decrease_action, SIGNAL(triggered()), p, SLOT(decreaseSyncDelay()));
	
		connect(ui.option_preferences_action, SIGNAL(triggered()), p, SLOT(showPreferencesDialog()));

		connect(ui.about_qt_action, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
		connect(ui.about_cmp_action, SIGNAL(triggered()), p, SLOT(showAboutDialog()));
		
		ui.video_on_top_only_playing_action->setData(OnlyPlaying);
		ui.video_on_top_off_action->setData(NotStayOnTop);
		ui.video_on_top_always_action->setData(AlwaysOnTop);
		onTopActions->addAction(ui.video_on_top_always_action);
		onTopActions->addAction(ui.video_on_top_only_playing_action);
		onTopActions->addAction(ui.video_on_top_off_action);
	
		ui.video_size_50_action->setData(0.5);
		ui.video_size_100_action->setData(1.0);
		ui.video_size_150_action->setData(1.5);
		ui.video_size_200_action->setData(2.0);
		ui.video_size_250_action->setData(2.5);
		ui.video_size_300_action->setData(3.0);
		ui.video_size_350_action->setData(3.5);
		ui.video_size_400_action->setData(4.0);
		ui.video_size_user_action->setData(-1.0);
		videoSizeActions->addAction(ui.video_size_50_action);
		videoSizeActions->addAction(ui.video_size_100_action);
		videoSizeActions->addAction(ui.video_size_150_action);
		videoSizeActions->addAction(ui.video_size_200_action);
		videoSizeActions->addAction(ui.video_size_250_action);
		videoSizeActions->addAction(ui.video_size_300_action);
		videoSizeActions->addAction(ui.video_size_350_action);
		videoSizeActions->addAction(ui.video_size_400_action);
		videoSizeActions->addAction(ui.video_size_user_action);
	
		ui.video_aspect_auto_action->setData(MPlayer::VideoWidget::AspectRatioAuto);
		ui.video_aspect_widget_action->setData(MPlayer::VideoWidget::AspectRatioWidget);
		ui.video_aspect_4_3_action->setData(static_cast<double>(4) / 3);
		ui.video_aspect_16_9_action->setData(static_cast<double>(16) / 9);
		ui.video_aspect_2_35_1_action->setData(2.35 / 1);
		videoAspectActions->addAction(ui.video_aspect_auto_action);
		videoAspectActions->addAction(ui.video_aspect_widget_action);
		videoAspectActions->addAction(ui.video_aspect_4_3_action);
		videoAspectActions->addAction(ui.video_aspect_16_9_action);
		videoAspectActions->addAction(ui.video_aspect_2_35_1_action);
	
		ui.video_crop_off_action->setData(MPlayer::VideoWidget::CropOff);
		ui.video_crop_4_3_action->setData(static_cast<double>(4) / 3);
		ui.video_crop_16_9_action->setData(static_cast<double>(16) / 9);
		ui.video_crop_2_35_1_action->setData(2.35 / 1);
		videoCropActions->addAction(ui.video_crop_off_action);
		videoCropActions->addAction(ui.video_crop_4_3_action);
		videoCropActions->addAction(ui.video_crop_16_9_action);
		videoCropActions->addAction(ui.video_crop_2_35_1_action);
	
		subListActions->addAction(ui.subtitle_disable_action);
		subListActions->setExclusive(false);

		QList<QWidget *> tools;
#define addToolButton(act) {\
		QToolButton *tb = new QToolButton(pmb); tb->setAutoRaise(true); \
		tb->setFocusPolicy(Qt::NoFocus); tb->setIconSize(QSize(16, 16)); \
		tb->setDefaultAction(act); tools.append(tb);}
		addToolButton(ui.play_previous_action);
		addToolButton(ui.play_pause_action);
		addToolButton(ui.play_stop_action);
		addToolButton(ui.play_next_action);
		tools.append(new MPlayer::SeekSlider(engine, pmb));
		addToolButton(ui.audio_mute_action);
		tools.append(new MPlayer::VolumeSlider(audio, pmb));
#undef makeToolButton
		pmb->init(tools);
		connect(engine, SIGNAL(totalTimeChanged(qint64)), pmb, SLOT(setTotalTime(qint64)));
		connect(engine, SIGNAL(tick(qint64)), pmb, SLOT(setCurrentTime(qint64)));
		ui.play_bar->layout()->setMargin(0);
		ui.play_bar->layout()->setSpacing(0);
		ui.play_bar->addWidget(pmb);
	
		connect(engine, SIGNAL(stateChanged(MPlayer::State, MPlayer::State)), p, SLOT(slotStateChanged(MPlayer::State)));
		connect(engine, SIGNAL(speedChanged(double)), p, SLOT(updateSpeed(double)));
		connect(engine, SIGNAL(aboutToFinished()), p, SLOT(updateFinishedFile()));
		connect(engine, SIGNAL(stopped(qint64)), p, SLOT(updateStopped(qint64)));
		connect(subout, SIGNAL(syncDelayChanged(int)), p, SLOT(updateSyncDelay(int)));
		connect(subout, SIGNAL(subtitlesChanged(const QStringList&)), p, SLOT(updateSubtitles(const QStringList&)));
		connect(subout, SIGNAL(currentIndexesChanged(const QList<int>&)), p, SLOT(updateCurrentSubtitleIndexes(const QList<int>&)));

		connect(audio, SIGNAL(mutedChanged(bool)), ui.audio_mute_action, SLOT(setChecked(bool)));
		
		connect(video, SIGNAL(resized(const QSize&)), p, SLOT(slotResized()));
		connect(video, SIGNAL(sizeHintChanged(const QSize&)), ui.video_size_100_action, SLOT(trigger()));
		connect(video, SIGNAL(customContextMenuRequested(const QPoint&)), p, SLOT(showMouseMenu(const QPoint&)));
		
		connect(recent, SIGNAL(filesChanged(const RecentStack&)), p, SLOT(updateRecentActions(const RecentStack&)));
		connect(recent, SIGNAL(rememberCountChanged(int)), p, SLOT(updateRecentSize(int)));

		connect(pld, SIGNAL(visibilityChanged(bool)), p, SLOT(adjustSizeForDock(bool)));
		connect(plm, SIGNAL(currentRowChanged(int)), p, SLOT(updatePlayText()));
		connect(plm, SIGNAL(rowCountChanged(int)), p, SLOT(updatePlayText()));
	}
	QMenu *findMenuIn(QMenu *menu, const QString &title) {
		QList<QAction*> acts = menu->actions();
		for (int i=0; i<acts.size(); ++i) {
			if (acts[i]->menu()) {
				if (acts[i]->text() != title) {
					QMenu *m = findMenuIn(acts[i]->menu(), title);
					if (m)
						return m;
				} else
					return acts[i]->menu();
			}
		}
		return 0;
	}
	void registerActions() {
		mouseClickActions[Preferences::Interface::ToggleFullScreen] = ui.video_fullscreen_action;
		mouseClickActions[Preferences::Interface::TogglePlayPause] = ui.play_pause_action;
		wheelScrollActions[Preferences::Interface::ForwardBackward]
				= qMakePair(ui.play_forward_action, ui.play_backward_action);
		wheelScrollActions[Preferences::Interface::ForwardBackwardMore]
				= qMakePair(ui.play_forward_more_action, ui.play_backward_more_action);
		wheelScrollActions[Preferences::Interface::ForwardBackwardMuchMore]
				= qMakePair(ui.play_forward_much_more_action, ui.play_backward_much_more_action);
		wheelScrollActions[Preferences::Interface::VolumeUpDown]
				= qMakePair(ui.audio_volume_up_action, ui.audio_volume_down_action);
	
		ActionCollection *ac = ActionCollection::get();
		QList<QAction *> acts = p->menuBar()->actions();
		ac->addActions(acts);
		QMenu *wholeMenu = new QMenu(p);
		wholeMenu->addActions(acts);
		QMenu *customMenu = new QMenu(p);
		MenuTreeReader reader;
		if (!reader.read(customMenu, Helper::menuFile())) {
			customMenu->addAction(ui.file_open_action);
			customMenu->addMenu(ui.file_recent_menu);
			customMenu->addSeparator();
			customMenu->addMenu(ui.video_on_top_menu);
			customMenu->addMenu(ui.video_size_menu);
			customMenu->addMenu(ui.video_aspect_menu);
			customMenu->addMenu(ui.video_crop_menu);
			customMenu->addAction(ui.video_equalizer_action);
			customMenu->addSeparator();
			customMenu->addAction(ui.play_show_playlist_action);
			customMenu->addMenu(ui.play_speed_menu);
			customMenu->addMenu(ui.play_ab_menu);
			customMenu->addSeparator();
			customMenu->addMenu(ui.subtitle_select_menu);
			customMenu->addAction(ui.subtitle_add_action);
			customMenu->addMenu(ui.subtitle_pos_menu);
			customMenu->addMenu(ui.subtitle_sync_menu);
			customMenu->addSeparator();
			customMenu->addAction(ui.option_preferences_action);
			customMenu->addSeparator();
			customMenu->addAction(ui.about_qt_action);
			customMenu->addAction(ui.about_cmp_action);
			customMenu->addSeparator();
			customMenu->addAction(ui.file_exit_action);
		}
		ac->setWholeMenu(wholeMenu);
		ac->setCustomMenu(customMenu);
		p->addActions(ac->actions());
	
		updateMenus();
		
		const QMap<QString, QKeySequence> &keys = Preferences::get()->interface().shortcuts;
		for (QMap<QString, QKeySequence>::const_iterator it = keys.begin(); it != keys.end(); ++it) {
			QAction *act = ac->action(it.key());
			if (act)
				act->setShortcut(it.value());
		}
	}
	void updateStaysOnTop() {
		if (p->isFullScreen())
			return;
		Qt::WindowFlags f = p->windowFlags();
		QPoint oldPos = p->pos();
		bool wasOnTop =  f & Qt::WindowStaysOnTopHint;
		bool wasVisible = p->isVisible();
		bool wasActivated = p->isActiveWindow();
		bool isOnTop = (staysOnTop == AlwaysOnTop)
				|| (staysOnTop == OnlyPlaying && engine->state() == MPlayer::PlayingState);
		if (wasOnTop != isOnTop) {
			if (isOnTop)
				f |= Qt::WindowStaysOnTopHint;
			else
				f &= ~Qt::WindowStaysOnTopHint;
			p->setWindowFlags(f);
			p->setVisible(wasVisible);
			if (wasActivated)
				p->activateWindow();
			p->move(oldPos);
		}
	}
	void updateMenus() {
		static const ActionCollection *ac = ActionCollection::get();
		subSelMenu = findMenuIn(ac->customMenu(), ui.subtitle_select_menu->title());
		recentMenu = findMenuIn(ac->customMenu(), ui.file_recent_menu->title());
	}
	void open(const QString &file) {
		static const QStringList NameFilter
				= MPlayer::Informations::get()->videoExtensions().toNameFilter();
		plm->clear();
		const QFileInfo info(file);
		if (pref->general().autoAddFiles != Preferences::General::DoNotAddFiles) {
			QString fileName = QFileInfo(file).fileName();
			QStringList files = info.dir().entryList(NameFilter, QDir::Files, QDir::Name);
			bool all = pref->general().autoAddFiles == Preferences::General::AllFiles;
			bool prefix = false, suffix = false;
			for(QStringList::const_iterator it = files.begin(); it != files.end(); ++it) {
				if (!all) {
					static QRegExp rxs("(\\D*)\\d+(.*)");
					static QRegExp rxt("(\\D*)\\d+(.*)");
					if (rxs.indexIn(fileName) == -1 || rxt.indexIn(*it) == -1)
						continue;
					if (!prefix && !suffix) {
						if (rxs.cap(1) == rxt.cap(1))
							prefix = true;
						else if (rxs.cap(2) == rxt.cap(2))
							suffix = true;
						else
							continue;
					} else if (prefix) {
						if (rxs.cap(1) != rxt.cap(1))
							continue;
					} else if (suffix) {
						if (rxs.cap(2) != rxt.cap(2))
							continue;
					}
				}
				plm->append(info.path() + '/' + *it);
			}
		}
		plm->play(file);
		recent->stackFile(file);
	}
};

MainWindow::MainWindow(QWidget *parent)
: QMainWindow(parent) {
	d = new Data(this);
	
	QMenuBar *bar = menuBar();
	bar->insertSeparator(d->ui.help_menu->menuAction());
	bar->hide();
		
	addDockWidget(Qt::RightDockWidgetArea, d->pld);
	d->pld->hide();

	d->video->setContextMenuPolicy(Qt::CustomContextMenu);	
	setMouseTracking(true);
	setAcceptDrops(true);
	setCentralWidget(d->video);
	
	d->repeater->setPlayEngine(d->engine);
	
	setWindowTitle(trUtf8("CMP") + ' ' + Helper::version());
	
	d->registerActions();
	
	d->recent->setPlayList(d->plm);
	d->recent->load();

	resize(300, 200);
		
	QStringList args = QApplication::arguments();
	const int size = args.size();
	if (size > 1) {
		int index = args.indexOf("-shutdown");
		if (index != -1) {
			d->plm->play(d->plm->currentRow());
			d->pld->setAutoShutdown(true);
		} else
			d->open(args.last());
	}
}

MainWindow::~MainWindow() {
	d->engine->stop();
	d->recent->save();
	delete d;
}

void MainWindow::showMouseMenu(const QPoint &pos) {
	ActionCollection::get()->customMenu()->exec(d->video->mapToGlobal(pos));
}

void MainWindow::togglePlayListVisibility() {
	d->pld->setVisible(d->pld->isHidden());
}

void MainWindow::increaseSpeed() {
	d->engine->setSpeed(d->engine->speed() + 0.1);
}

void MainWindow::decreaseSpeed() {
	d->engine->setSpeed(d->engine->speed() - 0.1);
}

void MainWindow::restoreSpeed() {
	d->engine->setSpeed(1.0);
}

void MainWindow::doubleSpeed() {
	d->engine->setSpeed(d->engine->speed() * 2.0);
}

void MainWindow::halfSpeed() {
	d->engine->setSpeed(d->engine->speed() * 0.5);
}

void MainWindow::updateSpeed(double speed) {
	static QString text = trUtf8("현재: ×%1 배속");
	d->ui.play_speed_current_action->setText(text.arg(speed));
}

void MainWindow::changeStaysOnTop(QAction *act) {
	d->staysOnTop = Data::StaysOnTop(act->data().toInt());
	d->updateStaysOnTop();
}

void MainWindow::updateFinishedFile() {
	d->recent->setFinished(d->engine->currentMediaSource().fileName());
}

void MainWindow::updatePlayText() {
	QString text = QFileInfo(d->plm->currentMediaSource().fileName()).fileName();
	const int row = d->plm->currentRow();
	const int count = d->plm->rowCount();
	if (row != -1 && count && row < count)
		text += QString(" (%1/%2)").arg(row + 1).arg(count);
	if (!text.isEmpty())
		text += " - ";
	if (d->engine->isPlaying())
		text += trUtf8("재생중");
	else if (d->engine->isPaused())
		text += trUtf8("일시정지");
	else
		text += trUtf8("정지");
	d->pmb->setPlayText(text);
}

void MainWindow::clearRecentFiles() {
	d->recent->clearStack();
}

void MainWindow::updateRecentSize(int size) {
	if (!d->recentMenu)
		return;
	static ActionCollection *ac = ActionCollection::get();
	while (size != d->recentActions.size()) {
		if (size > d->recentActions.size()) {
			static QAction *sprt = d->recentMenu->actions()[0];
			QAction *act = new QAction(d->recentMenu);
			connect(act, SIGNAL(triggered()), this, SLOT(openRecent()));
			d->recentMenu->insertAction(sprt, act);
			d->recentActions.append(act);
		} else
			delete ac->take(d->recentActions.takeLast());
	}
	for (int i=0; i<d->recentActions.size(); ++i) {
		ac->addAction(trUtf8("최근 연 파일 %1").arg(i+1), ac->take(d->recentActions[i]));
	}
}

void MainWindow::updateRecentActions(const RecentStack &files) {
	const int count = files.size();
	if (count != d->recentActions.size())
		updateRecentSize(count);
	for (int i=0; i<count; ++i) {
		QAction *act = d->recentActions[i];
		act->setData(files[i]);
		act->setText(QFileInfo(files[i]).fileName());
		act->setVisible(!files[i].isEmpty());
	}
}

void MainWindow::openRecent() {
	QAction *act = qobject_cast<QAction *>(sender());
	if (act)
		d->open(act->data().toString());
}

void MainWindow::slotResized() {
	if (!d->resizedByAct && !isFullScreen())
		d->ui.video_size_user_action->setChecked(true);
	else
		d->resizedByAct = false;
}

void MainWindow::updateSyncDelay(int msec) {
	d->ui.subtitle_sync_current_action->setText(trUtf8("현재값:"
			"%1").arg(static_cast<double>(msec)/1000));
}

void MainWindow::crop(QAction *act) {
	d->video->crop(act->data().toDouble());
}

void MainWindow::showPreferencesDialog() {
	Preferences::SettingsDialog dlg(this);
	if (dlg.exec()) {
		d->updateMenus();
		d->engine->restart();
	}
}

void MainWindow::clearSubtitleList() {
	QList<QAction *> acts = d->subListActions->actions();
	for (int i=0; i<acts.size()-1; ++i) {
		d->subListActions->removeAction(acts[i]);
		delete acts[i];
	}
	d->subListActions->removeAction(d->ui.subtitle_disable_action);
	d->ui.subtitle_disable_action->setVisible(false);
}

void MainWindow::updateCurrentSubtitleIndexes(const QList<int> &indexes) {
	d->ui.subtitle_disable_action->setChecked(!indexes.size());
	QList<QAction *> act = d->subListActions->actions();
	for (int i=0; i<act.size()-1; ++i)
		act[i]->setChecked(indexes.contains(i));
}

void MainWindow::updateSubtitles(const QStringList &files) {
	if (!d->subSelMenu)
		return;
	clearSubtitleList();
	const int count = files.size();
	const QList<int> &indexes = d->subout->currentIndexes();
	for (int i=0; i<count; ++i) {
		QAction *act = d->subSelMenu->addAction(QFileInfo(files[i]).fileName());
		act->setCheckable(true);
		act->setData(i);
		act->setChecked(indexes.contains(i));
		d->subListActions->addAction(act);
	}
	d->subListActions->addAction(d->ui.subtitle_disable_action);
	d->ui.subtitle_disable_action->setVisible(count);
	d->ui.subtitle_clear_action->setEnabled(count);
}

void MainWindow::addSubtitles() {
	static const QString Filter
		= trUtf8("자막 파일") + ' ' + MPlayer::Informations::get()->subtitleFilter().toFilter() + ";;"
		+ trUtf8("모든 파일") + ' ' + "(*.*)";
	const QStringList paths = QFileDialog::getOpenFileNames(this, trUtf8("파일 열기"),
		QString(), Filter);
	if (paths.size())
		d->subout->appendSubtitles(paths, true);
}

void MainWindow::showEqualizer() {
	EqualizerDialog dlg(d->video, this);
	dlg.exec();
}

void MainWindow::changeCurrentSubtitles(QAction* act) {
	if (act != d->ui.subtitle_disable_action) {
		if (act->isChecked()) {
			d->subout->appendCurrentIndex(act->data().toInt());
		} else
			d->subout->removeCurrentIndex(act->data().toInt());
	} else
		d->subout->setCurrentIndexes(QList<int>());
}

void MainWindow::setFullScreen(bool full) {
	if (full == isFullScreen())
		return;
	d->ui.play_bar->setHidden(full);
	if (full) {
		d->pld->hide();
		setWindowState(windowState() ^ Qt::WindowFullScreen);
	} else {
		setWindowState(windowState() ^ Qt::WindowFullScreen);
		d->updateStaysOnTop();
	}
	d->engine->setFullScreenState(full);
	d->videoSizeActions->setDisabled(full);
}

void MainWindow::changeVideoSize(QAction *act) {
	d->resizedByAct = act != d->ui.video_size_user_action;
	setVideoSize(act->data().toDouble());
}

void MainWindow::setVideoSize(double rate) {
	if (rate > 0.0)
		resize(size() + d->video->sizeHint()*std::sqrt(rate) - d->video->size());
}

void MainWindow::slotStateChanged(MPlayer::State /*state*/) {
	if (d->engine->isPlaying()) {
		d->ui.play_pause_action->setIcon(QIcon(":/img/media-playback-pause.png"));
		d->ui.play_pause_action->setText(trUtf8("일시정지"));
	} else {
		d->ui.play_pause_action->setIcon(QIcon(":/img/media-playback-start.png"));
		d->ui.play_pause_action->setText(trUtf8("재생"));
	}
	updatePlayText();
	d->updateStaysOnTop();
}

void MainWindow::hideEvent(QHideEvent *event) {
	QMainWindow::hideEvent(event);
	if (d->pref->general().pauseWhenMinimized && d->engine->isPlaying()) {
		d->engine->pause();
		d->pausedByHiding = true;
	}
}

void MainWindow::showEvent(QShowEvent *event) {
	QMainWindow::showEvent(event);
	if (d->pausedByHiding && d->pref->general().playWhenRestored) {
		d->engine->play();
		d->pausedByHiding = false;
	}
}

void MainWindow::closeEvent(QCloseEvent *event) {
	QMainWindow::closeEvent(event);
}

void MainWindow::changeAspectRatio(QAction *act) {
	d->video->setAspectRatio(act->data().toDouble());
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event) {
	return QMainWindow::eventFilter(obj, event);
}
	
void MainWindow::open() {
	static const MPlayer::Informations *info = MPlayer::Informations::get();
	static const QString Filter = trUtf8("비디오 파일") +' ' + info->videoExtensions().toFilter() + ";;"
			+ trUtf8("음악 파일") + ' ' + info->audioExtensions().toFilter() + ";;"
			+ trUtf8("모든 파일") + ' ' + "(*.*)";
	const QString file = QFileDialog::getOpenFileName(this, trUtf8("파일 열기"), QString(), Filter);
	if (!file.isEmpty())
		d->open(file);
}

void MainWindow::showAboutDialog() {
	QDialog dlg(this);
	Ui::Ui_AboutDialog ui;
	ui.setupUi(&dlg);
	ui.version_label->setText(ui.version_label->text().arg(Helper::version()).arg(QT_VERSION_STR));
	dlg.exec();
}

void MainWindow::mouseMoveEvent(QMouseEvent *event) {
	QMainWindow::mouseMoveEvent(event);
	if (d->dragMove && event->buttons() & Qt::LeftButton)
		move(event->globalPos() - d->dragPos);
	if (isFullScreen()) {
		static const int h = d->pmb->height();
		QRect r = rect();
		r.setTop(r.height() - h);
		d->ui.play_bar->setVisible(r.contains(event->pos()));
	}
}

void MainWindow::mousePressEvent(QMouseEvent *event) {
	QMainWindow::mouseMoveEvent(event);
	bool inCentral = d->video->geometry().contains(event->pos());
	d->dragMove = event->buttons() & Qt::LeftButton && inCentral && !isFullScreen();
	if (d->dragMove)
		d->dragPos = event->globalPos() - frameGeometry().topLeft();
	if (event->button() == Qt::MidButton && inCentral)
		d->mouseClickActions[d->pref->interface().middleClickAction]->trigger();
}

void MainWindow::mouseDoubleClickEvent(QMouseEvent *event) {
	QMainWindow::mouseDoubleClickEvent(event);
	if (event->button() == Qt::LeftButton
			&& d->video->geometry().contains(event->pos()))
		d->mouseClickActions[d->pref->interface().doubleClickAction]->trigger();
}

void MainWindow::wheelEvent(QWheelEvent *event) {
	const int delta = event->delta();
	if (delta > 0)
		d->wheelScrollActions[d->pref->interface().wheelScrollAction].first->trigger();
	else if (delta < 0)
		d->wheelScrollActions[d->pref->interface().wheelScrollAction].second->trigger();
	else
		event->ignore();
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event) {
	if (event->mimeData()->hasUrls())
		event->acceptProposedAction();
}

void MainWindow::dropEvent(QDropEvent *event) {
	if (!event->mimeData()->hasUrls())
		return;
	QList<QUrl> urls = event->mimeData()->urls();
	if (urls.size()) {
		if (urls[0].scheme() == "file") {
			d->plm->play(urls[0].toLocalFile());
		}
	}
}

void MainWindow::increaseVolume() {
	d->audio->setVolume(d->pref->interface().volumeStep, true);
}

void MainWindow::decreaseVolume() {
	d->audio->setVolume(-d->pref->interface().volumeStep, true);
}

void MainWindow::forward() {
	d->engine->seek(d->pref->interface().seekingStep, true);
}

void MainWindow::forwardMore() {
	d->engine->seek(d->pref->interface().seekingMoreStep, true);
}

void MainWindow::forwardMuchMore() {
	d->engine->seek(d->pref->interface().seekingMuchMoreStep, true);
}

void MainWindow::backward() {
	d->engine->seek(-d->pref->interface().seekingStep, true);
}

void MainWindow::backwardMore() {
	d->engine->seek(-d->pref->interface().seekingMoreStep, true);
}

void MainWindow::backwardMuchMore() {
	d->engine->seek(-d->pref->interface().seekingMuchMoreStep, true);
}

void MainWindow::increaseSyncDelay() {
	d->subout->addSyncDelay(d->pref->interface().syncDelayStep);
}

void MainWindow::decreaseSyncDelay() {
	d->subout->addSyncDelay(-d->pref->interface().syncDelayStep);
}

void MainWindow::stepDownSubtitle() {
	d->subout->move(d->subPosStep, true);
}

void MainWindow::stepUpSubtitle() {
	d->subout->move(-d->subPosStep, true);
}

void MainWindow::togglePlayPause() {
	if (d->engine->isStopped())
		d->plm->play(d->plm->currentRow());
	else
		d->engine->isPlaying() ? d->engine->pause() : d->engine->play();
}

void MainWindow::updateStopped(qint64 time) {
	d->recent->setStopped(d->engine->currentMediaSource().fileName(), time);
}

void MainWindow::selectABSection() {
	static bool a = false, b = false;
	if (d->repeater->isRepeating())
		a = b = false;
	if (a && !b) {
		d->repeater->setBToCurrentTime();
		b = true;
		d->repeater->start();
		a = b = false;
	} else if (!a) {
		d->repeater->setAToCurrentTime();
		d->repeater->stop();
		a = true;
	}
}

void MainWindow::showABRepeatDialog() {
	static ABRepeatDialog *dlg = new ABRepeatDialog(this);
	dlg->show();
}

void MainWindow::adjustSizeForDock(bool visible) {
	if (!isFullScreen() && !d->pld->isFloating())
		resize(width() + (visible ? 1 : -1 ) * d->pld->width(), height());
}

