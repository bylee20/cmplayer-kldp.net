#ifndef PREFERENCESPREFSUBTITLE_H
#define PREFERENCESPREFSUBTITLE_H

#include <QString>
#include <QStringList>

class QSettings;

namespace Preferences {

class Subtitle {
public:
	enum AutoLoad {
		Matched = 0,
		Contain = 1,
		SamePath = 2
	};
	enum AutoSelect {
		FirstFile = 0,
		SameName = 1,
		AllLoaded
	};
	enum AutoScale {
		NoAutoScale = 0,
		FitToHeight = 1,
		FitToWidth = 2,
		FitToDiagonal = 3
	};
	QString family;
	bool useAutoLoad;
	QString encoding;
	AutoScale autoScale;
	double defaultScale;
	int initialPosition;
	QStringList classes;
	AutoLoad autoLoad;
	AutoSelect autoSelect;
	void load(QSettings *set);
	void save(QSettings *set) const;
};

}

#endif
