#include <QSettings>
#include "prefsubtitle.h"

namespace Preferences {

void Subtitle::load(QSettings *set) {
	set->beginGroup("Subtitle");
	family = set->value("Family", QString()).toString();
	encoding = set->value("Encoding", QString("CP949")).toString();
	autoScale = (AutoScale)set->value("AutoScale", Subtitle::FitToHeight).toInt();
	defaultScale = set->value("DefaultScale", 5.0).toDouble();
	initialPosition = set->value("InitialPosition", 100).toInt();
	classes = set->value("Classes", QStringList()<<"ENCC"<<"EGCC"<<"KRCC"<<"KNCC").toStringList();
	autoLoad = AutoLoad(set->value("AutoLoad", Subtitle::Contain).toInt());
	autoSelect = AutoSelect(set->value("AutoSelect", Subtitle::SameName).toInt());
	useAutoLoad = set->value("UseAutoLoad", true).toBool();
	set->endGroup();
}

void Subtitle::save(QSettings *set) const {
	set->beginGroup("Subtitle");
	set->setValue("Family", family);
	set->setValue("Encoding", encoding);
	set->setValue("AutoScale", autoScale);
	set->setValue("DefaultScale", defaultScale);
	set->setValue("InitialPosition", initialPosition);
	set->setValue("Classes", classes);
	set->setValue("AutoLoad", autoLoad);
	set->setValue("AutoSelect", autoSelect);
	set->setValue("UseAutoLoad", useAutoLoad);
	set->endGroup();
}

}
