#ifndef PLAYLISTDOCK_H
#define PLAYLISTDOCK_H

#include <QDockWidget>

class PlayListModel;

class PlayListDock : public QDockWidget {
	Q_OBJECT
public:
	PlayListDock(PlayListModel *model, QWidget *parent = 0);
	~PlayListDock();
	void setAutoShutdown(bool shut);
public slots:
	void checkRoot(bool checked);
private slots:
	void add();
	void erase();
	void up();
	void down();
	void readStdOut();
	void checkPassword();
	void slotTimer();
	void checkShutdown();
	void open();
	void save();
private:
	struct Data;
	friend struct Data;
	Data *d;
};

#endif
