#ifndef RECENTINFO_H
#define RECENTINFO_H

#include <QStringList>
#include <QMap>
#include <QObject>
#include "singletoninterface.h"

namespace MPlayer {class MediaSource;}

class PlayListModel;

class RecentStack : private QStringList {
public:
	RecentStack(const int size = 0);
	inline void setSize(int size) {m_size = size; checkSize();}
	inline void stack(const QString &file) {removeAll(file); push_front(file); checkSize();}
	inline int size() const {return QStringList::size();}
	inline void clear() {for (int i=0; i< m_size; ++i) (*this)[i].clear();}
	inline QString &operator[] (int i) {return QStringList::operator[](i);}
	inline const QString &operator[] (int i) const {return QStringList::operator[](i);}
	inline RecentStack &operator = (const QStringList &other) {
		QStringList::operator=(other); checkSize(); return *this;}
	inline QString value(int i) const {return QStringList::value(i);}
	inline const QStringList &toStringList() const {return static_cast<const QStringList&>(*this);}
private:
	inline void checkSize() {
		while(size() != m_size) {if (size() > m_size) pop_back(); else push_back(QString());}}
	int m_size;
};

class RecentInfo : public QObject, public SingletonInterface<RecentInfo> {
	SINGLE(RecentInfo)
	Q_OBJECT
public:
	static const int DefaultRememberCount = 5;
	inline void setPlayList(PlayListModel *model) {m_list = model;}
	inline const RecentStack &files() {return m_files;}
	inline QString lastFile() const {return m_files.value(0);}
	inline QString file(int nth) const {return m_files.value(nth);}
	inline void clearStack() {m_files.clear(); emit filesChanged(m_files);}
	inline void setStoppedCount(int count) {m_stoppedCount = count;}
	inline void setRememberCount(int count) {
		if (count != m_files.size()) {m_files.setSize(count);emit rememberCountChanged(count);}}
	void setFiles(const QStringList &files);
	void stackFile(const QString &file);
	void appendFile(const QString &file);
	void load();
	void save() const;
	void setStopped(const QString &file, qint64 time);
	void setFinished(const QString &file);
	qint64 stoppedTime(const QString &file);
signals:
	void filesChanged(const RecentStack &files);
	void rememberCountChanged(int count);
private:
	typedef QMap<QString, qint64> StoppedInfo;
	RecentInfo();
	RecentStack m_files;
	StoppedInfo m_stopped;
	PlayListModel *m_list;
	int m_stoppedCount;
};

#endif
